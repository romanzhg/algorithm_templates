#ifndef PATH_PLANNER_H
#define PATH_PLANNER_H

#include <list>

#include "position.h"
#include "robot_agent/internal_types.h"

namespace scheduling_server {

const std::list<int> kEmptyIntList = {};

struct PpRequest {
  int robot_id;
  PositionXYT pos;
  int target_or_current_sid;
  std::list<Task> tasks;
  uint64_t stand_still_time_ms;
  bool cancel_future_reservations;

  PpRequest() = default;
};

struct PpResponse {
  int robot_id;

  // Sids the robot should move to.
  // Do not update robot instructions if this field is empty.
  std::list<int> path_points;

  // True if the destination is within a range and locked by another robot.
  bool dest_locked;

  int target;
  std::list<int> locked_points;

  PpResponse(int id) : robot_id(id) {};
  PpResponse(int id,
             const std::list<int> &points,
             int target,
             const std::list<int> &locked_points)
      : robot_id(id),
        path_points(points),
        target(target),
        locked_points(locked_points) {};
};

class PathPlannerInterface {
 public:
  // This method is not thread safe.
  virtual std::list<PpResponse> QueryPath(const std::list<PpRequest> &requests) = 0;
  virtual ~PathPlannerInterface() = default;
};

}
#endif