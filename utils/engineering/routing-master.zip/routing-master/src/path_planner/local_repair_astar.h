#ifndef PP_COOPERATIVE_ASTAR_H
#define PP_COOPERATIVE_ASTAR_H

#include <set>
#include <vector>

#include "path_planner/path_planner.h"
#include "path_planner/ss_map.h"

namespace scheduling_server {
struct LrRequest;

class LRLock {
 public:
  LRLock(SsMap *ss_map) : ss_map_(ss_map) {};

  // Returns true if the path point is locked successfully.
  // A path point cannot be locked by the robot itself.
  bool LockPathPoint(int robot_id, int path_point);

  // Free one path point.
  void FreePathPoint(int robot_id);

  bool CanLockPathPoint(int robot_id, int path_point);

  // Free all path points after the given path_point.
  void FreePathPointFromSid(int robot_id, int path_point);

  int GetLockedPathPointSize(int robot_id);

  const std::list<int>& GetLockedPathPoints(int robot_id) const;

  void UpdateRobotLastUpdateTime(const std::list<PpRequest>& reqs);

 private:
  void FreeLockedPointInSidToRobotSet(int robot_id, int path_point);

  void FreeAllPathPoint(int robot_id);

  // Record the path points locked by a robot.
  // A path point is effectively a sid.
  // All points here are once sent to the robot in PpResponse.path_points.
  // For each robot, the sids here is a subset of sids in robot_to_locked_sid_.
  // path points in this list won't contain any duplication, since a path point cannot be locked twice.
  std::map<int, std::list<int>> robot_to_locked_path_point_;
  std::map<int, uint64_t> robot_to_last_update_time_;

  // Adjacency lock list.
  std::map<int, std::multiset<int>> sid_to_robot_set_;

  SsMap *ss_map_;
};

class LocalRepairAstar : public PathPlannerInterface {
 public:
  LocalRepairAstar(SsMap *ss_map) : ss_map_(ss_map), lr_lock_{ss_map} {
    prev_.resize(ss_map_->GetStatePointCount());
  };

  std::list<PpResponse> QueryPath(const std::list<PpRequest> &requests) override;

 private:
  std::list<PpResponse> LRAstar(std::list<LrRequest> requests);

  void SortRobots(std::list<LrRequest> &requests);

  // Return a list of sids from the source to the destination.
  std::list<int> Astar(int robot_id,
                       int src_sid,
                       int dest_sid,
                       bool &can_reach_dest);
  std::list<int> GetPathToRandomLocation(int robot_id, int src_sid);

  SsMap *ss_map_;
  LRLock lr_lock_;

  // Used by the LRAstar routine.
  std::vector<int> prev_;
};

}

#endif