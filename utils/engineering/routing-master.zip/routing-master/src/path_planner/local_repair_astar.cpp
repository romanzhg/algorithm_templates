#include "path_planner/local_repair_astar.h"

#include <iostream>
#include <list>
#include <queue>

#include "util/ss_util.h"
#include "logger/log.h"

using namespace std;

namespace {
// Data structure for AStar.
struct Elem {
  int sid;
  double past_cost;
  double heuristic;
  int step_count;

  Elem() = default;
  Elem(int sid, double past_cost, double heuristic, int count)
      : sid(sid), past_cost(past_cost), heuristic(heuristic), step_count(count) {};

  bool operator<(const Elem &o) const {
    double self_cost = past_cost + heuristic;
    double other_cost = o.past_cost + o.heuristic;
    return self_cost > other_cost;
  }
};

// The cost in seconds.
double GetCost(const scheduling_server::MapPoint &p1,
               const scheduling_server::MapPoint &p2) {
  if (p1 == p2) {
    return scheduling_server::kKubotRotationHalfPiTimeMS / scheduling_server::kMillisecondsPerSecond;
  } else {
    return scheduling_server::GetDist(p1.x, p1.y, p2.x, p2.y)
        / scheduling_server::kKubotMoveSpeedMetersPerSecond;
  }
}

double GetHeuristic(const scheduling_server::MapPoint &p1,
                    const scheduling_server::MapPoint &p2) {
  return scheduling_server::GetManhattanDist(p1.x, p1.y, p2.x, p2.y)
      / scheduling_server::kKubotMoveSpeedMetersPerSecond;
}

double GetTravelTimeWithManhattanDist(const scheduling_server::PositionXYT &p1,
                                      const scheduling_server::PositionXYT &p2) {
  return scheduling_server::GetManhattanDist(p1.x, p1.y, p2.x, p2.y)
      / scheduling_server::kKubotMoveSpeedMetersPerSecond
      + (scheduling_server::DoubleEquals(p1.theta, p2.theta) ?
         0 : scheduling_server::kKubotRotationHalfPiTimeMS / scheduling_server::kMillisecondsPerSecond);
}

int FindClosestPathPointIndex(const scheduling_server::PositionXYT &pos,
                              vector<int> path_points, scheduling_server::SsMap *ss_map) {
  double dist = scheduling_server::kDoubleInf;
  int rtn = -1;
  for (int index = 0; index < path_points.size(); index++) {
    const scheduling_server::PositionXYT &p = ss_map->GetPositionBySid(path_points[index]);
    double tmp_dist = scheduling_server::GetDist(p.x, p.y, pos.x, pos.y);
    if (tmp_dist < dist) {
      dist = tmp_dist;
      rtn = index;
    }
  }
  return rtn;
}

}

namespace scheduling_server {
struct LrRequest {
  int robot_id;
  int src_sid;
  int dest_sid;
  bool movable;

  LrRequest(int robot_id, int src_sid, int dest_sid, bool movable)
      : robot_id(robot_id), src_sid(src_sid), dest_sid(dest_sid), movable(movable) {};
};

list<PpResponse> LocalRepairAstar::QueryPath(const list<PpRequest> &requests) {
  lr_lock_.UpdateRobotLastUpdateTime(requests);

  // Make sure all the target_or_current_sid are locked(for the case that a new robot joins).
  for (const PpRequest &req : requests) {
    lr_lock_.LockPathPoint(req.robot_id, req.target_or_current_sid);
  }

  // Free unnecessary reservations base on current position.
  for (const PpRequest &req : requests) {
    const list<int> &tmp_locked_points = lr_lock_.GetLockedPathPoints(req.robot_id);
    vector<int> locked_points(tmp_locked_points.begin(), tmp_locked_points.end());

    // 1. Free future reservations if requested.
    {
      if (req.cancel_future_reservations) {
        lr_lock_.FreePathPointFromSid(req.robot_id, req.target_or_current_sid);
      }
    }

    // 2. Check if the robot is at some point, if yes, then remove all the previous points.
    {
      int target_index;
      for (target_index = 0; target_index < locked_points.size(); target_index++) {
        int sid = locked_points[target_index];
        if (MapPointEquals(req.pos, ss_map_->GetPositionBySid(sid))) {
          break;
        }
      }

      if (target_index != locked_points.size()) {
        for (int index = 0; index < target_index; index++) {
          lr_lock_.FreePathPoint(req.robot_id);
        }
        continue;
      }
    }

    // TODO: find the closest point base on line segment between path points.
    // 3. Find the closest point and remove all points before.
    {
      if (locked_points.size() > 1) {
        int target_index = FindClosestPathPointIndex(req.pos, locked_points, ss_map_);
        for (int index = 0; index < target_index - kLocalRepairAstarBufferSize; index++) {
          lr_lock_.FreePathPoint(req.robot_id);
        }
      }
    }

  }

  if (kDebugMode) {
    for (const PpRequest &req : requests) {
      const list<int> &locked_points = lr_lock_.GetLockedPathPoints(req.robot_id);
      cout << "robot " + to_string(req.robot_id) + " holds: ";
      for (int sid : locked_points) {
        cout << sid << " : ";
      }
      cout << endl;
    }
    cout << endl;
  }

  // Build internal requests.
  list<LrRequest> internal_reqs;
  for (const PpRequest &req : requests) {
    int src_sid, dest_sid;

    src_sid = req.target_or_current_sid;
    if (req.tasks.empty() || req.tasks.front().type != InternalTaskType::MoveTask) {
      dest_sid = src_sid;
    } else {
      // Robot has a target position to move to.
      dest_sid = ss_map_->FindSidByPosition(req.tasks.front().move_task.target_pos);
      if (dest_sid == -1) {
        LOG(LogLevel::error, "Cannot find target point.");
        exit(0);
      }
    }

    bool movable = req.tasks.empty()
        || (req.tasks.front().type == InternalTaskType::MoveTask
            && src_sid != dest_sid
            && lr_lock_.GetLockedPathPointSize(req.robot_id) == 1
            && req.stand_still_time_ms > kPushAfterStandstillMS
        );

    internal_reqs.emplace_back(req.robot_id, src_sid, dest_sid, movable);
  }
  return LRAstar(internal_reqs);
}

list<PpResponse> LocalRepairAstar::LRAstar(list<LrRequest> requests) {
  list<PpResponse> rtn;

  // For robots that have enough planned path points, do nothing.
  for (auto it = requests.begin(); it != requests.end();) {
    if (lr_lock_.GetLockedPathPointSize(it->robot_id) > kLocalRepairAstarReplanLimit) {
      rtn.emplace_back(it->robot_id,
                       kEmptyIntList,
                       it->dest_sid,
                       lr_lock_.GetLockedPathPoints(it->robot_id));
      it = requests.erase(it);
    } else {
      ++it;
    }
  }

  // The first phase, for each robot, call Astar and find a path.
  list<LrRequest> second_phase_reqs;
  for (const auto &req : requests) {
    bool can_reach_dest;
    const list<int> &sids = Astar(req.robot_id, req.src_sid, req.dest_sid, can_reach_dest);

    if (!can_reach_dest && req.movable) {
      second_phase_reqs.push_back(req);
    } else {
      rtn.emplace_back(req.robot_id, sids, req.dest_sid, lr_lock_.GetLockedPathPoints(req.robot_id));
    }
  }

  // The second phase, move to a random adjacent point if the target cannot be reached(a rare case).
  for (const auto &req : second_phase_reqs) {
    if ((rand() % kRandomMoveMod) == 0) {
      const list<int> &sids = GetPathToRandomLocation(req.robot_id, req.src_sid);
      rtn.emplace_back(req.robot_id, sids, req.dest_sid, lr_lock_.GetLockedPathPoints(req.robot_id));
    } else {
      rtn.emplace_back(req.robot_id, kEmptyIntList, req.dest_sid, lr_lock_.GetLockedPathPoints(req.robot_id));
    }
  }

  return rtn;
}

list<int> LocalRepairAstar::GetPathToRandomLocation(int robot_id, int src_sid) {
  // 1. Get all adjacent sids that the robot can move to.
  set<int> candidates;
  queue<int> to_expand;

  to_expand.push(src_sid);

  while (!to_expand.empty()) {
    if (candidates.size() > kPushExpandSetSize) {
      break;
    }

    int cur = to_expand.front();
    to_expand.pop();

    const set<int> &adj_sids = ss_map_->GetAdjSids(cur);
    for (int adj_sid : adj_sids) {
      if (candidates.find(adj_sid) != candidates.end()) {
        continue;
      }

      if (lr_lock_.CanLockPathPoint(robot_id, adj_sid)) {
        candidates.insert(adj_sid);
        to_expand.push(adj_sid);
      }
    }
  }

  // 2. Select an adjacent sid that is not conflicting with the current sid.
  // In future maybe have better strategy on selecting this point.
  int dest_sid = -1;
  for (int tmp_sid : candidates) {
    if (!ss_map_->IsConflict(src_sid, tmp_sid)) {
      dest_sid = tmp_sid;
      break;
    }
  }

  // 3. Return the shortest path from source to dest.
  if (dest_sid == -1) {
    return {};
  } else {
    bool can_reach_dest;
    auto rtn = Astar(robot_id, src_sid, dest_sid, can_reach_dest);
    assert(can_reach_dest);
    return rtn;
  }
}

list<int> LocalRepairAstar::Astar(int robot_id,
                                  int src_sid,
                                  int dest_sid,
                                  bool &can_reach_dest) {
  set<int> visited;
  priority_queue<Elem> elements;
  int depth_counter = 0;

  elements.push(Elem(src_sid, 0, GetHeuristic(
      ss_map_->GetMapPointBySid(src_sid), ss_map_->GetMapPointBySid(dest_sid)), 0));
  visited.insert(src_sid);
  Elem current_elem;

  while (!elements.empty()) {
    current_elem = elements.top();
    elements.pop();
    ++depth_counter;

    if (current_elem.sid == dest_sid) {
      break;
    }

    if (depth_counter > kLocalRepairAstarDepthLimit) {
      break;
    }

    // Expand.
    const set<int> &adj_sids = ss_map_->GetAdjSids(current_elem.sid);
    for (int adj_sid : adj_sids) {
      if (visited.find(adj_sid) != visited.end()) {
        continue;
      }

      // For points far away, do not consider conflict.
      // TODO: may use another mode when the robot is close to the operation center.
      if (current_elem.past_cost < kConflictWindowSeconds
          && (!lr_lock_.CanLockPathPoint(robot_id, adj_sid))) {
        continue;
      }

      visited.insert(adj_sid);
      prev_[adj_sid] = current_elem.sid;
      // TODO: consider implement the calculations here as map lookup, to save some computation.
      elements.emplace(adj_sid,
                       current_elem.past_cost + GetCost(
                           ss_map_->GetMapPointBySid(current_elem.sid),
                           ss_map_->GetMapPointBySid(adj_sid)),
                       GetHeuristic(ss_map_->GetMapPointBySid(adj_sid),
                                    ss_map_->GetMapPointBySid(dest_sid)),
                       current_elem.step_count + 1);
    }
  }

  can_reach_dest = current_elem.sid == dest_sid;
  if (!can_reach_dest) {
    return {};
  }

  // Generate path. Lock path points.
  vector<int> tmp_rtn;
  int cur = current_elem.sid;
  while (cur != src_sid) {
    tmp_rtn.push_back(cur);
    cur = prev_[cur];
  }

  reverse(tmp_rtn.begin(), tmp_rtn.end());

  int points_to_lock = kLocalRepairAstarLockLimit - lr_lock_.GetLockedPathPointSize(robot_id);
  list<int> rtn;
  for (int i = 0; i < tmp_rtn.size() && i < points_to_lock; ++i) {
    int sid_to_lock = tmp_rtn[i];
    if (!lr_lock_.LockPathPoint(robot_id, sid_to_lock)) {
      break;
    }
    rtn.push_back(sid_to_lock);
  }
  return rtn;
}

// TODO: sort base on some heuristic.
void LocalRepairAstar::SortRobots(list<LrRequest> &requests) {
  // Sort the robots, find path for each.
  // Add some randomness to help to break dead lock/live lock.
  return;
}

bool LRLock::LockPathPoint(int robot_id, int path_point) {
  if (!CanLockPathPoint(robot_id, path_point)) {
    return false;
  }

  // Lock the path point.
  robot_to_locked_path_point_[robot_id].push_back(path_point);

  // Lock adjacent points.
  for (int sid : ss_map_->GetSidsToLock(path_point)) {
    sid_to_robot_set_[sid].insert(robot_id);
  }
  return true;
}

bool LRLock::CanLockPathPoint(int robot_id, int path_point) {
  // If the path point is already locked by the robot itself, return false.
  const list<int> &locked_points = robot_to_locked_path_point_[robot_id];
  for (int v : locked_points) {
    if (v == path_point) {
      return false;
    }
  }

  // If the path point in sid_to_robot_set_ is locked by other robots, return false.
  if (sid_to_robot_set_[path_point].count(robot_id) != sid_to_robot_set_[path_point].size()) {
    return false;
  }

  return true;
}

void LRLock::FreeAllPathPoint(int robot_id) {
  while (!robot_to_locked_path_point_[robot_id].empty()) {
    FreePathPoint(robot_id);
  }
  robot_to_locked_path_point_.erase(robot_id);
}

void LRLock::FreePathPoint(int robot_id) {
  if (robot_to_locked_path_point_[robot_id].empty()) {
    LOG(LogLevel::error, "Tries to free a path point which was not locked.");
    exit(0);
  }

  int sid_to_free = robot_to_locked_path_point_[robot_id].front();
  robot_to_locked_path_point_[robot_id].pop_front();
  FreeLockedPointInSidToRobotSet(robot_id, sid_to_free);
}

void LRLock::FreePathPointFromSid(int robot_id, int path_point) {
  cout << "handling cancel for robot " << to_string(robot_id) << endl;
  while (robot_to_locked_path_point_[robot_id].back() != path_point) {
    int sid_to_free = robot_to_locked_path_point_[robot_id].back();
    robot_to_locked_path_point_[robot_id].pop_back();
    FreeLockedPointInSidToRobotSet(robot_id, sid_to_free);
  }

  if (robot_to_locked_path_point_[robot_id].empty()) {
    LOG(LogLevel::error, "Invalid state, a robot should have at least one reservation.");
    exit(0);
  }
}

void LRLock::FreeLockedPointInSidToRobotSet(int robot_id, int path_point) {
  for (int sid : ss_map_->GetSidsToLock(path_point)) {
    auto it = sid_to_robot_set_[sid].find(robot_id);
    if (it == sid_to_robot_set_[sid].end()) {
      LOG(LogLevel::error, "Tries to free a sid which was not locked.");
      exit(0);
    }
    sid_to_robot_set_[sid].erase(it);
  }
}

int LRLock::GetLockedPathPointSize(int robot_id) {
  return robot_to_locked_path_point_[robot_id].size();
}

const list<int> &LRLock::GetLockedPathPoints(int robot_id) const {
  return robot_to_locked_path_point_.at(robot_id);
}

void LRLock::UpdateRobotLastUpdateTime(const std::list<PpRequest> &reqs) {
  for (const PpRequest &req : reqs) {
    robot_to_last_update_time_[req.robot_id] = GetCurrentTimeSinceEpochMS();
  }

  // Remove a robot if it was not updated for kRobotStateShouldBeRemovedMSecs.
  for (auto it = robot_to_last_update_time_.cbegin(); it != robot_to_last_update_time_.cend();) {
    if (IsElapsedTimeLongerThan(it->second, kRobotStateShouldBeRemovedMSecs)) {
      FreeAllPathPoint(it->first);
      it = robot_to_last_update_time_.erase(it);
      LOG(LogLevel::info, "Removed a robot from path_planner.");
    } else {
      ++it;
    }
  }
}

}