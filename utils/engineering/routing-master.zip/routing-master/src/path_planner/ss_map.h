#ifndef SS_MAP_H
#define SS_MAP_H

#include <algorithm>
#include <cmath>
#include <list>
#include <map>
#include <set>
#include <string>
#include <stdexcept>
#include <vector>

#include "position.h"
#include "ss_constants.h"
#include "util/ss_util.h"

namespace scheduling_server {

enum class RotationType : int {
  TYPE_I = 0,
  TYPE_II = 1,
};

// There are two types of point, map point and state point.
// Data structures for MapPointSet.
struct XIndexElem {
  double x;
  int mid;

  XIndexElem(double x, int mid) : x(x), mid(mid) {};

  bool operator<(const XIndexElem &other) const {
    return x < other.x;
  }
};

struct YIndexElem {
  double y;
  int mid;

  YIndexElem(double y, int mid) : y(y), mid(mid) {};
  bool operator<(const YIndexElem &other) const {
    return y < other.y;
  }
};

struct MapPoint {
  double x, y;
  int tunnel_id;

  MapPoint(double x, double y, int tunnel_id)
      : x(x), y(y), tunnel_id(tunnel_id) {};

  bool operator==(const MapPoint &rhs) const {
    return scheduling_server::DoubleEquals(x, rhs.x) && scheduling_server::DoubleEquals(y, rhs.y);
  };

  std::string ToString() const {
    return std::to_string(x) + " " + std::to_string(y);
  }
};

class MapPointSet {
 public:
  MapPointSet() = default;

  void AddPoint(double x, double y, int tunnel_id) {
    int mid = map_points_.size();
    map_points_.emplace_back(x, y, tunnel_id);
    x_index_.emplace_back(x, mid);
    y_index_.emplace_back(y, mid);
    sort(x_index_.begin(), x_index_.end());
    sort(y_index_.begin(), y_index_.end());
  };

  // Returns the id of a map point to (x,y) in
  // [x - delta, x + delta], [y - delta, y + delta].
  int FindClosestMapPoint(double x, double y) const;
  int FindClosestMapPointWithinRange(double x, double y, double epsilon) const;
  std::set<int> FindMapPointsWithinRange(double x, double y, double epsilon) const;

  const MapPoint &GetPoint(int mid) const {
    if (mid >= map_points_.size()) {
      throw std::runtime_error("Map point id out of range.");
    }
    return map_points_[mid];
  }

  int GetMapPointCount() const {
    return map_points_.size();
  }

  std::vector<MapPoint> map_points_;
  std::vector<XIndexElem> x_index_;
  std::vector<YIndexElem> y_index_;
};

// Date structures for state points.
struct StatePoint {
  int mid;
  double theta;

  StatePoint(int mid, double theta) : mid(mid), theta(theta) {};
};

// Vertexes in state point graph are state points.
//
// There will be an edge between two vertexes if it is possible to transfer from
// one corresponding state point to another.
class StatePointGraph {
 public:
  StatePointGraph() = default;

  // Get the sid of a state point. If the state point doesn't exist, create one.
  int GetOrCreateStatePointId(int mid, double theta);
  int GetStatePointId(int mid, double theta) const;

  const StatePoint &GetStatePoint(int sid) const;
  int GetMidBySid(int sid) const { return state_points_[sid].mid; };

  // Add an edge between two sids.
  void AddEdge(int sid0, int sid1);

  // Get all the sids associated with a mid.
  const std::set<int> &GetSidsFromMid(int mid) const;

  // Get all the adjacent sids for an sid.
  const std::set<int> &GetAdjSids(int sid) const;

  void ResizeMidVector(int map_point_count) {
    mid_to_sid_.resize(map_point_count);
  }

  int GetStatePointCount() const {
    return state_points_.size();
  }

  // Helper functions.
  bool ThetaEquals(double a, double b) const {
    return std::abs(a - b) <= kThetaEpsilon;
  }

  // Data.
  std::vector<StatePoint> state_points_;
  std::vector<std::set<int>> mid_to_sid_;
  std::map<int, std::set<int>> adj_list_;
};

class SsMap {
 public:
  SsMap() = default;

  // Loads map file, the map is represented in adjacent list.
  void LoadMap(const std::string &);

  int FindClosestMapPointWithinRange(double x, double y, double epsilon) const {
    return map_point_set_.FindClosestMapPointWithinRange(x, y, epsilon);
  };

  int FindSidByPosition(const PositionXYT &p);

  // Gets the map point corresponds to the input state id.
  const MapPoint &GetMapPointBySid(int sid) const {
    return GetMapPointByMid(GetMidFromSid(sid));
  };

  const MapPoint &GetMapPointByMid(int mid) const {
    return map_point_set_.GetPoint(mid);
  };

  const std::set<int> &GetAdjSids(int sid) {
    return state_point_graph_.GetAdjSids(sid);
  };

  int GetMidFromSid(int sid) const { return state_point_graph_.GetMidBySid(sid); };

  PositionXYT GetPositionBySid(int sid) const;

  double GetDistBetweenSids(int sid_a, int sid_b) const;
  double GetDistBetweenMids(int mid_a, int mid_b) const;
  bool InFirstOrThirdQuadrant(int mid_a, int mid_b) const;
  bool InSecondOrFourthQuadrant(int mid_a, int mid_b) const;

  bool IsConflict(int sid_a, int sid_b) const;

  std::set<int> GetSidsToLock(int to_sid) const;
  std::set<int> GetSidsToLock(int from_sid, int to_sid) const;

  int GetStatePointCount() { return state_point_graph_.GetStatePointCount(); };

  // Should be private, for test only, use other public APIs.
  MapPointSet map_point_set_;
  StatePointGraph state_point_graph_;

 private:
  // Helper functions.
  // Get the car direction(in theta) if the car moves from source to destination.
  // For now theta should only be (
  //    0(x positive direction),
  //    pi/2(y positive direction),
  //    -pi/2(y negative direction),
  //    pi(x negative direction)
  // ).
  double GetTheta(double sx, double sy, double dx, double dy);
  std::set<PositionXY> GetCornerPoints(int sid) const;
  RotationType GetRotationType(const PositionXYT &from, const PositionXYT &to);

  void BuildSidLockMap();
  void BuildRotationLockMap();

  std::vector<std::set<int>> sid_to_sids_to_lock_;
  std::map<std::pair<int, int>, std::set<int>> rotation_to_sids_to_lock_;
  std::set<PositionXY> corner_points_horizontal_;
  std::set<PositionXY> corner_points_vertical_;
};

}

#endif