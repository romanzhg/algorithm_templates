#include "ss_map.h"

#include <fstream>
#include <vector>
#include <set>

#include "ss_constants.h"
#include "util/ss_util.h"

using namespace std;

namespace {

// Returns true if the diff between two theta is smaller than kPi/2(with a 0.5% allowance).
bool IsThetaNear(double t1, double t2) {
  double dist = scheduling_server::GetThetaDist(t1, t2);
  return dist < (scheduling_server::kHalfPi * 1.05);
}

int GetThetaIndex(double t) {
  if (abs(t - scheduling_server::kDirectionRight) < scheduling_server::kThetaEpsilon) {
    return 0;
  } else if (abs(t - scheduling_server::kDirectionUp) < scheduling_server::kThetaEpsilon) {
    return 1;
  } else if (abs(t - scheduling_server::kDirectionLeft) < scheduling_server::kThetaEpsilon) {
    return 2;
  } else if (abs(t - scheduling_server::kDirectionDown) < scheduling_server::kThetaEpsilon) {
    return 3;
  } else {
    throw std::runtime_error("Invalid theta.");
  }
}

}

namespace scheduling_server {

int MapPointSet::FindClosestMapPoint(double x, double y) const {
  return FindClosestMapPointWithinRange(x, y, kMapPointEpsilon);
}

int MapPointSet::FindClosestMapPointWithinRange(double x, double y, double epsilon) const {
  const set<int> &candidates = FindMapPointsWithinRange(x, y, epsilon);

  int rtn = -1;
  double dist = kDoubleInf;
  for (int candidate : candidates) {
    double tmp = GetDist(x, y, map_points_[candidate].x, map_points_[candidate].y);
    if (tmp < dist) {
      dist = tmp;
      rtn = candidate;
    }
  }
  return rtn;
}

set<int> MapPointSet::FindMapPointsWithinRange(double x, double y, double epsilon) const {
  auto xStart = lower_bound(x_index_.begin(), x_index_.end(), XIndexElem(x - epsilon, 0));
  auto xEnd = upper_bound(x_index_.begin(), x_index_.end(), XIndexElem(x + epsilon, 0));
  set<int> filtered_by_x;
  for (auto it = xStart; it != xEnd; it++) {
    filtered_by_x.insert(it->mid);
  }

  auto yStart = lower_bound(y_index_.begin(), y_index_.end(), YIndexElem(y - epsilon, 0));
  auto yEnd = upper_bound(y_index_.begin(), y_index_.end(), YIndexElem(y + epsilon, 0));
  set<int> filtered_by_y;
  for (auto it = yStart; it != yEnd; it++) {
    filtered_by_y.insert(it->mid);
  }

  // Get intersection.
  set<int> candidates;
  for (int id : filtered_by_x) {
    if (filtered_by_y.find(id) != filtered_by_y.end()) {
      candidates.insert(id);
    }
  }

  return candidates;
}

void StatePointGraph::AddEdge(int sid0, int sid1) {
  adj_list_[sid0].insert(sid1);
}

int StatePointGraph::GetOrCreateStatePointId(int mid, double theta) {
  const set<int> &sids = mid_to_sid_[mid];
  for (int sid : sids) {
    if (ThetaEquals(theta, state_points_[sid].theta)) {
      return sid;
    }
  }
  int new_sid = state_points_.size();
  state_points_.emplace_back(mid, theta);
  mid_to_sid_[mid].insert(new_sid);
  return new_sid;
}

int StatePointGraph::GetStatePointId(int mid, double theta) const {
  const set<int> &sids = mid_to_sid_[mid];
  for (int sid : sids) {
    if (ThetaEquals(theta, state_points_[sid].theta)) {
      return sid;
    }
  }
  return -1;
}

const set<int> &StatePointGraph::GetAdjSids(int sid) const {
  return adj_list_.at(sid);
}

const set<int> &StatePointGraph::GetSidsFromMid(int mid) const {
  return mid_to_sid_[mid];
}

const StatePoint &StatePointGraph::GetStatePoint(int sid) const {
  return state_points_[sid];
}

double SsMap::GetTheta(double sx, double sy, double dx, double dy) {
  bool x_equals = DoubleEquals(sx, dx);
  bool y_equals = DoubleEquals(sy, dy);
  if (x_equals && y_equals) {
    throw runtime_error("Error in the input adjacent list, a point is said to be adjacent to itself.");
  }
  if (!x_equals && !y_equals) {
    throw runtime_error("Current version of path planner only support rectangular girds.");
  }
  if (x_equals) {
    // x equals and y differs.
    if (sy < dy) {
      return kDirectionUp;
    } else {
      return kDirectionDown;
    }
  } else {
    // y equals and x differs.
    if (sx < dx) {
      return kDirectionRight;
    } else {
      return kDirectionLeft;
    }
  }
}

void SsMap::LoadMap(const string &file_path) {
  ifstream input(file_path);
  if (!input) {
    throw runtime_error("Could not open map file.");
  }

  vector<string> buffer;
  string tmp_line;
  while (getline(input, tmp_line)) {
    if (tmp_line[0] == '#') {
      // Skip comments.
      continue;
    }
    buffer.push_back(tmp_line);
  }
  input.close();

  // 1. The first phase, get all map points and their tunnel id.
  for (const string &line : buffer) {
    vector<string> vertex_and_adj = scheduling_server::StrSplit(line, ':');

    if (vertex_and_adj.size() != 2) {
      throw std::runtime_error("Adjacent list parse error 0.");
    }

    vector<string> source_point_split = scheduling_server::StrSplit(vertex_and_adj[0], ',');
    if (source_point_split.size() != 3) {
      throw std::runtime_error("Adjacent list parse error 1.");
    }

    double x = stod(source_point_split[0]);
    double y = stod(source_point_split[1]);
    int tunnel_id = stoi(source_point_split[2]);
    map_point_set_.AddPoint(x, y, tunnel_id);
  }

  state_point_graph_.ResizeMidVector(map_point_set_.GetMapPointCount());

  // 2. The second phase, add state point and edges according to the map point adjacency.
  for (const string &line : buffer) {
    vector<string> vertex_and_adj = scheduling_server::StrSplit(line, ':');
    if (vertex_and_adj.size() != 2) {
      throw std::runtime_error("Adjacent list parse error 2.");
    }

    vector<string> source_point_split = scheduling_server::StrSplit(vertex_and_adj[0], ',');
    if (source_point_split.size() != 3) {
      throw std::runtime_error("Adjacent list parse error 3.");
    }

    double sx = stod(source_point_split[0]);
    double sy = stod(source_point_split[1]);
    int s_mid = map_point_set_.FindClosestMapPoint(sx, sy);

    vector<string> dest_point_list;
    scheduling_server::StrSplit(vertex_and_adj[1], ';', dest_point_list);
    for (const string &dest_point : dest_point_list) {
      vector<string> dest_point_split = scheduling_server::StrSplit(dest_point, ',');
      if (dest_point_split.size() != 2) {
        throw std::runtime_error("Destination point parse error.");
      }
      double dx = stod(dest_point_split[0]);
      double dy = stod(dest_point_split[1]);
      int d_mid = map_point_set_.FindClosestMapPoint(dx, dy);

      // Build the state point at source and destination.
      double theta = GetTheta(sx, sy, dx, dy);

      int sid_source = state_point_graph_.GetOrCreateStatePointId(s_mid, theta);
      int sid_dest = state_point_graph_.GetOrCreateStatePointId(d_mid, theta);

      state_point_graph_.AddEdge(sid_source, sid_dest);
      // Kubot can go backward, add an edge from dest to source.
      state_point_graph_.AddEdge(sid_dest, sid_source);
    }
  }

  // 3. The third phase, add edges between the state points associated with the same map point.
  int total_map_points = map_point_set_.GetMapPointCount();
  for (int mid = 0; mid < total_map_points; mid++) {
    set<int> tmp_sids = state_point_graph_.GetSidsFromMid(mid);
    vector<int> sids(tmp_sids.begin(), tmp_sids.end());
    for (int i = 0; i < sids.size(); i++) {
      for (int j = i + 1; j < sids.size(); j++) {
        int source_sid = sids[i];
        int dest_sid = sids[j];
        const StatePoint &p0 = state_point_graph_.GetStatePoint(source_sid);
        const StatePoint &p1 = state_point_graph_.GetStatePoint(dest_sid);

        if (IsThetaNear(p0.theta, p1.theta)) {
          state_point_graph_.AddEdge(source_sid, dest_sid);
          state_point_graph_.AddEdge(dest_sid, source_sid);
        }
      }
    }
  }

  // 4. Remove edge/sid/mid.
  ifstream ifs;
  ifs.open(kMapModifierFilePath);
  if (ifs.fail()) {
    throw runtime_error("Failed to load map_modifier.json.");
  }

  nlohmann::json map_modifier_json;
  ifs >> map_modifier_json;

  if (map_modifier_json.contains("edgesToRemove")) {
    for (const auto &edges_to_remove : map_modifier_json["edgesToRemove"]) {
      int from_sid = FindSidByPosition(PositionXYT(edges_to_remove["fromPos"]));
      int to_sid = FindSidByPosition(PositionXYT(edges_to_remove["toPos"]));
      if (state_point_graph_.adj_list_[from_sid].find(to_sid)
          == state_point_graph_.adj_list_[from_sid].end()) {
        throw runtime_error("Invalid edge to remove.");
      } else {
        state_point_graph_.adj_list_[from_sid].erase(to_sid);
      }
    }
  }

  if (map_modifier_json.contains("sidsToRemove")) {
    for (int sid_to_remove : map_modifier_json["sidsToRemove"]) {

    }
  }

  if (map_modifier_json.contains("midsToRemove")) {
    for (int mid_to_remove : map_modifier_json["midsToRemove"]) {

    }
  }

  // 5. Build the corner point of a robot, and compute the sid lock map.
  corner_points_horizontal_.insert(PositionXY(kKubotLength / 2, kKubotWidth / 2));
  corner_points_horizontal_.insert(PositionXY(kKubotLength / 2, -kKubotWidth / 2));
  corner_points_horizontal_.insert(PositionXY(-kKubotLength / 2, -kKubotWidth / 2));
  corner_points_horizontal_.insert(PositionXY(-kKubotLength / 2, kKubotWidth / 2));

  corner_points_vertical_.insert(PositionXY(kKubotWidth / 2, kKubotLength / 2));
  corner_points_vertical_.insert(PositionXY(kKubotWidth / 2, -kKubotLength / 2));
  corner_points_vertical_.insert(PositionXY(-kKubotWidth / 2, -kKubotLength / 2));
  corner_points_vertical_.insert(PositionXY(-kKubotWidth / 2, kKubotLength / 2));

  BuildSidLockMap();

  // 6. Build rotation related locks.
  BuildRotationLockMap();

  // 7. Lock tunnels if requested.
  if (map_modifier_json.contains("tunnelsToLock")) {
    for (int tunnel_to_lock : map_modifier_json["tunnelsToLock"]) {
      set<int> mid_set;
      for (int index = 0; index < map_point_set_.map_points_.size(); index++) {
        if (map_point_set_.map_points_[index].tunnel_id == tunnel_to_lock) {
          mid_set.insert(index);
        }
      }

      set<int> sid_set;
      for (int mid : mid_set) {
        const auto &tmp = state_point_graph_.GetSidsFromMid(mid);
        sid_set.insert(tmp.begin(), tmp.end());
      }

      for (int sid : sid_set) {
        sid_to_sids_to_lock_[sid].insert(sid_set.begin(), sid_set.end());
      }
    }
  }
}

int SsMap::FindSidByPosition(const PositionXYT &p) {
  int mid = map_point_set_.FindClosestMapPoint(p.x, p.y);
  if (mid == -1) {
    return -1;
  }
  int sid = state_point_graph_.GetStatePointId(mid, p.theta);
  return sid;
}

PositionXYT SsMap::GetPositionBySid(int sid) const {
  const StatePoint &sp = state_point_graph_.GetStatePoint(sid);
  const MapPoint &mp = map_point_set_.GetPoint(sp.mid);
  return PositionXYT(mp.x, mp.y, sp.theta);
}

double SsMap::GetDistBetweenSids(int sid_a, int sid_b) const {
  PositionXYT pa = GetPositionBySid(sid_a);
  PositionXYT pb = GetPositionBySid(sid_b);
  return GetDist(pa.x, pa.y, pb.x, pb.y);
}

// TODO: only use this this function for maps that has this type of collisions.
set<int> SsMap::GetSidsToLock(int from_sid, int to_sid) const {
  set<int> rtn;
  rtn = sid_to_sids_to_lock_[to_sid];
  if (from_sid != -1) {
    if (kDebugMode) {
      const auto &tmp = state_point_graph_.GetAdjSids(from_sid);
      assert(tmp.find(to_sid) != tmp.end());
    }
    if (IsRotateTransition(GetPositionBySid(from_sid), GetPositionBySid(to_sid))) {
      const set<int> &tmp = rotation_to_sids_to_lock_.at({from_sid, to_sid});
      rtn.insert(tmp.begin(), tmp.end());
    }
  }
  return rtn;
}

std::set<int> SsMap::GetSidsToLock(int to_sid) const {
  return sid_to_sids_to_lock_[to_sid];
}

set<PositionXY> SsMap::GetCornerPoints(int sid) const {
  set<PositionXY> std_corner;
  int theta_index = GetThetaIndex(state_point_graph_.GetStatePoint(sid).theta);
  if (theta_index == 0 || theta_index == 2) {
    std_corner = corner_points_horizontal_;
  } else {
    // theta_index == 1 || theta_index == 3
    std_corner = corner_points_vertical_;
  }

  set<PositionXY> rtn;
  const MapPoint &mp = GetMapPointBySid(sid);
  for (const PositionXY &ref : std_corner) {
    rtn.insert(PositionXY(ref.x + mp.x, ref.y + mp.y));
  }
  return rtn;
}

bool SsMap::IsConflict(int sid_a, int sid_b) const {
  const set<PositionXY> &corners_a = GetCornerPoints(sid_a);
  set<PositionXY> corners_and_center_b = GetCornerPoints(sid_b);

  const MapPoint &mp_b = GetMapPointBySid(sid_b);
  corners_and_center_b.insert(PositionXY(mp_b.x, mp_b.y));

  double a_max_x = -kDoubleInf;
  double a_min_x = kDoubleInf;
  double a_max_y = -kDoubleInf;
  double a_min_y = kDoubleInf;

  for (const PositionXY &corner : corners_a) {
    a_max_x = max(a_max_x, corner.x);
    a_min_x = min(a_min_x, corner.x);
    a_max_y = max(a_max_y, corner.y);
    a_min_y = min(a_min_y, corner.y);
  }

  for (const PositionXY &point : corners_and_center_b) {
    if (point.x <= a_max_x
        && point.x >= a_min_x
        && point.y <= a_max_y
        && point.y >= a_min_y) {
      return true;
    }
  }
  return false;
}

void SsMap::BuildSidLockMap() {
  sid_to_sids_to_lock_.resize(state_point_graph_.GetStatePointCount());
  for (int sid = 0; sid < state_point_graph_.GetStatePointCount(); sid++) {
    // 1. Get mids within a range.
    // 2. For each sid associated with the mids, check if there would be a conflict.
    // And add the conflict points to the lock table.
    const MapPoint &mp = GetMapPointBySid(sid);

    const set<int> &candidates = map_point_set_.FindMapPointsWithinRange(
        mp.x, mp.y, kAdjMapPointRange);
    for (int mid : candidates) {
      const set<int> &candidate_sids = state_point_graph_.GetSidsFromMid(mid);
      for (int adj_sid : candidate_sids) {
        if (IsConflict(sid, adj_sid)) {
          sid_to_sids_to_lock_[sid].insert(adj_sid);
        }
      }
    }
  }
}

void SsMap::BuildRotationLockMap() {
  for (int src_sid = 0; src_sid < state_point_graph_.GetStatePointCount(); src_sid++) {
    const set<int> &adj_sids = state_point_graph_.adj_list_[src_sid];
    int src_mid = GetMidFromSid(src_sid);
    const set<int> &mids_near_by = map_point_set_.FindMapPointsWithinRange(
        map_point_set_.GetPoint(src_mid).x,
        map_point_set_.GetPoint(src_mid).y,
        kKubotRotationDiameter
    );

    for (int dest_sid : adj_sids) {
      if (IsRotateTransition(GetPositionBySid(src_sid), GetPositionBySid(dest_sid))) {
        for (int mid : mids_near_by) {
          RotationType type = GetRotationType(GetPositionBySid(src_sid), GetPositionBySid(dest_sid));
          switch (type) {
            case RotationType::TYPE_I:
              if (InFirstOrThirdQuadrant(src_mid, mid)
                  && GetDistBetweenMids(src_mid, mid) < kKubotRotationDiameter) {
                const auto &tmp = state_point_graph_.GetSidsFromMid(mid);
                rotation_to_sids_to_lock_[make_pair(src_sid, dest_sid)].insert(tmp.begin(), tmp.end());
              }
              break;
            case RotationType::TYPE_II:
              if (InSecondOrFourthQuadrant(src_mid, mid)
                  && GetDistBetweenMids(src_mid, mid) < kKubotRotationDiameter) {
                const auto &tmp = state_point_graph_.GetSidsFromMid(mid);
                rotation_to_sids_to_lock_[make_pair(src_sid, dest_sid)].insert(tmp.begin(), tmp.end());
              }
              break;
            default:exit(0);
          }
        }
      }
    }
  }
}

RotationType SsMap::GetRotationType(const PositionXYT &from, const PositionXYT &to) {
  if (DoubleEquals(from.theta, kDirectionRight)) {
    if (DoubleEquals(to.theta, kDirectionUp)) {
      return RotationType::TYPE_I;
    } else if (DoubleEquals(to.theta, kDirectionDown)) {
      return RotationType::TYPE_II;
    }
  } else if (DoubleEquals(from.theta, kDirectionUp)) {
    if (DoubleEquals(to.theta, kDirectionLeft)) {
      return RotationType::TYPE_II;
    } else if (DoubleEquals(to.theta, kDirectionRight)) {
      return RotationType::TYPE_I;
    }
  } else if (DoubleEquals(from.theta, kDirectionLeft)) {
    if (DoubleEquals(to.theta, kDirectionUp)) {
      return RotationType::TYPE_II;
    } else if (DoubleEquals(to.theta, kDirectionDown)) {
      return RotationType::TYPE_I;
    }
  } else if (DoubleEquals(from.theta, kDirectionDown)) {
    if (DoubleEquals(to.theta, kDirectionLeft)) {
      return RotationType::TYPE_I;
    } else if (DoubleEquals(to.theta, kDirectionRight)) {
      return RotationType::TYPE_II;
    }
  }
  // Invalid state.
  exit(0);
}

double SsMap::GetDistBetweenMids(int mid_a, int mid_b) const {
  const auto &a = map_point_set_.GetPoint(mid_a);
  const auto &b = map_point_set_.GetPoint(mid_b);
  return GetDist(a.x, a.y, b.x, b.y);
}

bool SsMap::InFirstOrThirdQuadrant(int mid_a, int mid_b) const {
  const auto &a = map_point_set_.GetPoint(mid_a);
  const auto &b = map_point_set_.GetPoint(mid_b);
  if (DoubleLargerThan(b.x, a.x) && DoubleLargerThan(b.y, a.y)) {
    return true;
  }
  if (DoubleSmallerThan(b.x, a.x) && DoubleSmallerThan(b.y, a.y)) {
    return true;
  }
  return false;
}

bool SsMap::InSecondOrFourthQuadrant(int mid_a, int mid_b) const {
  const auto &a = map_point_set_.GetPoint(mid_a);
  const auto &b = map_point_set_.GetPoint(mid_b);
  if (DoubleLargerThan(b.x, a.x) && DoubleSmallerThan(b.y, a.y)) {
    return true;
  }
  if (DoubleSmallerThan(b.x, a.x) && DoubleLargerThan(b.y, a.y)) {
    return true;
  }
  return false;
}

}