#include "path_planner/ss_map.h"

#include <iostream>

#include "gtest/gtest.h"

using namespace scheduling_server;
using namespace std;

namespace {
class MapTestSixPoints : public ::testing::Test {
 protected:
  MapTestSixPoints() {

  }

  ~MapTestSixPoints() override {
  }

  void SetUp() override {
    ss_map_ = new SsMap();
    ss_map_->LoadMap("../data/test2_6/adjacency_list.in");
  }

  void TearDown() override {
    delete ss_map_;
  }

  SsMap *ss_map_;
};

TEST_F(MapTestSixPoints, Basic) {
  // 6 map points.
  EXPECT_EQ(ss_map_->map_point_set_.GetMapPointCount(), 6);

  // Point (2,2) is the 5th point with mid 4.
  EXPECT_EQ(ss_map_->map_point_set_.FindClosestMapPoint(2.000001, 2), 4);

  // 24 state points.
  EXPECT_EQ(ss_map_->state_point_graph_.GetStatePointCount(), 24);

  // The state point (2,2,-kPi/2) (points down) should have 3 adjacent points.
  int sid = ss_map_->state_point_graph_.GetStatePointId(4, -kPi / 2);
  EXPECT_EQ(ss_map_->state_point_graph_.GetAdjSids(sid).size(), 3);
}

class MapTestMapEv : public ::testing::Test {
 protected:
  MapTestMapEv() {

  }

  ~MapTestMapEv() override {
  }

  void SetUp() override {
    ss_map_ = new SsMap();
    ss_map_->LoadMap("../data/ev/adjacency_list.in");
  }

  void TearDown() override {
    delete ss_map_;
  }

  SsMap *ss_map_;
};

TEST_F(MapTestMapEv, Basic) {
  EXPECT_EQ(ss_map_->map_point_set_.GetMapPointCount(), 1128);
  EXPECT_EQ(ss_map_->state_point_graph_.GetStatePointCount(), 2386);
}

TEST_F(MapTestMapEv, SidConflictList) {

  {
    double x = 43.770;
    double y = 29.990;
    int cur_sid = ss_map_->FindSidByPosition(PositionXYT(x, y, kDirectionRight));
    const set<int>& conflict_sids = ss_map_->GetSidsToLock(cur_sid);
    for (int sid : conflict_sids) {
      cout << "conflict position: " << ss_map_->GetPositionBySid(sid).ToString() << endl;
    }
    cout << endl;
  }

  {
    double x = 46.753;
    double y = 25.15;
    int cur_sid = ss_map_->FindSidByPosition(PositionXYT(x, y, kDirectionRight));
    const set<int>& conflict_sids = ss_map_->GetSidsToLock(cur_sid);
    for (int sid : conflict_sids) {
      cout << "conflict position: " << ss_map_->GetPositionBySid(sid).ToString() << endl;
    }
    cout << endl;
  }

  {
    double x = 22.718;
    double y = 22.73;
    int cur_sid = ss_map_->FindSidByPosition(PositionXYT(x, y, kDirectionRight));
    const set<int>& conflict_sids = ss_map_->GetSidsToLock(cur_sid);
    for (int sid : conflict_sids) {
      cout << "conflict position: " << ss_map_->GetPositionBySid(sid).ToString() << endl;
    }
    cout << endl;
  }
}


class MapTestMap6060 : public ::testing::Test {
 protected:
  MapTestMap6060() {

  }

  ~MapTestMap6060() override {
  }

  void SetUp() override {
    ss_map_ = new SsMap();
    ss_map_->LoadMap("../data/test60_60/adjacency_list.in");
  }

  void TearDown() override {
    delete ss_map_;
  }

  SsMap *ss_map_;
};

TEST_F(MapTestMap6060, Basic) {
  {
    int mid = ss_map_->FindClosestMapPointWithinRange(30.1, 30.1, 0.3);
    MapPoint mp = ss_map_->GetMapPointByMid(mid);
    EXPECT_EQ(mp, MapPoint(30, 30, 0));
  }

  {
    int mid = ss_map_->FindClosestMapPointWithinRange(38.1, 30.1, 5);
    MapPoint mp = ss_map_->GetMapPointByMid(mid);
    EXPECT_EQ(mp, MapPoint(38, 30, 0));
  }
}

TEST_F(MapTestMap6060, SidConflictList) {
  double x = 30;
  double y = 30;

  int cur_sid = ss_map_->FindSidByPosition(PositionXYT(x, y, kDirectionRight));
  const set<int>& conflict_sids = ss_map_->GetSidsToLock(cur_sid);
  for (int sid : conflict_sids) {
    cout << "conflict position: " << ss_map_->GetPositionBySid(sid).ToString() << endl;
  }
}

}

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
