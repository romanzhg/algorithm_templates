#include "path_planner/local_repair_astar.h"

#include <list>

#include "gtest/gtest.h"

using namespace scheduling_server;
using namespace std;

namespace {
class FindPathTest : public ::testing::Test {
 protected:
  FindPathTest() {
  }

  ~FindPathTest() override {
  }

  void SetUp() override {
    ss_map_ = new SsMap();
    ss_map_->LoadMap("../data/test2_6/adjacency_list.in");
    ppi_ = new LocalRepairAstar(ss_map_);
  }

  void TearDown() override {
    delete ss_map_;
  }

  SsMap *ss_map_;
  PathPlannerInterface *ppi_;
};

TEST_F(FindPathTest, TestFindPath) {
  PpRequest req;
  req.robot_id = 0;
  Task moveTask;
  moveTask.type = InternalTaskType::MoveTask;
  moveTask.move_task.target_pos.x = 3;
  moveTask.move_task.target_pos.y = 2;
  moveTask.move_task.target_pos.theta = kDirectionRight;
  req.tasks.push_back(moveTask);
  req.pos.x = 1;
  req.pos.y = 1;
  req.pos.theta = kDirectionUp;
  req.target_or_current_sid = ss_map_->FindSidByPosition(PositionXYT(req.pos));

  list<PpResponse> rtn;
  rtn = ppi_->QueryPath({req});
  const PpResponse& resp = rtn.front();
  EXPECT_EQ(req.robot_id, resp.robot_id);

  list<int> expectedAnswer;
  expectedAnswer.push_back(3);
  expectedAnswer.push_back(14);
  expectedAnswer.push_back(15);
  expectedAnswer.push_back(20);
//  for (const auto& elem : rtn.front().path_points) {
//    printf("path point: %s\n", ss_map_->GetPositionBySid(elem).ToString().c_str());
//  }

  EXPECT_EQ(expectedAnswer, resp.path_points);

  // Go back to the original position.
  req.pos.x = 3;
  req.pos.y = 2;
  req.pos.theta = kDirectionRight;
  req.target_or_current_sid = ss_map_->FindSidByPosition(PositionXYT(req.pos));
  req.tasks.clear();
  moveTask.move_task.target_pos.x = 1;
  moveTask.move_task.target_pos.y = 1;
  moveTask.move_task.target_pos.theta = kDirectionUp;
  req.tasks.push_back(moveTask);

  rtn = ppi_->QueryPath({req});

//  for (const auto& elem : rtn.front().path_points) {
//    printf("path point: %s\n", ss_map_->GetPositionBySid(elem).ToString().c_str());
//  }
}

// Find path test with a larger map.
class FindPathTestLarge : public ::testing::Test {
 protected:
  FindPathTestLarge() {
  }

  ~FindPathTestLarge() override {
  }

  void SetUp() override {
    ss_map_ = new SsMap();
    ss_map_->LoadMap("../data/test60_60/adjacency_list.in");
    ppi_ = new LocalRepairAstar(ss_map_);
  }

  void TearDown() override {
    delete ss_map_;
  }

  SsMap *ss_map_;
  PathPlannerInterface *ppi_;
};

TEST_F(FindPathTestLarge, TestFindPath) {
  PpRequest req1;
  req1.robot_id = 0;
  req1.pos.x = 32;
  req1.pos.y = 20;
  req1.pos.theta = kDirectionRight;
  req1.target_or_current_sid = ss_map_->FindSidByPosition(PositionXYT(req1.pos));
  Task moveTask1;
  moveTask1.type = InternalTaskType::MoveTask;
  moveTask1.move_task.target_pos.x = 35;
  moveTask1.move_task.target_pos.y = 20;
  moveTask1.move_task.target_pos.theta = kDirectionRight;
  req1.tasks.push_back(moveTask1);

  PpRequest req2;
  req2.robot_id = 1;
  req2.pos.x = 38;
  req2.pos.y = 20;
  req2.pos.theta = kDirectionLeft;
  req2.target_or_current_sid = ss_map_->FindSidByPosition(PositionXYT(req2.pos));
  Task moveTask2;
  moveTask2.type = InternalTaskType::MoveTask;
  moveTask2.move_task.target_pos.x = 25;
  moveTask2.move_task.target_pos.y = 19;
  moveTask2.move_task.target_pos.theta = kDirectionLeft;
  req2.tasks.push_back(moveTask2);

  PpRequest req3;
  req3.robot_id = 2;
  req3.pos.x = 32;
  req3.pos.y = 25;
  req3.pos.theta = kDirectionLeft;
  req3.target_or_current_sid = ss_map_->FindSidByPosition(PositionXYT(req3.pos));
  Task moveTask3;
  moveTask3.type = InternalTaskType::MoveTask;
  moveTask3.move_task.target_pos.x = 32;
  moveTask3.move_task.target_pos.y = 18;
  moveTask3.move_task.target_pos.theta = kDirectionLeft;
  req3.tasks.push_back(moveTask3);

  list<PpResponse> rtn = ppi_->QueryPath({req1, req2, req3});

//  for (const auto& resp : rtn) {
//    printf("robot id: %d\n", resp.robot_id);
//    for (const auto& elem : resp.path_points) {
//     printf("path point: %s\n", ss_map_->GetPositionBySid(elem).ToString().c_str());
//    }
//  }
}

}

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
