#ifndef SYNCER_H
#define SYNCER_H

#include "scheduling_server.h"
#include "hiredis/hiredis.h"

namespace scheduling_server {

class SsSyncer {
 public:
  SsSyncer(SchedulingServer* ss);
  void Run();

 private:
  SchedulingServer* ssp_;
  redisContext *redis_;
};

} // end namespace scheduling_server

#endif