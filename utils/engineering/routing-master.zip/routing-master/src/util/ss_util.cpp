#include "ss_util.h"

#include <cmath>

#include "ss_constants.h"
#include "position.h"

namespace scheduling_server {
using std::string;
using std::min;
using std::abs;
using std::vector;

void StrSplit(const string &str, char delim, vector<string> &result) {
  size_t cur = 0;
  size_t pos = str.find(delim);
  while (pos != string::npos) {
    if (pos != cur) {
      result.push_back(str.substr(cur, pos - cur));
    }
    pos++;
    cur = pos;
    pos = str.find(delim, pos);
  }
  if (cur != str.length()) {
    result.push_back(str.substr(cur));
  }
}

vector<string> StrSplit(const string &str, char delim) {
  vector<string> rtn;
  StrSplit(str, delim, rtn);
  return rtn;
}

bool MapPointEquals(const PositionXYT& a, const PositionXYT& b) {
  return DoubleEquals(a.x, b.x) && DoubleEquals(a.y, b.y);
}

bool MapPointEquals(const PositionXY& a, const PositionXY& b) {
  return DoubleEquals(a.x, b.x) && DoubleEquals(a.y, b.y);
}

// Get the absolute value of minimum rotation from a to b(all in radian).
double GetThetaDist(double a, double b) {
  a = a > 0 ? a : kTwoPi + a;
  b = b > 0 ? b : kTwoPi + b;

  double diff = abs(a - b);
  double compliment = kTwoPi - diff;
  return min(diff, compliment);
}

bool IsRotateTransition(const PositionXYT &a,
                        const PositionXYT &b) {
  bool x_equals = DoubleEquals(a.x, b.x);
  bool y_equals = DoubleEquals(a.y, b.y);
  bool theta_equals = DoubleEquals(a.theta, b.theta);
  double theta_diff = abs(a.theta - b.theta) / kHalfPi;
  bool theta_diff_valid = abs(theta_diff - round(theta_diff)) < 0.05;
  if (!theta_diff_valid) {
    if (kDebugMode) {
      printf("theta diff invalid: %lf, %lf\n", a.theta, b.theta);
      exit(0);
    }
  }
  return x_equals && y_equals && !theta_equals && theta_diff_valid;
}

bool IsMoveTransition(const PositionXYT &a,
                      const PositionXYT &b) {
  bool x_equals = DoubleEquals(a.x, b.x);
  bool y_equals = DoubleEquals(a.y, b.y);
  bool theta_equals = DoubleEquals(a.theta, b.theta);
  return theta_equals && ((x_equals && !y_equals) || (!x_equals && y_equals));
}

bool IsPositionSameLowPrecision(const PositionXYT &a,
                                const PositionXYT &b) {
  double dist = GetDist(a.x, a.y, b.x, b.y);
  double theta_diff = std::abs(a.theta - b.theta);
  return dist < kMapPointEpsilon && theta_diff < kThetaEpsilon;
}

double GetMapPointDist(const PositionXY& a, const PositionXY& b) {
  return GetDist(a.x, a.y, b.x, b.y);
}

double GetMapPointDist(const PositionXYT& a, const PositionXYT& b) {
  return GetDist(a.x, a.y, b.x, b.y);
}


}
