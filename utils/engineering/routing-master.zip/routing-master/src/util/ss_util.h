#ifndef COMMON_UTIL_SS_UTIL_H
#define COMMON_UTIL_SS_UTIL_H

#include <string>
#include <vector>
#include <cmath>
#include <thread>
#include <chrono>

#include "ss_constants.h"

namespace scheduling_server {

class PositionXY;
class PositionXYT;

inline void SleepMS(size_t ms) {
  std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}

inline void SleepSec(size_t sec) {
  std::this_thread::sleep_for(std::chrono::seconds(sec));
}

inline uint64_t GetCurrentTimeSinceEpochMS() {
  auto duration = std::chrono::system_clock::now().time_since_epoch();
  return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

// Return true if the duration from time_point_ms till now is shorter than duration_ms.
inline bool IsElapsedTimeShorterThan(uint64_t time_point_ms, uint64_t duration_ms) {
  uint64_t current = GetCurrentTimeSinceEpochMS();
  return (current - time_point_ms) < duration_ms;
}

inline bool IsElapsedTimeLongerThan(uint64_t time_point_ms, uint64_t duration_ms) {
  return !IsElapsedTimeShorterThan(time_point_ms, duration_ms);
}

inline bool DoubleEquals(double a, double b) {
  return std::abs(a - b) < scheduling_server::kDoubleEpsilon;
}

inline bool DoubleLargerThan(double a, double b) {
  return a - b > scheduling_server::kDoubleEpsilon;
}

inline bool DoubleSmallerThan(double a, double b) {
  return !DoubleLargerThan(a, b);
}

inline double GetDist(double x1, double y1, double x2, double y2) {
  return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

inline double GetManhattanDist(double x1, double y1, double x2, double y2) {
  return abs(x1 - x2) + abs(y1 - y2);
}

void StrSplit(
    const std::string &str,
    char delim,
    std::vector<std::string> &result);

std::vector<std::string> StrSplit(const std::string &str, char delim);

double GetThetaDist(double a, double b);

bool IsRotateTransition(const PositionXYT &a,
                        const PositionXYT &b);

bool IsMoveTransition(const PositionXYT &a,
                      const PositionXYT &b);

bool MapPointEquals(const PositionXYT& a, const PositionXYT& b);

bool MapPointEquals(const PositionXY& a, const PositionXY& b);

bool IsPositionSameLowPrecision(const scheduling_server::PositionXYT &a,
                                const scheduling_server::PositionXYT &b);

double GetMapPointDist(const PositionXY& a, const PositionXY& b);

double GetMapPointDist(const PositionXYT& a, const PositionXYT& b);

}

#endif
