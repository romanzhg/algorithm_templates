#include <ctime>
#include <thread>

#include "scheduling_server.h"
#include "ss_syncer.h"
#include "messaging_service/local_ms.h"

int main() {
  srand(time(nullptr));

  messaging_service::MessagingServiceInterface* msi =
      new messaging_service::LocalMs();

  scheduling_server::SchedulingServer ss;
  ss.Init(msi);

  scheduling_server::SsSyncer syncer(&ss);

  // Start one thread to run syncer.
  std::thread t0(&scheduling_server::SsSyncer::Run, &syncer);
  t0.detach();

  // Start one thread to run SchedulingServer::manageTasks.
  std::thread t1(&scheduling_server::SchedulingServer::ManageTasks, &ss);
  t1.detach();

  // Main thread. Never return.
  ss.Run();
  return 0;
}