#ifndef RA_ROBOT_TRAYS_H
#define RA_ROBOT_TRAYS_H

#include <optional>
#include <utility>

#include "ss_constants.h"

namespace scheduling_server {

class RobotTrays {
 public:
  RobotTrays() {
    for (int i = 0; i < kKubotTrayCount; i++) {
      internal_trays_[i] = -1;
    }
  }

  std::optional<std::pair<TrayType, int>> FindTrayByBinId(int bin_id) const {
    for (int i = 0; i < kKubotTrayCount; i++) {
      if (internal_trays_[i] == bin_id) {
        return GetTrayFromInternalTrayIndex(i);
      }
    }
    return std::nullopt;
  };

  std::optional<std::pair<TrayType, int>> FindEmptyBeilou() const {
    for (int i = 1; i < kKubotTrayCount; i++) {
      if (internal_trays_[i] == -1) {
        return GetTrayFromInternalTrayIndex(i);
      }
    }
    return std::nullopt;
  };

  void SetTray(TrayType type, int tray_index, int bin_id) {
    int index = type == TrayType::BEILOU ? tray_index + 1 : 0;
    internal_trays_[index] = bin_id;
  }

  void UpdateTrayStateWithSucceedInst(const Instruction& inst) {
    assert(inst.type == MessageType::RCS2LL_BIN_OP
        || inst.type == MessageType::RCS2LL_INTERNAL_BIN_OP);

    if (inst.type == MessageType::RCS2LL_BIN_OP) {
      if (inst.bin_op_inst.op_type == BinOpType::PUT_NEAR) {
        SetTray(TrayType::FORK, 0, -1);
      } else if (inst.bin_op_inst.op_type == BinOpType::TAKE_NEAR) {
        SetTray(TrayType::FORK, 0, inst.bin_op_inst.bin_id);
      } else {
        exit(0);
      }
    }

    if (inst.type == MessageType::RCS2LL_INTERNAL_BIN_OP) {
      SetTray(inst.internal_bin_op_inst.source_tray_type,
              inst.internal_bin_op_inst.source_tray_id,
              -1);
      SetTray(inst.internal_bin_op_inst.dest_tray_type,
              inst.internal_bin_op_inst.dest_tray_id,
              inst.internal_bin_op_inst.bin_id);
    }
  }

  void DumpTrayInfo(std::vector<RcsKubotTray>& trays) const {
    for (int index = 0; index < kKubotTrayCount; index++) {
      const std::pair<TrayType, int>& tmp = GetTrayFromInternalTrayIndex(index);
      trays.emplace_back(tmp.second, tmp.first, internal_trays_[index]);
    }
  }

 private:
  // Helper functions.
  std::pair<TrayType, int> GetTrayFromInternalTrayIndex(int index) const {
    if (index == 0) {
      return {TrayType::FORK, 0};
    } else {
      return {TrayType::BEILOU, index - 1};
    }
  }

  // Data.
  // Index 0 corresponds to the fork, 1+ corresponds to the trunks.
  // The content -1 means the tray is empty, otherwise it would be the tray id.
  int internal_trays_[kKubotTrayCount];
};
}

#endif