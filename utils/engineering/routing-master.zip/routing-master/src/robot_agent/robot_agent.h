#ifndef RA_ROBOT_AGENT_H
#define RA_ROBOT_AGENT_H

#include <string>
#include <list>
#include <mutex>
#include <optional>

#include "path_planner/path_planner.h"
#include "path_planner/ss_map.h"
#include "position.h"
#include "robot_agent/robot_trays.h"
#include "rest_manager.h"
#include "interface/mc_ss_messages.h"
#include "interface/ss_ll_messages.h"
#include "ss_constants.h"
#include "messaging_service/messaging_service.h"

namespace scheduling_server {

using messaging_service::MessagingServiceInterface;

class SchedulingServer;

class RobotAgent {
 public:
  RobotAgent() = delete;
  RobotAgent(int robot_id,
             const std::string &unique_id,
             SchedulingServer *ssp,
             MessagingServiceInterface *msi,
             SsMap *ss_map,
             RestManager *rm_,
             int init_sid);

  // TODO: if there is an performance problem, may change this to a pull mode.
  void SetRobotState(const KubotState &ks);
  void SetKill();
  void SetCancel();
  void GetRobotInfo(std::string &unique_id, bool &is_available, std::vector<RcsKubotTray> &trays);

  // PP related functions.
  PpRequest BuildPpRequest();
  void SetPpResponse(const PpResponse &resp);

  void AddMcMission(const McMission &new_mission);
  void AddMcDetour(const PositionXYT &pos);
  void HandleLlResponse(const LlResp &ll_resp);
  void HandleMcTrayUpdate(const McBinUpdate &bin_update);

  bool IsOnRestMission();
  bool IsOnChargeMission();
  PositionXYT GetCurrentPosition();

  // Main thread.
  void Process();

 private:
  // Internal helper functions below, should be called with the lock held.
  void ProcessTasksInternal();
  void ProcessMoveInternal();

  // Returns true if the current process should be terminated.
  bool MaybeKillInternal();
  void MaybeSendInitInst();

  void HandleCancelInternal(bool &cancel_done);
  void CancelSingleTask(const InternalTask &internal_task);
  void CancelAllTasksInternal();

  bool IsReadyInternal();
  bool IsAvailableInternal();
  bool IsCancellableInternal();

  void UpdateStandStillTimeInternal();

  void ResponseToMc(const InternalTask &task);
  void SendOpUpdateInternal(int robot_id, int64_t op_id, int mission_id,
                            OpResult op_result, int dest_tray_id);
  void SendMissionUpdateInternal(int robot_id, int mission_id, MissionStatus mission_status);

  void ShouldRestOrChargeInternal();
  void SendInstInternal(Instruction &inst);

  // These fields are immutable for an object, so they don't need to be
  // protected by a lock.
  int robot_id_;
  std::string unique_id_;
  SchedulingServer *ssp_;
  MessagingServiceInterface *msi_;
  const SsMap *ss_map_;
  RestManager *rm_;

  // All data below is protected by the robot agent mutex.
  std::mutex mutex_;
  bool to_kill_;
  bool init_inst_sent_;
  int seq_num_;
  KubotState state_;
  RobotTrays trays_;

  std::list<InternalTask> internal_tasks_;

  // This field should be set before sending init instruction to the robot.
  int target_or_current_sid_;

  // Stand still time and related states.
  uint64_t stand_still_time_ms_;
  PositionXYT prev_pos_;
  uint64_t prev_pos_ts_;

  // Cancel related states.
  bool cancel_started_;
  bool cancel_synced_with_pp_;
  // Used to hold the mission temporarily when cancelling the Rest mission.
  std::list<McMission> next_mission_;
};

}

#endif