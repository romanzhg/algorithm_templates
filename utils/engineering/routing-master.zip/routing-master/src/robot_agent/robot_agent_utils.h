/**
 * Utilities of robot_agent.cpp.
 */
#ifndef RA_ROBOT_AGENT_UTILS_H
#define RA_ROBOT_AGENT_UTILS_H

#include <list>

#include "path_planner/ss_map.h"
#include "robot_agent/internal_types.h"
#include "robot_agent/robot_trays.h"

namespace scheduling_server {

void MaybeGenerateBinOpInstructions(const RobotTrays &trays, InternalTask &task);

void BuildTasksFromMission(McMission m, std::list<InternalTask> &internal_tasks);

void BuildMoveInstructions(const std::list<int> &points,
                           const SsMap *ss_map,
                           int &target_or_current_sid,
                           std::list<InternalTask> &internal_tasks);
}

#endif