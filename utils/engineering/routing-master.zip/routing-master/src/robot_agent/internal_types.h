/**
 * Types shared by components of scheduling server.
 *
 * As compared to the types defined in ss_types.h, the types
 * defined here does not need the ToJson function.
 *
 */

#ifndef RA_INTERNAL_TYPES_H
#define RA_INTERNAL_TYPES_H

#include <list>

#include "position.h"
#include "interface/mc_ss_messages.h"
#include "interface/ss_ll_messages.h"

namespace scheduling_server {

enum class InternalTaskType : int {
  BinTask,
  MoveTask,
  WaitTask,
};

struct BinTask {
  OpType type;
  int bin_id;
  PositionXYT robot_pos;
  double fork_height;
  double bin_orient;
};

struct MoveTask {
  PositionXYT target_pos;
  double fork_height;
};

struct Task {
  InternalTaskType type;
  BinTask bin_task;
  MoveTask move_task;
};

enum class InternalMissionType : int {
  McMission,
  Charge,
  Rest,
  Internal,
};

struct InternalTask {
  // Internal missions(Charge and Rest) always have mission id -1.
  int mission_id;
  InternalMissionType mission_type;
  int64_t op_id;

  Task task;

  bool should_send_op_update;
  bool should_send_mission_update;

  bool bin_op_insts_set;

  bool external_bin_op_failed;
  bool internal_bin_op_failed;

  // For load op.
  int dest_tray_id;

  // A list of instructions to send to the robot.
  std::list<Instruction> insts;
  std::list<Instruction> sent_insts;

  InternalTask(int mission_id, InternalMissionType mission_type, int64_t op_id)
      : mission_id(mission_id),
        mission_type(mission_type),
        op_id(op_id) {
    should_send_op_update = false;
    should_send_mission_update = false;

    bin_op_insts_set = false;

    external_bin_op_failed = false;
    internal_bin_op_failed = false;
  }
};

}
#endif