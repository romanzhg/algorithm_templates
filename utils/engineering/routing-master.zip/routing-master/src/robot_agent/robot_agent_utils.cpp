#include "robot_agent/robot_agent_utils.h"

#include <vector>
#include "logger/log.h"

namespace scheduling_server {
using std::list;
using std::vector;

void MaybeGenerateBinOpInstructions(const RobotTrays& trays, InternalTask &task) {
  if (task.bin_op_insts_set) {
    return;
  }

  const BinTask &bin_task = task.task.bin_task;

  Instruction external_bin_inst;
  external_bin_inst.type = MessageType::RCS2LL_BIN_OP;
  external_bin_inst.bin_op_inst.fork_orient = bin_task.bin_orient;
  external_bin_inst.bin_op_inst.map_position = bin_task.robot_pos;
  external_bin_inst.bin_op_inst.height = bin_task.fork_height;
  external_bin_inst.bin_op_inst.bin_id = bin_task.bin_id;
  if (bin_task.type == OpType::LOAD) {
    external_bin_inst.bin_op_inst.op_type = BinOpType::TAKE_NEAR;
  } else if (bin_task.type == OpType::UNLOAD) {
    external_bin_inst.bin_op_inst.op_type = BinOpType::PUT_NEAR;
  }

  // The internal bin op.
  Instruction internal_bin_inst;
  internal_bin_inst.type = MessageType::RCS2LL_INTERNAL_BIN_OP;

  if (bin_task.type == OpType::LOAD) {
    internal_bin_inst.internal_bin_op_inst.source_tray_type = TrayType::FORK;
    internal_bin_inst.internal_bin_op_inst.source_tray_id = 0;
    internal_bin_inst.internal_bin_op_inst.dest_tray_type = TrayType::BEILOU;
    internal_bin_inst.internal_bin_op_inst.bin_id = bin_task.bin_id;

    // Find an empty tray to put the bucket in.
    auto id_or_empty = trays.FindEmptyBeilou();
    if (id_or_empty.has_value()) {
      internal_bin_inst.internal_bin_op_inst.dest_tray_id = id_or_empty.value().second;
    } else {
      // TODO: consider how to return error on this op and cancel all following instructions.
      LOG(LogLevel::error, "invalid instructions, should return failure to MC.");
      exit(0);
    }

    // LOAD operation, external bin op first then internal bin op.
    task.insts.push_back(external_bin_inst);
    task.insts.push_back(internal_bin_inst);

  } else if (bin_task.type == OpType::UNLOAD) {
    internal_bin_inst.internal_bin_op_inst.dest_tray_type = TrayType::FORK;
    internal_bin_inst.internal_bin_op_inst.dest_tray_id = 0;
    internal_bin_inst.internal_bin_op_inst.source_tray_type = TrayType::BEILOU;

    // Find the tray that contains the required bin.
    auto id_or_empty = trays.FindTrayByBinId(bin_task.bin_id);
    if (id_or_empty.has_value()) {
      assert(id_or_empty.value().first == TrayType::BEILOU);
      internal_bin_inst.internal_bin_op_inst.source_tray_id = id_or_empty.value().second;
    } else {
      LOG(LogLevel::error, "invalid instructions, should return failure to MC.");
      exit(0);
    }

    // PUT operation, external bin op first then internal bin op.
    task.insts.push_back(internal_bin_inst);
    task.insts.push_back(external_bin_inst);
  }

  task.bin_op_insts_set = true;
}

void BuildTasksFromMission(McMission m, list<InternalTask>& internal_tasks) {
  list<InternalTask> new_tasks;

  if (m.msg_body.operations.empty()) {
    return;
  }

  int mission_id = m.msg_body.mission_id;
  InternalMissionType mission_type = InternalMissionType::McMission;

  // Separate wait and other normal operations.
  bool contains_wait = false;
  int wait_op_id;
  if (m.msg_body.operations.back().type == OpType::WAIT) {
    contains_wait = true;
    wait_op_id = m.msg_body.operations.back().op_id;
    m.msg_body.operations.pop_back();
  }

  for (int index = 0; index < m.msg_body.operations.size(); index++) {
    const McOperation &mc_op = m.msg_body.operations[index];
    bool is_last_op = index == (m.msg_body.operations.size() - 1);

    if (mc_op.type == OpType::LOAD
        || mc_op.type == OpType::UNLOAD) {
      InternalTask it_move(mission_id, mission_type, mc_op.op_id);
      it_move.task.type = InternalTaskType::MoveTask;
      it_move.task.move_task.target_pos = mc_op.map_position;

      InternalTask it_bin_op(mission_id, mission_type, mc_op.op_id);
      it_bin_op.should_send_op_update = true;
      it_bin_op.should_send_mission_update = is_last_op;

      it_bin_op.task.type = InternalTaskType::BinTask;
      it_bin_op.task.bin_task.bin_orient = mc_op.fork_orient;
      it_bin_op.task.bin_task.fork_height = mc_op.fork_height;
      it_bin_op.task.bin_task.bin_id = mc_op.bin_id;
      it_bin_op.task.bin_task.type = mc_op.type;
      it_bin_op.task.bin_task.robot_pos = mc_op.map_position;

      new_tasks.push_back(it_move);
      new_tasks.push_back(it_bin_op);
    } else if (mc_op.type == OpType::MOVE) {
      InternalTask it(mission_id, mission_type, mc_op.op_id);
      it.should_send_op_update = true;
      it.should_send_mission_update = is_last_op;

      it.task.type = InternalTaskType::MoveTask;
      it.task.move_task.target_pos = mc_op.map_position;

      new_tasks.push_back(it);
    } else if (mc_op.type == OpType::WAIT) {
      LOG(LogLevel::error, "Wait can only be the last operation in a "
                         "mission. This constrain can be removed once "
                         "we don't send mission update");
      exit(0);
    } else {
      LOG(LogLevel::error, "Invalid op type");
      exit(0);
    }
  }

  if (contains_wait) {
    InternalTask it(mission_id, mission_type, wait_op_id);
    it.task.type = InternalTaskType::WaitTask;
    new_tasks.push_back(it);
  }

  internal_tasks.splice(internal_tasks.end(), new_tasks);
}

void BuildMoveInstructions(const std::list<int> &points,
                           const SsMap *ss_map,
                           int &target_or_current_sid,
                           std::list<InternalTask> &internal_tasks) {
  if (points.empty()) {
    return;
  }

  // Figure out how to travel from current or target position to points.
  vector<PositionXYT> path_points;
  path_points.push_back(ss_map->GetPositionBySid(target_or_current_sid));
  for (int p : points) {
    path_points.push_back(ss_map->GetPositionBySid(p));
  }

  vector<bool> is_way_point(path_points.size());
  for (int i = 0; i < path_points.size() - 1; i++) {
    if (IsRotateTransition(path_points[i], path_points[i + 1])) {
      is_way_point[i] = true;
      is_way_point[i + 1] = true;
    }
  }

  is_way_point.front() = false;
  is_way_point.back() = true;

  for (int i = 0; i < path_points.size(); i++) {
    if (is_way_point[i]) {
      Instruction inst;
      inst.type = MessageType::RCS2LL_MOVE;
      inst.move_inst.target_position = path_points[i];
      internal_tasks.front().insts.push_back(inst);
    }
  }

  target_or_current_sid = points.back();
}

}