#include "robot_agent/robot_agent.h"

#include "logger/log.h"
#include "interface/mc_ss_messages.h"
#include "interface/ss_ll_messages.h"
#include "robot_agent/robot_agent_utils.h"
#include "scheduling_server.h"
#include "ss_constants.h"
#include "util/ss_util.h"

using namespace std;

namespace scheduling_server {

RobotAgent::RobotAgent(int robot_id,
                       const string& unique_id,
                       SchedulingServer *ssp,
                       MessagingServiceInterface *msi,
                       SsMap *ss_map,
                       RestManager* rm,
                       int init_sid)
    : to_kill_(false),
      init_inst_sent_(false) {
  robot_id_ = robot_id;
  unique_id_ = unique_id;
  ssp_ = ssp;
  msi_ = msi;
  ss_map_ = ss_map;
  rm_ = rm;
  target_or_current_sid_ = init_sid;

  seq_num_ = 0;

  cancel_started_ = false;
  cancel_synced_with_pp_ = false;

  // For recording the stand still time.
  stand_still_time_ms_ = GetCurrentTimeSinceEpochMS();
  // Assign an impossible location.
  prev_pos_.x = kDoubleInf;
  prev_pos_.y = kDoubleInf;
}

void RobotAgent::SetRobotState(const KubotState &ks) {
  lock_guard<mutex> lock(mutex_);
  state_ = ks;
}

void RobotAgent::SetKill() {
  lock_guard<mutex> lock(mutex_);
  to_kill_ = true;
}

void RobotAgent::SetCancel() {
  lock_guard<mutex> lock(mutex_);
  if (IsCancellableInternal()) {
    cancel_started_ = true;
  }
}

void RobotAgent::AddMcMission(const McMission &new_mission) {
  lock_guard<mutex> lock(mutex_);

  if (!IsAvailableInternal()) {
    // TODO: send out the rejection to MC.
    return;
  }

  // 4. No tasks now, available.
  if (internal_tasks_.empty()) {
    BuildTasksFromMission(new_mission, internal_tasks_);
    return;
  }

  // 6. Resting, available.
  if (internal_tasks_.front().mission_type == InternalMissionType::Rest) {
    cancel_started_ = true;
    next_mission_.push_back(new_mission);
    return;
  }

  // 7. If the current mission is a McMission, the robot is considered available only when
  // the mission is effectively finished(current task is wait task).
  if (internal_tasks_.front().mission_type == InternalMissionType::McMission
      && internal_tasks_.front().task.type == InternalTaskType::WaitTask) {
    internal_tasks_.clear();
    BuildTasksFromMission(new_mission, internal_tasks_);
    return;
  }

  LOG(LogLevel::error, "Invalid state.");
  exit(0);
}

void RobotAgent::AddMcDetour(const PositionXYT &pos) {
  lock_guard<mutex> lock(mutex_);
  if (!IsReadyInternal()) {
    return;
  }

  if (cancel_started_) {
    return;
  }

  if (!internal_tasks_.empty()
      && internal_tasks_.front().task.type != InternalTaskType::MoveTask) {
    return;
  }

  InternalTask it(0, InternalMissionType::Internal, -1);
  it.should_send_op_update = false;
  it.should_send_mission_update = false;

  it.task.type = InternalTaskType::MoveTask;
  it.task.move_task.target_pos = pos;

  internal_tasks_.push_front(it);
}

PpRequest RobotAgent::BuildPpRequest() {
  lock_guard<mutex> lock(mutex_);
  PpRequest rtn;
  rtn.robot_id = robot_id_;
  rtn.pos = state_.pos;
  rtn.target_or_current_sid = target_or_current_sid_;
  rtn.stand_still_time_ms = stand_still_time_ms_;

  if (cancel_started_) {
    rtn.cancel_future_reservations = true;
    cancel_synced_with_pp_ = true;
    return rtn;
  }

  rtn.cancel_future_reservations = false;

  for (const InternalTask &internal_task : internal_tasks_) {
    rtn.tasks.push_back(internal_task.task);
    // TODO: remove this to give path planner more tasks.
    break;
  }
  return rtn;
}

void RobotAgent::SetPpResponse(const PpResponse &resp) {
  lock_guard<mutex> lock(mutex_);

  if (cancel_started_) {
    // If cancel is set, do not accept any new path points.
    return;
  }

  if (resp.path_points.empty()) {
    return;
  }

  if (internal_tasks_.empty()
      || internal_tasks_.front().task.type != InternalTaskType::MoveTask) {
    LOG(LogLevel::error, "Got move directions while the current task is not a move task");
    return;
  }

  BuildMoveInstructions(resp.path_points, ss_map_, target_or_current_sid_, internal_tasks_);
}

void RobotAgent::HandleMcTrayUpdate(const McBinUpdate &bin_update) {
  lock_guard<mutex> lock(mutex_);

  if (bin_update.op_type == OpType::LOAD) {
    trays_.SetTray(bin_update.tray_type, bin_update.tray_id, bin_update.bin_id);
  } else if (bin_update.op_type == OpType::UNLOAD) {
    trays_.SetTray(bin_update.tray_type, bin_update.tray_id, -1);
  } else {
    LOG(LogLevel::error, "Invalid log type.");
    exit(0);
  }
}

bool RobotAgent::IsOnRestMission() {
  lock_guard<mutex> lock(mutex_);
  return !internal_tasks_.empty()
      && internal_tasks_.front().mission_type == InternalMissionType::Rest;
}

bool RobotAgent::IsOnChargeMission() {
  lock_guard<mutex> lock(mutex_);
  return !internal_tasks_.empty()
      && internal_tasks_.front().mission_type == InternalMissionType::Charge
      && state_.power_level < kPowerFullLimitPercent;
}

PositionXYT RobotAgent::GetCurrentPosition() {
  lock_guard<mutex> lock(mutex_);
  return state_.pos;
}

void RobotAgent::HandleLlResponse(const LlResp &ll_resp) {
  lock_guard<mutex> lock(mutex_);

  if (internal_tasks_.empty()) {
    return;
  }
  InternalTask &task = internal_tasks_.front();

  // There should be at most one sent instruction.
  if (task.sent_insts.empty()) {
    return;
  }

  const Instruction &inst = task.sent_insts.front();

  if (ll_resp.seq_num == inst.seq_num) {
    assert(task.task.type == InternalTaskType::BinTask);
    if (inst.type == MessageType::RCS2LL_BIN_OP) {
      if (ll_resp.execution_result == ExecutionResult::SUCCESS) {
        trays_.UpdateTrayStateWithSucceedInst(inst);
        task.sent_insts.pop_front();
      } else {
        task.external_bin_op_failed = true;
        return;
      }
    } else if (inst.type == MessageType::RCS2LL_INTERNAL_BIN_OP) {
      if (ll_resp.execution_result == ExecutionResult::SUCCESS) {
        trays_.UpdateTrayStateWithSucceedInst(inst);
        if (inst.internal_bin_op_inst.dest_tray_type == TrayType::BEILOU) {
          task.dest_tray_id = inst.internal_bin_op_inst.dest_tray_id;
        }
        task.sent_insts.pop_front();
      } else {
        task.internal_bin_op_failed = true;
        return;
      }
    } else {
      LOG(LogLevel::error, "Invalid response from LL.");
      exit(0);
    }
  }
}

void RobotAgent::GetRobotInfo(
    std::string &unique_id,
    bool &is_available,
    std::vector<RcsKubotTray> &trays) {
  lock_guard<mutex> lock(mutex_);
  unique_id = state_.unique_id;
  is_available = IsAvailableInternal();
  trays_.DumpTrayInfo(trays);
}

void RobotAgent::Process() {
  int round_counter = 0;
  mutex_.lock();
  while (true) {
    mutex_.unlock();
    LOG(LogLevel::trace, "RA thread loop start, robot " + std::to_string(robot_id_));
    SleepMS(kRobotAgentSleepMS);
    mutex_.lock();

    if (state_.state_type == RobotState::ROBOT_READY_TO_INIT) {
      MaybeSendInitInst();
      continue;
    }

    UpdateStandStillTimeInternal();

    if (MaybeKillInternal()) {
      break;
    }

    if (cancel_started_) {
      // Handle all the pending move instructions first.
      if (!internal_tasks_.empty()) {
        InternalTask &internal_task = internal_tasks_.front();
        if (internal_task.task.type == InternalTaskType::MoveTask) {
          while (!internal_task.insts.empty()) {
            Instruction &inst = internal_task.insts.front();
            SendInstInternal(inst);
            internal_task.insts.pop_front();
          }
        } else {
          LOG(LogLevel::error, "Invalid state");
          exit(0);
        }
      }

      bool cancel_done;
      HandleCancelInternal(cancel_done);

      if (!cancel_done) {
        continue;
      }
    }

    if (++round_counter % kBookkeepingEveryNRounds == 0) {
      ShouldRestOrChargeInternal();
    }

    ProcessTasksInternal();
  }
}

bool RobotAgent::IsCancellableInternal() {
  // If the robot is not initiated, do not accept cancel.
  if (!IsReadyInternal()) {
    return false;
  }

  // If cancel is already set, do not accept cancel again.
  if (cancel_started_) {
    return false;
  }

  // As long as the current task is not a bin task, it is cancellable.
  if ((!internal_tasks_.empty())
      && internal_tasks_.front().task.type == InternalTaskType::BinTask) {
    return false;
  }
  return true;
}

bool RobotAgent::IsAvailableInternal() {
  // 1. The robot is not ready, not available.
  if (!IsReadyInternal()) {
    return false;
  }

  // 2. Cancel set, not available.
  if (cancel_started_) {
    return false;
  }

  // 3. Should go to charge immediately.
  if (state_.power_level < kPowerDangerLimitPercent) {
    return false;
  }

  // 4. No tasks now, available.
  if (internal_tasks_.empty()) {
    return true;
  }

  // 5. Do not interrupt Charge tasks, not available.
  if (internal_tasks_.front().mission_type == InternalMissionType::Charge) {
    return false;
  }

  // 6. Resting, available.
  if (internal_tasks_.front().mission_type == InternalMissionType::Rest) {
    return true;
  }

  // 7. If the current mission is a McMission, the robot is considered available only when
  // the mission is effectively finished(current task is wait task).
  if (internal_tasks_.front().mission_type == InternalMissionType::McMission
      && internal_tasks_.front().task.type == InternalTaskType::WaitTask) {
    return true;
  }

  // 8. For all other cases, not available.
  return false;
}

void RobotAgent::UpdateStandStillTimeInternal() {
  uint64_t cur_time = GetCurrentTimeSinceEpochMS();
  if (prev_pos_ == state_.pos) {
    stand_still_time_ms_ += cur_time - prev_pos_ts_;
  } else {
    stand_still_time_ms_ = 0;
    prev_pos_ = state_.pos;
  }
  prev_pos_ts_ = cur_time;
}

void RobotAgent::HandleCancelInternal(bool &cancel_done) {
  const PositionXYT &target_pos = ss_map_->GetPositionBySid(target_or_current_sid_);

  if (!IsPositionSameLowPrecision(state_.pos, target_pos)) {
    // Need to wait for the robot to reach its current destination.
    cancel_done = false;
    return;
  }

  if (!cancel_synced_with_pp_) {
    cancel_done = false;
    return;
  }

  cancel_done = true;
  cancel_started_ = false;
  cancel_synced_with_pp_ = false;

  CancelAllTasksInternal();

  assert(next_mission_.size() <= 1);
  if (!next_mission_.empty()) {
    BuildTasksFromMission(next_mission_.front(), internal_tasks_);
    next_mission_.pop_front();
  }
}

void RobotAgent::ProcessTasksInternal() {
  while (!internal_tasks_.empty()) {
    InternalTask &internal_task = internal_tasks_.front();
    if (internal_task.task.type == InternalTaskType::MoveTask) {

      // Send all move instructions.
      while (!internal_task.insts.empty()) {
        Instruction &inst = internal_task.insts.front();
        SendInstInternal(inst);
        internal_task.insts.pop_front();
      }
      if (!IsPositionSameLowPrecision(state_.pos, internal_task.task.move_task.target_pos)) {
        // Move task not finished.
        return;
      }

      // At this point, the move task is finished.

    } else if (internal_task.task.type == InternalTaskType::WaitTask) {

      // Wait task can be interrupted. And we don't need to do anything about it.
      return;

    } else if (internal_task.task.type == InternalTaskType::BinTask) {

      MaybeGenerateBinOpInstructions(trays_, internal_task);

      if (!internal_task.external_bin_op_failed && !internal_task.internal_bin_op_failed) {
        // Send instructions only if we haven't received any failure message.
        if (!internal_task.sent_insts.empty()) {
          // Waiting for response, do nothing.
          return;
        }

        if (!internal_task.insts.empty()) {
          Instruction &inst = internal_task.insts.front();
          SendInstInternal(inst);
          internal_task.sent_insts.push_back(inst);
          internal_task.insts.pop_front();
          return;
        }
      } else {
        // One of the bin op failed. Should cancel all tasks.
        cancel_started_ = true;
        return;
      }
    }

    ResponseToMc(internal_task);
    // At this point all instructions are sent and we got responses for them.
    // Remove the task from task list.
    internal_tasks_.pop_front();
  }
}

bool RobotAgent::IsReadyInternal() {
  return (!to_kill_)
      && (state_.state_type != RobotState::ROBOT_READY_TO_INIT)
      && (state_.state_type != RobotState::ROBOT_ERROR);
}

void RobotAgent::SendInstInternal(Instruction &inst) {
  inst.seq_num = seq_num_++;
  inst.robot_unique_id = unique_id_;
  msi_->SendToLlAsync(inst.ToJson().dump());
}

void RobotAgent::ResponseToMc(const InternalTask &internal_task) {
  OpResult op_result;
  if (internal_task.should_send_op_update) {
    if (internal_task.task.type == InternalTaskType::BinTask) {
      if (internal_task.task.bin_task.type == OpType::LOAD) {
        if (internal_task.external_bin_op_failed) {
          op_result = OpResult::FAILURE;
        } else {
          op_result = OpResult::SUCCESS;
        }
      } else if (internal_task.task.bin_task.type == OpType::UNLOAD) {
        if (internal_task.external_bin_op_failed || internal_task.internal_bin_op_failed) {
          op_result = OpResult::FAILURE;
        } else {
          op_result = OpResult::SUCCESS;
        }
      } else {
        LOG(LogLevel::error, "Invalid state.");
        exit(0);
      }
      SendOpUpdateInternal(
          robot_id_, internal_task.op_id, internal_task.mission_id, op_result, internal_task.dest_tray_id);
    } else if (internal_task.task.type == InternalTaskType::MoveTask) {
      // At this point a move task will always success.
      op_result = OpResult::SUCCESS;
      SendOpUpdateInternal(
          robot_id_, internal_task.op_id, internal_task.mission_id, op_result, 0);
    } else {
      // internal_task.task.type == InternalTaskType::WaitTask
      // We do not sent out response in this case.
      return;
    }
  }

  if (internal_task.should_send_mission_update) {
    assert(internal_task.should_send_op_update);
    MissionStatus mission_status;
    if (op_result == OpResult::SUCCESS) {
      mission_status = MissionStatus::SUCCESS;
    } else {
      mission_status = MissionStatus::FAILURE;
    }
    SendMissionUpdateInternal(robot_id_, internal_task.mission_id, mission_status);
  }
}

void RobotAgent::SendOpUpdateInternal(
    int robot_id, int64_t op_id, int mission_id, OpResult op_result, int dest_tray_id) {
  RcsOpUpdate op_update(robot_id, op_id, mission_id, op_result, TrayType::BEILOU, dest_tray_id);
  msi_->SendToMcAsync(op_update.ToJson().dump());
}

void RobotAgent::SendMissionUpdateInternal(int robot_id, int mission_id, MissionStatus mission_status) {
  RcsMissionUpdate mission_update;
  mission_update.robot_id = robot_id;
  mission_update.mission_id = mission_id;
  mission_update.mission_status = mission_status;
  msi_->SendToMcAsync(mission_update.ToJson().dump());
}

// We assume at this point robot has no tasks associated with it.
// So killing a robot we don't have to cancel the tasks.
bool RobotAgent::MaybeKillInternal() {
  // The robot is not updated for a long time, should be removed.
  if (IsElapsedTimeLongerThan(state_.last_update_ms,
                              kRobotStateShouldBeRemovedMSecs)) {
    to_kill_ = true;
  }

  if (!to_kill_) {
    return false;
  }

  Instruction pause_inst;
  pause_inst.type = MessageType::RCS2LL_PAUSE;
  SendInstInternal(pause_inst);

  mutex_.unlock();

  // Make sure the robot related information is removed from RCS first.
  ssp_->RemoveRobot(robot_id_);
  mutex_.lock();

  string unique_id = state_.unique_id;
  CancelAllTasksInternal();

  delete this;

  LOG(LogLevel::info, "Removed a robot " + unique_id);

  return true;
}

// Internal function, this function is to be called with the lock held.
// If the robot is in RobotState::ROBOT_READY_TO_INIT, then send out the init command.
// Please note the reply of this command is ignored.
void RobotAgent::MaybeSendInitInst() {
  if (!init_inst_sent_) {
    init_inst_sent_ = true;
    Instruction init;
    init.type = MessageType::RCS2LL_INIT;
    SendInstInternal(init);
  }
}

void RobotAgent::CancelAllTasksInternal() {
  while (internal_tasks_.empty()) {
    InternalTask &it = internal_tasks_.front();
    CancelSingleTask(it);
    internal_tasks_.pop_front();
  }
}

void RobotAgent::CancelSingleTask(const InternalTask &internal_task) {
  if (internal_task.should_send_op_update) {
    if (internal_task.task.type == InternalTaskType::BinTask
        || internal_task.task.type == InternalTaskType::MoveTask) {
      SendOpUpdateInternal(
          robot_id_, internal_task.op_id, internal_task.mission_id, OpResult::CANCEL, 0);
    } else {
      // internal_task.task.type == InternalTaskType::WaitTask
      // We do not sent out response in this case.
      return;
    }
  }

  if (internal_task.should_send_mission_update) {
    assert(internal_task.should_send_op_update);
    SendMissionUpdateInternal(
        robot_id_, internal_task.mission_id, MissionStatus::CANCEL);
  }
}

void RobotAgent::ShouldRestOrChargeInternal() {
  if (!IsReadyInternal()) {
    return;
  }

  if (cancel_started_) {
    return;
  }

  // Charge only when there is no other task.
  if (!internal_tasks_.empty()) {
    return;
  }

  if (state_.power_level < kPowerLowLimitPercent) {
    // Should charge.
    auto dest_or_empty = rm_->LockChargeStation(robot_id_);
    if (dest_or_empty.has_value()) {
      InternalTask it0(-1, InternalMissionType::Charge, -1);
      it0.task.type = InternalTaskType::MoveTask;
      it0.task.move_task.target_pos = dest_or_empty.value();

      InternalTask it1(-1, InternalMissionType::Charge, -1);
      it1.task.type = InternalTaskType::WaitTask;

      internal_tasks_.push_back(it0);
      internal_tasks_.push_back(it1);
      return;
    }
  }

  // Should rest.
  if (rm_->IsAtRestStation(state_.pos)) {
    return;
  }

  auto dest_or_empty = rm_->LockRestStation(robot_id_);
  if (dest_or_empty.has_value()) {
    InternalTask it0(-1, InternalMissionType::Rest, -1);
    it0.task.type = InternalTaskType::MoveTask;
    it0.task.move_task.target_pos = dest_or_empty.value();
    internal_tasks_.push_back(it0);
  }
}
}