#ifndef KUBOT_H
#define KUBOT_H

#include <list>
#include <string>
#include <mutex>
#include <utility>

#include "interface/ss_ll_messages.h"
#include "interface/message_types.h"
#include "position.h"
#include "rest_manager.h"

namespace mock_ll {

class MockLl;

class Kubot {
 public:
  Kubot() = delete;
  Kubot(scheduling_server::KubotState ks, MockLl *ll, scheduling_server::RestManager* rm)
      : ks_(std::move(ks)), ll_(ll), rm_(rm) {
    cur_time_ = scheduling_server::GetCurrentTimeSinceEpochMS();
    real_power_level_ = ks_.power_level;
  };
  void EnqueInstruction(const scheduling_server::Instruction& inst);
  std::string GetUniqueName() {return ks_.unique_id; };
  void Run();
  scheduling_server::KubotState CopyKs();

 private:
  void UpdatePowerLevelInternal();
  void SleepWithLockMS(int ms);
  bool IsAtChargeStation() {
    return rm_->IsAtChargeStation(ks_.pos);
  };

  void HandleCancel();

  // Instruction handlers called from different state.
  // These functions should be called with the lock held.
  void HandleAtReadyToInit(const scheduling_server::Instruction &inst);
  void HandleAtIdle(const scheduling_server::Instruction &inst);
  void HandleAtRunning(const scheduling_server::Instruction &inst);

  // Handle instructions.
  scheduling_server::ExecutionResult HandleMove(const scheduling_server::Instruction &inst);
  scheduling_server::ExecutionResult HandleExternalBinOp(const scheduling_server::Instruction &inst);
  scheduling_server::ExecutionResult HandleInternalBinOp(const scheduling_server::Instruction &inst);

  // Helper functions.
  // These functions should be called with the lock held.
  void MoveRobot(const scheduling_server::PositionXYT &t, double duration_ms);
  scheduling_server::KubotTray *GetKubotTray(scheduling_server::TrayType type, int tray_id);
  void PrintRobotState() const;

  // Data.
  std::mutex mutex_;
  MockLl *ll_;
  scheduling_server::RestManager* rm_;
  scheduling_server::KubotState ks_;
  uint64_t cur_time_;
  double real_power_level_;

  // Instructions.
  std::list<scheduling_server::Instruction> instructions_;
  bool pause_set_;
  std::list<scheduling_server::Instruction> cancel_instructions_;
};

}

#endif