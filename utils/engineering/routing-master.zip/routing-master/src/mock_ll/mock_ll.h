#ifndef MOCK_LL_H
#define MOCK_LL_H

#include "hiredis/hiredis.h"
#include "rest_manager.h"
#include "ss_constants.h"
#include "messaging_service/messaging_service.h"
#include "mock_ra.h"

namespace mock_ll {

class MockLl {
 public:
  MockLl(messaging_service::MessagingServiceInterface *msi)
      : msi_(msi) {};

  void StateUpdate();

  // Helper functions.
  void SendToRcs(const std::string &body);
  void SendRespToRcs(const std::string &unique_id,
                     uint64_t seq_num,
                     scheduling_server::ExecutionResult result);

  void Init(const std::string &kubot_file);
  void Run();

 private:
  void RedisSet(const std::string &key, const std::string &value);
  void BuildKubots(const std::string &kubot_file, int kubots);
  void BuildThread(const std::string &kubot_info);
  scheduling_server::KubotState GetKubotState(
      int kubot_id, const scheduling_server::PositionXYT &position);

  std::map<std::string, Kubot *> unique_id_to_kubot_;
  // Redis client and a redis helper function.
  redisContext *redis_;

  messaging_service::MessagingServiceInterface *msi_;

  // Rest manager, for charging.
  scheduling_server::RestManager *rm_;
};

}

#endif