#include <algorithm>
#include <iostream>

#include "mock_ll.h"
#include "util/ss_util.h"
#include "interface/message_types.h"
#include "mock_ll_constants.h"
#include "mock_ra.h"

using namespace scheduling_server;
using namespace std;

namespace {

bool IsAtBinOpPosition(const scheduling_server::PositionXYT &a,
                       const scheduling_server::PositionXYT &b) {
  bool x_equals = scheduling_server::DoubleEquals(a.x, b.x);
  bool y_equals = scheduling_server::DoubleEquals(a.y, b.y);
  return x_equals && y_equals;
}

// Moves need to be aligned with theta.
// When x changes, theta is either 0 or pi.
// When y changes, theta is either pi/2 or -pi/2.
bool IsMoveTransitionValid(const scheduling_server::PositionXYT &a,
                           const scheduling_server::PositionXYT &b) {
  bool x_equals = scheduling_server::DoubleEquals(a.x, b.x);
  bool y_equals = scheduling_server::DoubleEquals(a.y, b.y);

  if (!x_equals) {
    return scheduling_server::DoubleEquals(a.theta, kDirectionLeft)
        || scheduling_server::DoubleEquals(a.theta, kDirectionRight);
  }
  if (!y_equals) {
    return scheduling_server::DoubleEquals(a.theta, kDirectionUp)
        || scheduling_server::DoubleEquals(a.theta, kDirectionDown);
  }
  return false;
}

}

namespace mock_ll {

scheduling_server::KubotState Kubot::CopyKs() {
  lock_guard<mutex> lock(mutex_);
  return ks_;
}

void Kubot::EnqueInstruction(const Instruction& inst) {
  lock_guard<mutex> lock(mutex_);

  if (inst.type == MessageType::RCS2LL_PAUSE) {
    pause_set_ = true;
    ll_->SendRespToRcs(ks_.unique_id,
                       inst.seq_num, ExecutionResult::SUCCESS);
  } else if (inst.type == MessageType::RCS2LL_RECOVER) {
    pause_set_ = false;
    ll_->SendRespToRcs(ks_.unique_id,
                       inst.seq_num, ExecutionResult::SUCCESS);
  } else if (inst.type == MessageType::RCS2LL_CANCEL) {
    cancel_instructions_.push_back(inst);
  } else {
    instructions_.push_back(inst);
  }
}

void Kubot::UpdatePowerLevelInternal() {
  double time_diff_ms = GetCurrentTimeSinceEpochMS() - cur_time_;
  cur_time_ = GetCurrentTimeSinceEpochMS();

  if (IsAtChargeStation()) {
    real_power_level_ += time_diff_ms * kChargePercentPerMS;
    ks_.power_level = (int)real_power_level_;
  } else {
    real_power_level_ -= time_diff_ms * kPowerConsumptionPerMS;
    ks_.power_level = (int)real_power_level_;
  }
}

void Kubot::Run() {
  mutex_.lock();
  while (true) {
    UpdatePowerLevelInternal();

    HandleCancel();

    if (pause_set_) {
      ks_.state_type = RobotState::ROBOT_PAUSE;
      SleepWithLockMS(kMockRaSleepTimeMS);
      continue;
    }

    if (instructions_.empty()) {
      SleepWithLockMS(kMockRaSleepTimeMS);
      continue;
    }

    const Instruction &inst = instructions_.front();
    if (ks_.state_type == RobotState::ROBOT_READY_TO_INIT) {
      HandleAtReadyToInit(inst);
    } else if (ks_.state_type == RobotState::ROBOT_IDLE) {
      HandleAtIdle(inst);
    } else if (ks_.state_type == RobotState::ROBOT_RUNNING) {
      HandleAtRunning(inst);
    } else {
      // At state PAUSE, we don't handle any instructions.
      // Actually this branch is not reachable.
      exit(0);
    }
    instructions_.pop_front();
  }
}

// This function needs to be called with the mutex held.
void Kubot::SleepWithLockMS(int ms) {
  mutex_.unlock();
  scheduling_server::SleepMS(ms);
  mutex_.lock();
}

void Kubot::HandleAtReadyToInit(const scheduling_server::Instruction &inst) {
  // At the ROBOT_READY_TO_INIT, only accept the init instruction.
  if (inst.type == MessageType::RCS2LL_INIT) {
    SleepWithLockMS(kKubotInitTimeMS);
    ks_.state_type = RobotState::ROBOT_IDLE;
    ll_->SendRespToRcs(ks_.unique_id,
                       inst.seq_num, ExecutionResult::SUCCESS);
  } else {
    // Decline all other types of instructions.
    ll_->SendRespToRcs(ks_.unique_id,
                       inst.seq_num, ExecutionResult::DECLINE);
  }
}

void Kubot::HandleAtIdle(const Instruction &inst) {
  ExecutionResult result;
  if (inst.type == MessageType::RCS2LL_MOVE) {
    ks_.state_type = RobotState::ROBOT_RUNNING;
    result = HandleMove(inst);
    ks_.state_type = RobotState::ROBOT_IDLE;
  } else if (inst.type == MessageType::RCS2LL_BIN_OP) {
    ks_.state_type = RobotState::ROBOT_RUNNING;
    result = HandleExternalBinOp(inst);
    ks_.state_type = RobotState::ROBOT_IDLE;
  } else if (inst.type == MessageType::RCS2LL_INTERNAL_BIN_OP) {
    ks_.state_type = RobotState::ROBOT_RUNNING;
    result = HandleInternalBinOp(inst);
    ks_.state_type = RobotState::ROBOT_IDLE;
  } else {
    // Decline all other types of instructions.
    ll_->SendRespToRcs(ks_.unique_id,
                       inst.seq_num, ExecutionResult::DECLINE);
    return;
  }
  ll_->SendRespToRcs(ks_.unique_id,
                     inst.seq_num, result);
}

void Kubot::HandleAtRunning(const scheduling_server::Instruction &inst) {
  // Base on current structure, this function is not reachable, because
  // instructions run in sequence.

  // TODO: update the structure to support simultaneous move and fork
  // operations(change height).
  exit(0);
}

KubotTray *Kubot::GetKubotTray(TrayType type, int tray_id) {
  for (auto &tray : ks_.trays) {
    if (tray.type == type && tray.tray_id == tray_id) {
      return &tray;
    }
  }
  return nullptr;
}

void Kubot::MoveRobot(const scheduling_server::PositionXYT &t, double duration_ms) {
  double x_diff = t.x - ks_.pos.x;
  double y_diff = t.y - ks_.pos.y;
  double theta_diff = t.theta - ks_.pos.theta;
  if (DoubleEquals(ks_.pos.theta, kDirectionLeft) && DoubleEquals(t.theta, kDirectionDown)) {
    theta_diff = kHalfPi;
  } else if (DoubleEquals(ks_.pos.theta, kDirectionDown) && DoubleEquals(t.theta, kDirectionLeft)) {
    theta_diff = -kHalfPi;
  }

  int update_steps = floor(duration_ms / kMoveUpdateIntervalMS);

  for (int i = 0; i < update_steps; i++) {
    ks_.pos.x += x_diff / ((double) update_steps);
    ks_.pos.y += y_diff / ((double) update_steps);
    ks_.pos.theta += theta_diff / ((double) update_steps);
    SleepWithLockMS(kMoveUpdateIntervalMS);
  }

  ks_.pos.x = t.x;
  ks_.pos.y = t.y;
  ks_.pos.theta = t.theta;
}

ExecutionResult Kubot::HandleMove(const Instruction &inst) {
  if (IsMoveTransition(ks_.pos, inst.move_inst.target_position)) {
    if (IsMoveTransitionValid(ks_.pos, inst.move_inst.target_position)) {
      double move_dist = GetDist(ks_.pos.x,
                                 ks_.pos.y,
                                 inst.move_inst.target_position.x,
                                 inst.move_inst.target_position.y);
      MoveRobot(inst.move_inst.target_position,
                move_dist / kKubotMoveSpeedMetersPerSecond * kMillisecondsPerSecond);
      return ExecutionResult::SUCCESS;
    } else {
      // Decline if the move transition is not valid.
      return ExecutionResult::DECLINE;
    }
  } else if (IsRotateTransition(ks_.pos, inst.move_inst.target_position)) {
    MoveRobot(inst.move_inst.target_position, kKubotRotationHalfPiTimeMS);
    return ExecutionResult::SUCCESS;
  } else {
    return ExecutionResult::DECLINE;
  }
}

ExecutionResult Kubot::HandleExternalBinOp(const Instruction &inst) {
  if (!IsAtBinOpPosition(ks_.pos, inst.bin_op_inst.map_position)) {
    // The robot is not at the position required by the bin op.
    // Declines the bin op instruction.
    return ExecutionResult::DECLINE;
  }

  KubotTray *fork = GetKubotTray(TrayType::FORK, 0);

  if (inst.bin_op_inst.op_type == BinOpType::PUT_NEAR) {
    // TODO: Add these back once the tray state sensor on robot is ready.
//    if (fork->state == TrayState::FULL) {
//      ks_.fork_height = inst.bin_op_inst.height;
//
//      inventory::Location location;
//      location.x = inst.bin_op_inst.map_position.x;
//      location.y = inst.bin_op_inst.map_position.y;
//      location.bin_id = inst.bin_op_inst.bin_id;
//      location.bin_face = inst.bin_op_inst.orient;
//      location.height = inst.bin_op_inst.height;
//      SendUpdateToIs(location);
//
//      // During sleep the lock is released, so new instructions may be enqueued.
//      SleepWithLockMS(kBinOpTimeMS);
//
//      fork->state = TrayState::EMPTY;
//
//      return ExecutionResult::SUCCESS;
//    } else {
//      // Fork is of state empty or error, cannot take.
//      return ExecutionResult::DECLINE;
//    }
    SleepWithLockMS(kBinOpTimeMS);
    return ExecutionResult::SUCCESS;
  } else if (inst.bin_op_inst.op_type == BinOpType::TAKE_NEAR) {
    // TODO: Add these fields back once the tray state sensor on robot is ready.
//    if (fork->state == TrayState::EMPTY) {
//      SleepWithLockMS(kBinOpTimeMS);
//      fork->state = TrayState::FULL;
//      return ExecutionResult::SUCCESS;
//    } else {
//      // Fork is of state full or error, cannot take.
//      return ExecutionResult::DECLINE;
//    }
    SleepWithLockMS(kBinOpTimeMS);
    return ExecutionResult::SUCCESS;
  } else {
    // Invalid bin op type.
    return ExecutionResult::DECLINE;
  }
}

ExecutionResult Kubot::HandleInternalBinOp(const Instruction &inst) {
  KubotTray *source_tray = GetKubotTray(inst.internal_bin_op_inst.source_tray_type,
                                        inst.internal_bin_op_inst.source_tray_id);
  KubotTray *dest_tray = GetKubotTray(inst.internal_bin_op_inst.dest_tray_type,
                                      inst.internal_bin_op_inst.dest_tray_id);

  if (source_tray == nullptr
      || dest_tray == nullptr) {
    // Invalid source tray or dest tray.
    return ExecutionResult::DECLINE;
  }

  if (source_tray->tray_id == dest_tray->tray_id
      && source_tray->type == dest_tray->type) {
    // Source tray and dest tray is same.
    return ExecutionResult::SUCCESS;
  }

//  if (source_tray->state != TrayState::FULL
//      || dest_tray->state != TrayState::EMPTY) {
//    return ExecutionResult::DECLINE;
//  }

  SleepWithLockMS(kBinOpTimeMS);
//  swap(source_tray->state, dest_tray->state);
  return ExecutionResult::SUCCESS;
}

void Kubot::HandleCancel() {
  CancelStart:

  while (!cancel_instructions_.empty()) {
    Instruction inst = cancel_instructions_.front();
    cancel_instructions_.pop_front();

    if (inst.cancel_inst.target_seq_num == kCancelAllSeqNum) {
      // Cancel all instructions.
      while (!instructions_.empty()) {
        const Instruction &to_cancel = instructions_.front();
        ll_->SendRespToRcs(ks_.unique_id,
                           to_cancel.seq_num, ExecutionResult::CANCLED);
        instructions_.pop_front();
      }
      // The cancel instruction itself succeed.
      ll_->SendRespToRcs(ks_.unique_id,
                         inst.seq_num, ExecutionResult::SUCCESS);
      goto CancelStart;
    } else {
      // Cancel one instruction.
      for (auto it = instructions_.begin()++; it != instructions_.end();) {
        if (it->seq_num == inst.cancel_inst.target_seq_num) {
          ll_->SendRespToRcs(ks_.unique_id,
                             it->seq_num, ExecutionResult::CANCLED);
          it = instructions_.erase(it);
          // The cancel instruction itself succeed.
          ll_->SendRespToRcs(ks_.unique_id,
                             inst.seq_num, ExecutionResult::SUCCESS);
          goto CancelStart;
        } else {
          ++it;
        }
      }
    }
    // Cannot find the one instruction to cancel, the cancel instruction itself failed.
    ll_->SendRespToRcs(ks_.unique_id,
                       inst.seq_num, ExecutionResult::FAIL);
  }
}

void Kubot::PrintRobotState() const {
  cout << "Robot state: " << endl;
  cout << "\t" + ks_.pos.ToJson().dump() << endl;
  for (const auto &tray : ks_.trays) {
    cout << "\t" << tray.ToJson() << endl;
  }
}

}