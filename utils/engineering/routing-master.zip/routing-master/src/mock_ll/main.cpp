#include "mock_ll.h"
#include "messaging_service/messaging_service.h"
#include "messaging_service/local_ms.h"

int main() {
  messaging_service::MessagingServiceInterface* msi;
  msi = new messaging_service::LocalMs();

  mock_ll::MockLl mock_ll(msi);
  mock_ll.Init(scheduling_server::kKubotFilePath);

  // Never returns.
  mock_ll.Run();
  return 0;
}