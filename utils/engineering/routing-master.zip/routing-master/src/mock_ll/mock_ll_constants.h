#ifndef MODULES_MOCK_LL_MOCK_LL_CONSTANTS_H_
#define MODULES_MOCK_LL_MOCK_LL_CONSTANTS_H_

namespace mock_ll {
// Number of test kubots to build.
const int kTestKubots = 4;

const double kMoveUpdateIntervalMS = 10;
const int kKubotInitTimeMS = 2000;
const int kMockRaSleepTimeMS = 100;
const int kRedisUpdateIntervalMS = 100;
const int kBinOpTimeMS = 4500;

// Assumes the robot can run 3 hours with full battery.
const double kPowerConsumptionPerMS = (double) 100 / ((double) 3 * 60 * 60 * 1000);
// Assumes it take 30 minutes to charge to full.
const double kChargePercentPerMS = (double) 100 / ((double) 30 * 60 * 1000);

}

#endif