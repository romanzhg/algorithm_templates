#include "mock_ll.h"

#include <iostream>
#include <fstream>
#include <thread>

#include "collision_detection.h"
#include "mock_ll_constants.h"

#include "ss_constants.h"
#include "util/ss_util.h"
#include "logger/log.h"

#include "hiredis/hiredis.h"
#include "json.hpp"

using namespace scheduling_server;
using namespace std;

namespace mock_ll {

void MockLl::Init(const string &kubot_file) {
  // 1. Build rest manager.
  rm_ = new RestManager(kRestFilePath);

  // 2. Build mock kubots.
  BuildKubots(kubot_file, kTestKubots);

  // 3. Start the syncer thread which read kubot states and update to redis.
  redis_ = redisConnect(kRedisHostname, kRedisPort);
  if (redis_ == nullptr || redis_->err) {
    cout << "Failed to connect to redis" << endl;
    exit(1);
  }

  thread t(&MockLl::StateUpdate, this);

  t.detach();

  LOG(LogLevel::info, "Mock LL server started.");
}

void MockLl::BuildKubots(const std::string &kubot_file, int kubots_to_build) {
  ifstream ifs(kubot_file);
  if (ifs.fail()) {
    throw runtime_error("kubot file failed.");
  }

  string kubot_info;
  int counter = 0;
  while (std::getline(ifs, kubot_info) && counter < kubots_to_build) {
    BuildThread(kubot_info);
    counter++;
  }
  ifs.close();
}

void MockLl::BuildThread(const std::string &kubot_info) {
  vector<string> temp = StrSplit(kubot_info, ',');
  if (temp.size() != 4) {
    cout << "Invalid kubot config." << endl;
    exit(0);
  }
  int kubot_id = stoi(temp[0]);
  PositionXYT position;
  position.x = stod(temp[1]);
  position.y = stod(temp[2]);
  position.theta = stod(temp[3]);

  Kubot *kp = new Kubot(GetKubotState(kubot_id, position), this, rm_);
  unique_id_to_kubot_[kp->GetUniqueName()] = kp;
  thread t(&Kubot::Run, kp);
  t.detach();
}

KubotState MockLl::GetKubotState(int kubot_id, const PositionXYT &position) {
  KubotState ks;
  ks.unique_id = "kubot_un_" + to_string(kubot_id);
  ks.state_type = RobotState::ROBOT_READY_TO_INIT;
  ks.pos = position;
  ks.trays.emplace_back(TrayType::FORK, 0);
  ks.trays.emplace_back(TrayType::BEILOU, 0);
  ks.trays.emplace_back(TrayType::BEILOU, 1);
  ks.trays.emplace_back(TrayType::BEILOU, 2);
  ks.trays.emplace_back(TrayType::BEILOU, 3);
  ks.trays.emplace_back(TrayType::BEILOU, 4);
  ks.trays.emplace_back(TrayType::BEILOU, 5);
  ks.power_level = 95;
  ks.battery_state = BatteryState::NORMAL;
  return ks;
}

// Not thread safe.
void MockLl::RedisSet(const string &key, const string &value) {
  redisReply *reply;
  reply = (redisReply *) redisCommand(redis_, "SET %s %s", key.c_str(), value.c_str());
  freeReplyObject(reply);
}

void MockLl::StateUpdate() {
  while (true) {
    vector<PositionXYT> positions;
    for (auto &elem : unique_id_to_kubot_) {
      Kubot *kp = elem.second;
      KubotState ks = kp->CopyKs();
      nlohmann::json j = ks.ToJson();
      positions.push_back(ks.pos);
      j["lastUpdate"] = GetCurrentTimeSinceEpochMS();
      RedisSet(j["robotId"], j.dump());
    }

    if (CollisionExists(positions)) {
      cout << "Collision" << endl;
      exit(0);
    }

    SleepMS(kRedisUpdateIntervalMS);
  }
}

void MockLl::SendToRcs(const string &body) {
  if (!msi_->SendToSsAsync(body)) {
    cout << "Message buffer overflowed." << endl;
    exit(0);
  }
}

void MockLl::SendRespToRcs(const string &unique_id, uint64_t seq_num, ExecutionResult result) {
  SendToRcs(LlResp(unique_id,
                   MessageType::LL2RCS_RESP,
                   seq_num,
                   result).ToJson().dump());
}

void MockLl::Run() {
  while (true) {
    const string& msg = msi_->BlockingReceiveAsLl();

    nlohmann::json msg_json = nlohmann::json::parse(msg);
    Instruction inst(msg_json);

    if (unique_id_to_kubot_.find(inst.robot_unique_id) == unique_id_to_kubot_.end()) {
      cout << "Invalid kubot id." << endl;
      exit(1);
    }
    LOG(LogLevel::info, "Mock Ll received message: " + msg);
    Kubot *kp = unique_id_to_kubot_[inst.robot_unique_id];

    kp->EnqueInstruction(inst);
  }
}

}