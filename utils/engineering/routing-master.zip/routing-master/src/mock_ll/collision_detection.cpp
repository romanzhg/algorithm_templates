#include "collision_detection.h"

#include "ss_constants.h"

namespace mock_ll {

using namespace std;
using namespace scheduling_server;

const double EPS = 1e-5;

// Return -1 if the value is smaller than 0.
// Return 0 if the value is equal to 0.
// Return 1 if the value is bigger than 0.
int dcmp(double x) {
  if (fabs(x) < EPS) {
    return 0;
  } else {
    return x < 0 ? -1 : 1;
  }
}

struct Point2 {
  double x, y;
  Point2() : x(0), y(0) {};
  Point2(double x, double y) : x(x), y(y) {};
};

const vector<Point2> proto_robot =
    {{kKubotLength / 2, kKubotWidth / 2},
     {kKubotLength / 2, 0},
     {kKubotLength / 2, -kKubotWidth / 2},
     {0, -kKubotWidth / 2},
     {-kKubotLength / 2, -kKubotWidth / 2},
     {-kKubotLength / 2, 0},
     {-kKubotLength / 2, kKubotWidth / 2},
     {0, kKubotWidth / 2}};


typedef Point2 Vector2;
typedef vector<Point2> Polygon;

Vector2 operator+(const Vector2 &a, const Vector2 &b) {
  return Vector2(a.x + b.x, a.y + b.y);
}

Vector2 operator-(const Vector2 &a, const Vector2 &b) {
  return Vector2(a.x - b.x, a.y - b.y);
}

Vector2 operator*(const Vector2 &v, double s) {
  return Vector2(v.x * s, v.y * s);
}

Vector2 operator/(const Vector2 &v, double s) {
  return Vector2(v.x / s, v.y / s);
}

bool operator<(const Point2 &a, const Point2 &b) {
  return a.x < b.x || (a.x == b.x && a.y < b.y);
}

bool operator==(const Point2 &a, const Point2 &b) {
  return dcmp(a.x - b.x) == 0 && dcmp(a.y - b.y) == 0;
}

bool operator!=(const Point2 &a, const Point2 &b) {
  return !(dcmp(b.x - a.x) == 0 && dcmp(b.y - a.y) == 0);
}

// Sign of the product represents the relative angle between a and b.
double crossProduct(const Vector2 &a, const Vector2 &b) {
  return a.x * b.y - a.y * b.x;
}

// Counter clockwise. A negative rad means clockwise.
Vector2 rotateVector2(const Vector2 &a, double rad) {
  return Vector2(a.x * cos(rad) - a.y * sin(rad), a.x * sin(rad) + a.y * cos(rad));
}

// A line is represented by p + tv.
struct Line2 {
  // Direction vector.
  Vector2 v;
  Point2 p;
  // The angle from positive x axis.
  // Positive for rotating counter-clockwise.
  // Negative for rotating clockwise.
  double ang;

  Line2() {};
  Line2(Vector2 v, Point2 p) : v(v), p(p) {
    ang = atan2(v.y, v.x);
  };

  // Get the point at p + tv.
  Point2 point(double t) const {
    return p + v * t;
  };

  Vector2 getDirection() const {
    return v;
  };

  Vector2 getNormalDirection() const {
    return Vector2(-v.y, v.x);
  };
};

// Point p is on left of line l.
bool onLeft(const Line2 &l, const Point2 &p) {
  return crossProduct(l.v, p - l.p) > 0;
}

// Returns 1 if the point is in the polygon.
// Returns 0 if the point is out of the polygon.
int isPointInConvexPolygon(const Point2 &p, const Polygon &poly) {
  int polySize = poly.size();
  for (int i = 0; i < polySize; i++) {
    if (!onLeft(Line2(poly[(i + 1) % polySize] - poly[i], poly[i]), p)) {
      return 0;
    }
  }
  return 1;
}

Point2 RobotCornerToPoint(const Point2& p, const PositionXYT& shift) {
  Point2 rotated = rotateVector2(p, shift.theta);
  rotated.x += shift.x;
  rotated.y += shift.y;
  return rotated;
}

bool Collides(const PositionXYT& a, const PositionXYT& b) {
  if (GetMapPointDist(a, b) > kSafeDistanceMeters) {
    return false;
  }

  // Model robots as polygons.
  Polygon poly_a;
  for (const Point2& p : proto_robot) {
    poly_a.push_back(RobotCornerToPoint(p, a));
  }

  Polygon poly_b;
  for (const Point2& p : proto_robot) {
    poly_b.push_back(RobotCornerToPoint(p, b));
  }

  // Check if any point in robot b is inside robot a.
  for (const Point2& p : poly_a) {
    if (isPointInConvexPolygon(p, poly_b)) {
      return true;
    }
  }
  return false;
}

bool CollisionExists(const vector<PositionXYT>& robots) {
  for (int i = 0; i < robots.size(); i++) {
    for (int j = i + 1; j < robots.size(); j++) {
      if (Collides(robots[i], robots[j])) {
        return true;
      }
    }
  }
  return false;
}

}