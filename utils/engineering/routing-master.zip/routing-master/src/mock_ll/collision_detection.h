#ifndef GEOMETRY_H
#define GEOMETRY_H

#include <vector>

#include "position.h"

namespace mock_ll {

bool CollisionExists(const std::vector<scheduling_server::PositionXYT>& robots);

}

#endif