#ifndef POSITION_XY_H
#define POSITION_XY_H

#include <string>
#include <cmath>

#include "json.hpp"
#include "util/ss_util.h"

namespace scheduling_server {
class PositionXY {
 public:
  PositionXY() = default;
  PositionXY(double x, double y) : x(x), y(y) {};
  PositionXY(const PositionXY &o) = default;
  explicit PositionXY(const nlohmann::json &j) {
    FromJson(j);
  }
  PositionXY &operator=(const PositionXY &o) = default;

  virtual nlohmann::json ToJson() const {
    nlohmann::json j;
    j["x"] = x;
    j["y"] = y;
    return j;
  };

  virtual void FromJson(const nlohmann::json &j) {
    x = j["x"];
    y = j["y"];
  };

  virtual std::string ToString() const { return ToJson().dump(); };

  bool operator==(const PositionXY &rhs) const {
    return DoubleEquals(x, rhs.x) && DoubleEquals(y, rhs.y);
  };

  bool operator!=(const PositionXY &rhs) const {
    return !(operator==(rhs));
  };

  bool operator<(const PositionXY &o) const {
    if (x != o.x) {
      return x < o.x;
    } else {
      return y < o.y;
    }
  }

  double x{NAN};
  double y{NAN};
};

class PositionXYT : public PositionXY {
 public:
  PositionXYT() = default;
  PositionXYT(double x, double y, double theta) {
    this->x = x;
    this->y = y;
    this->theta = theta;
  }
  PositionXYT(const PositionXYT &p) = default;
  explicit PositionXYT(const nlohmann::json &j) {
    x = j["x"];
    y = j["y"];
    theta = j["theta"];
  }

  PositionXYT &operator=(const PositionXYT &o) = default;

  nlohmann::json ToJson() const override {
    auto j = PositionXY::ToJson();
    j["theta"] = theta;
    return j;
  };

  void FromJson(const nlohmann::json &j) override {
    x = j["x"];
    y = j["y"];
    theta = j["theta"];
  };

  std::string ToString() const override { return ToJson().dump(); };

  bool operator==(const PositionXYT &rhs) const {
    return PositionXY::operator==(rhs) && DoubleEquals(theta, rhs.theta);
  };

  bool operator!=(const PositionXYT &rhs) const {
    return !(operator==(rhs));
  };

  bool operator<(const PositionXYT &o) const {
    if (x != o.x) {
      return x < o.x;
    } else if (y != o.y) {
      return y < o.y;
    } else {
      return theta < o.theta;
    }
  }

  double theta{NAN};
};
}

#endif