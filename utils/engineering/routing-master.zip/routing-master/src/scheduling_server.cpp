#include "scheduling_server.h"

#include <algorithm>
#include <list>
#include <string>

#include "interface/message_types.h"
#include "logger/log.h"
#include "path_planner/local_repair_astar.h"
#include "robot_agent/robot_agent.h"
#include "ss_constants.h"
#include "util/ss_util.h"

using namespace std;

namespace {

bool isMessageInvalid(const nlohmann::json &json) {
  // TODO: check "handling-inventories-positions" has x, y and bin id correctly set.
  return false;
}

}  // anonymous

namespace scheduling_server {

// THREAD 1
void SchedulingServer::Run() {
  while (true) {
    string msg = msi_->BlockingReceiveAsSs();
    LOG(LogLevel::info, "Received message: " + msg);

    nlohmann::json json_msg = nlohmann::json::parse(msg);
    if (isMessageInvalid(json_msg)) {
      continue;
    }

    MessageType type = json_msg.at("msgType");
    switch (type) {
      case MessageType::LL2RCS_RESP:HandleLlResponse(json_msg);
        break;
      case MessageType::MC2RCS_PUSH_MISSION:HandleMcPushMission(json_msg);
        break;
      case MessageType::MC2RCS_CANCEL:HandleMcCancel(json_msg);
        break;
      case MessageType::MC2RCS_KILL_ROBOT:HandleMcKill(json_msg);
        break;
      case MessageType::MC2RCS_BIN_UPDATE:HandleMcBinUpdate(json_msg);
        break;
      case MessageType::MC2RCS_DETOUR:HandleMcDetour(json_msg);
        break;
      default:LOG(LogLevel::error, "Invalid message type.");
        exit(0);
    }
  }
}

void SchedulingServer::HandleLlResponse(const nlohmann::json &msg) {
  lock_guard<mutex> lock(mutex_);

  LlResp resp(msg);
  RobotAgent* robot_agent = robot_manager_->GetRobotByUniqueId(resp.robot_unique_id);
  if (robot_agent == nullptr) {
    return;
  }
  robot_agent->HandleLlResponse(resp);
}

void SchedulingServer::HandleMcPushMission(const nlohmann::json &msg) {
  lock_guard<mutex> lock(mutex_);
  McMission m(msg);

  RobotAgent* robot_agent = robot_manager_->GetRobotById(m.msg_body.robot_id);
  if (robot_agent == nullptr) {
    return;
  }
  robot_agent->AddMcMission(m);
}

void SchedulingServer::HandleMcBinUpdate(const nlohmann::json &msg) {
  lock_guard<mutex> lock(mutex_);
  nlohmann::json json_updates = msg["msg-body"];
  if (json_updates.is_array()) {
    for (const auto &json_update : json_updates) {
      McBinUpdate bin_update(json_update);
      RobotAgent* robot_agent = robot_manager_->GetRobotById(bin_update.robot_id);
      if (robot_agent == nullptr) {
        return;
      }
      robot_agent->HandleMcTrayUpdate(bin_update);
    }
  } else {
    // Invalid json format.
  }
}

void SchedulingServer::HandleMcCancel(const nlohmann::json &msg) {
  lock_guard<mutex> lock(mutex_);
  McCancelMission m(msg);

  RobotAgent* robot_agent = robot_manager_->GetRobotById(m.robot_id);
  if (robot_agent == nullptr) {
    return;
  }
  robot_agent->SetCancel();
}

void SchedulingServer::HandleMcKill(const nlohmann::json &msg) {
  lock_guard<mutex> lock(mutex_);
  McKillRobot m(msg);
  RobotAgent* robot_agent = robot_manager_->GetRobotById(m.robot_id);
  if (robot_agent == nullptr) {
    return;
  }
  robot_agent->SetKill();
}

void SchedulingServer::HandleMcDetour(const nlohmann::json &msg) {
  lock_guard<mutex> lock(mutex_);
  McDetour m(msg);
  RobotAgent* robot_agent = robot_manager_->GetRobotById(m.robot_id);
  if (robot_agent == nullptr) {
    return;
  }
  robot_agent->AddMcDetour(m.pos);
}

void SchedulingServer::CheckRobotStateInternal() {
  // 1. Get all robots that holds a charge station, if any robot
  // disappears/not on an charge mission, release the station.
  set<int> charging_robots = rm_->GetRobotsLockedChargeStation();
  for (int rid : charging_robots) {
    bool should_release = true;
    RobotAgent* ra = robot_manager_->GetRobotById(rid);
    if (ra != nullptr && ra->IsOnChargeMission()) {
      should_release = false;
    }
    if (should_release) {
      rm_->FreeChargeStation(rid);
    }
  }

  // 2. Get all robots that holds a rest station. If any robot
  // disappears/(not on a rest mission and not at a rest
  // station location), release the station.
  set<int> resting_robots = rm_->GetRobotsLockedRestStation();
  for (int rid : resting_robots) {
    bool should_release = true;
    RobotAgent* ra = robot_manager_->GetRobotById(rid);
    if (ra != nullptr && (ra->IsOnRestMission() || rm_->IsAtRestStation(ra->GetCurrentPosition()))) {
      should_release = false;
    }
    if (should_release) {
      rm_->FreeRestStation(rid);
    }
  }
}

void SchedulingServer::PublishRobotInfoInternal(const list<PpResponse> &responses) {
  for (const auto &elem : responses) {
    KubotInfo info;
    info.robot_id = elem.robot_id;
    MapPoint mp_target = ss_map_->GetMapPointBySid(elem.target);
    info.target_point = PositionXY(mp_target.x, mp_target.y);
    for (const auto &l : elem.locked_points) {
      const MapPoint& mp_locked = ss_map_->GetMapPointBySid(l);
      info.locked_points.emplace_back(mp_locked.x, mp_locked.y);
    }
    robot_manager_->GetRobotById(elem.robot_id)->GetRobotInfo(
        info.unique_name, info.is_available, info.tray_info);
    RedisSetInternal("robot_info_" + std::to_string(elem.robot_id), info.ToJson().dump());
  }
}

void SchedulingServer::ManageTasks() {
  int round_counter = 0;
  while (true) {
    LOG(LogLevel::trace, "SS thread loop start.");
    mutex_.lock();

    // Bookkeeping on charge and rest stations. Reuse the pp requests already built.
    if (++round_counter % kBookkeepingEveryNRounds == 0) {
      CheckRobotStateInternal();
    }

    // For all robots, build the path_planner request, call path planner,
    // distribute the path_planner response.
    list<PpRequest> requests;
    for (const auto &elem : robot_manager_->GetIdToRobotMap()) {
      requests.push_back(elem.second->BuildPpRequest());
    }

    mutex_.unlock();

    const list<PpResponse>& responses = ppi_->QueryPath(requests);

    mutex_.lock();

    for (const auto &elem : responses) {
      RobotAgent* robot_agent = robot_manager_->GetRobotById(elem.robot_id);
      if (robot_agent == nullptr) {
        // For the rare condition that a robot got deleted when
        // the server was planning for path.
        continue;
      }
      robot_agent->SetPpResponse(elem);
    }

    // Write robot information to redis.
    PublishRobotInfoInternal(responses);

    mutex_.unlock();

    scheduling_server::SleepMS(kTaskManagerThreadSleepMS);
  }
}

void SchedulingServer::UpdateKubotState(const string &unique_id, const KubotState &ks) {
  lock_guard<mutex> lock(mutex_);
  // Allocate robot_id if needed, if a robot get killed and joins again, it will get a new
  // id. For now, the kill robot procedure should be
  // 1. Move robot to a safe place.
  // 2. Shutdown.
  // 3. Issue kill command so it is not in the system.
  // Currently if the robot send updates after it has been removed from the system, it will
  // get registered again.

  RobotAgent* robot_agent = robot_manager_->GetRobotByUniqueId(unique_id);
  if (robot_agent == nullptr) {
    int init_sid = ss_map_->FindSidByPosition(ks.pos);
    if (init_sid == -1) {
      LOG(LogLevel::error, "Invalid position for a new robot. " + ks.pos.ToString());
      return;
    }
    robot_agent = robot_manager_->CreateRobot(unique_id, init_sid);
  }
  robot_agent->SetRobotState(ks);
}

void SchedulingServer::RedisSetInternal(const string &key, const string &value) {
  redisReply *reply;
  // TODO: maybe update redis_ to be a non blocking context, handle error here.
  reply = (redisReply *) redisCommand(redis_, "SET %s %s", key.c_str(), value.c_str());
  freeReplyObject(reply);
}

void SchedulingServer::RemoveRobot(int robot_id) {
  lock_guard<mutex> lock(mutex_);
  robot_manager_->RemoveRobot(robot_id);
}

void SchedulingServer::Init(MessagingServiceInterface* msi) {
  msi_ = msi;
  ss_map_ = new SsMap();
  ss_map_->LoadMap(kMapFilePath);
  ppi_ = new LocalRepairAstar(ss_map_);

  rm_ = new RestManager(kRestFilePath);

  // Connect to redis.
  redis_ = redisConnect(kRedisHostname, kRedisPort);
  if (redis_ == nullptr || redis_->err) {
    LOG(LogLevel::error, "Failed to connect to redis.");
    exit(0);
  }

  robot_manager_ = new RobotManager(this, ss_map_, rm_, msi_) ;

  LOG(LogLevel::info, "Scheduling server started.");
}

}
