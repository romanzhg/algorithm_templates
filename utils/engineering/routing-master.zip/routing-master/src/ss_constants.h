#ifndef MODULES_SCHEDULING_SERVER_COMMON_SS_CONSTANTS_H_
#define MODULES_SCHEDULING_SERVER_COMMON_SS_CONSTANTS_H_

#include <cmath>
#include <cfloat>
#include <cstdint>

namespace scheduling_server {

const bool kDebugMode = false;

// For the connection to the common redis.
const char *const kRedisHostname = "127.0.0.1";
const int kRedisPort = 6379;

const int kMillisecondsPerSecond = 1000;
const int kRobotStateStaleDurationMSecs = 30 * 1000;
const int kRobotStateShouldBeRemovedMSecs = 30 * 1000;
const int kTaskManagerThreadSleepMS = 900;
const int kSyncerPullIntervalMS = 800;
const int kRobotAgentSleepMS = 950;
const int kInternalTaskTimeoutMS = 5 * 60 * 1000;
const int kBookkeepingEveryNRounds = 10;

// Two map points in +/- 0.1 meters are considered same.
const double kMapPointEpsilon = 0.1;
// Two directions in +/- 5 degrees(0.0872665 radian) are considered same.
const double kThetaEpsilon = 0.0872665;
const double kDoubleEpsilon = 0.06;

const double kPi = std::acos(-1);
const double kTwoPi = 2 * kPi;
const double kHalfPi = kPi / 2;
const double kDirectionRight = 0;
const double kDirectionUp = kPi / 2;
const double kDirectionLeft = kPi;
const double kDirectionDown = -kPi / 2;
const double kDoubleInf = DBL_MAX / 2;

const uint64_t kCancelAllSeqNum = UINTMAX_MAX;

// The map file path.
const char *const kMapFilePath = "../data/humen/adjacency_list.in";
const char *const kRestFilePath = "../data/humen/rest_stations.json";
const char *const kKubotFilePath = "../data/humen/kubot.txt";
const char *const kMapModifierFilePath = "../data/humen/map_modifier.json";

// Kubot related data.
const double kKubotLength = 1.540;
const double kKubotWidth = 0.83;
const double kKubotRotationDiameter = 1.62;
const double kKubotRotationHalfPiTimeMS = 2500;
const double kKubotMoveSpeedMetersPerSecond = 1.5;
// If two robots are kSafeDistanceMeters apart, they won't collide.
const double kSafeDistanceMeters = 2;
// Number of trays, includes BEILOU and FORK.
const int kKubotTrayCount = 7;

const int kPowerDangerLimitPercent = 15;
const int kPowerLowLimitPercent = 30;
const int kPowerFullLimitPercent = 95;
const int kPowerEnoughLimitPercent = 55;

// Map related.
// The distance used to find conflicting sids.
// Ideally this should be same as kKubotRotationDiameter.
const double kAdjMapPointRange = 1.8;

// Algorithm related.
const int kLocalRepairAstarDepthLimit = 30000;
// Do not consider conflicts for points * meters away.
const double kLocalRepairAstarConflictWindowMeters = 10;
const double kConflictWindowSeconds = 8;
const int kLocalRepairAstarLockLimit = 8;
const int kLocalRepairAstarReplanLimit = 3;
const int kLocalRepairAstarBufferSize = 1;

// If the robot stands still for * milliseconds, clear all the
// reservations except for its current position. Not used for now.
const uint64_t kLocalRepairAstarClearReservationsWaitTimeMS = 5100;
const uint64_t kPushAfterStandstillMS = 3 * 60 * 1000;
const int kPushExpandSetSize = 20;
const int kRandomMoveMod = 20;

}

#endif // MODULES_SCHEDULING_SERVER_COMMON_SS_CONSTANTS_H_
