#ifndef ROBOT_MANAGER_H
#define ROBOT_MANAGER_H

#include <string>

#include "robot_agent/robot_agent.h"

namespace scheduling_server {

class SchedulingServer;
class SsMap;
class RestManager;
class SsPulsar;

class RobotManager {
 public:
  RobotManager(SchedulingServer *ss, SsMap *ss_map, RestManager *rm, 
      messaging_service::MessagingServiceInterface *msi)
      : ss_(ss), ss_map_(ss_map), rm_(rm), msi_(msi) {};

  RobotAgent *GetRobotByUniqueId(const std::string &unique_id);
  RobotAgent *GetRobotById(int robot_id);
  const std::map<int, RobotAgent *> &GetIdToRobotMap();
  RobotAgent *CreateRobot(const std::string &unique_id, int initial_sid);
  void RemoveRobot(int robot_id);

 private:
  std::map<int, RobotAgent *> id_to_agent_;
  std::vector<std::pair<int, std::string>> id_and_unique_id_;
  int cur_robot_id_ = 1;

  SchedulingServer *ss_;
  SsMap *ss_map_;
  RestManager *rm_;
  MessagingServiceInterface *msi_;
};

}

#endif