#include "log.h"

#include <iostream>

namespace {
const scheduling_server::LogLevel kLogLevel = scheduling_server::LogLevel::debug;
}

namespace scheduling_server {

Log &Log::getLogger() {
  static Log log;
  return log;
}

void Log::log(LogLevel l, const std::string &msg) {
  // Check the min log level.
  // For development we should use debug.
  if (l >= kLogLevel) {
    std::cout << msg << std::endl;
  }
}

void Log::log(const std::string &msg) {
  log(LogLevel::info, msg);
}

}  // end namespace scheduling_server