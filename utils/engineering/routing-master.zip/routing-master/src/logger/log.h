#ifndef LOGGER_LOG_H
#define LOGGER_LOG_H

#include <string>

namespace scheduling_server {
enum class LogLevel : int {
  trace = 0,
  debug = 1,
  info = 2,
  warn = 3,
  error = 4,
};

class Log {
 public:
  static Log &getLogger();
  void log(LogLevel, const std::string &);
  void log(const std::string &msg);

 private:
  Log() = default;
};

} //end namespace scheduling_server

#define LOG(l, msg)   Log::getLogger().log(l, msg)

#endif