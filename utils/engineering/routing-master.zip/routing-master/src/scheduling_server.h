#ifndef SCHEDULING_SERVER_H
#define SCHEDULING_SERVER_H

#include <list>
#include <string>

#include "hiredis/hiredis.h"
#include "json.hpp"
#include "path_planner/path_planner.h"
#include "path_planner/ss_map.h"
#include "robot_manager.h"
#include "rest_manager.h"
#include "messaging_service/messaging_service.h"

namespace scheduling_server {

class RobotAgent;

class SchedulingServer {
 public:
  SchedulingServer() = default;
  ~SchedulingServer() = default;

  void Init(MessagingServiceInterface *msi);
  void Run();
  void ManageTasks();
  void UpdateKubotState(const std::string &unique_id, const KubotState &ks);

  // This function is to be called by robot threads.
  void RemoveRobot(int robot_id);

 private:
  // Handler function.
  void HandleLlResponse(const nlohmann::json &json);
  void HandleMcPushMission(const nlohmann::json &msg);
  void HandleMcBinUpdate(const nlohmann::json &msg);
  void HandleMcCancel(const nlohmann::json &msg);
  void HandleMcKill(const nlohmann::json &msg);
  void HandleMcDetour(const nlohmann::json &msg);

  void CheckRobotStateInternal();
  void PublishRobotInfoInternal(const std::list<PpResponse> &responses);
  void RedisSetInternal(const std::string &key, const std::string &value);

  // Stubs.
  PathPlannerInterface *ppi_;
  SsMap *ss_map_;
  RestManager* rm_;
  redisContext *redis_;
  MessagingServiceInterface *msi_;

  // This mutex protects all data below.
  std::mutex mutex_;
  RobotManager* robot_manager_;
};

}

#endif