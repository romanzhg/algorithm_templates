#include "mock_mc_move.h"

#include <iostream>

#include "hiredis/hiredis.h"
#include "interface/mc_ss_messages.h"
#include "interface/message_types.h"
#include "path_planner/ss_map.h"

using namespace std;
using namespace scheduling_server;

namespace {
PositionXYT GetRandomPositionXYT(SsMap *ss_map_) {
  int state_point_count = ss_map_->GetStatePointCount();
  PositionXYT rtn = ss_map_->GetPositionBySid(rand() % state_point_count);

  // For the humen map, simulate a box pickup.
  while (rtn.y > 30) {
    rtn = ss_map_->GetPositionBySid(rand() % state_point_count);
  }

  return rtn;
}
}  // namespace


void MockMcMove::Start() {
  srand(time(NULL));
  SsMap *ss_map_;
  ss_map_ = new SsMap();
  ss_map_->LoadMap(kMapFilePath);

  redisContext *redis_;
  redis_ = redisConnect(kRedisHostname, kRedisPort);
  if (redis_ == nullptr || redis_->err) {
    cout << "Failed to connect to redis." << endl;
    exit(0);
  }

  std::thread t_consumer(&MockMcMove::MessageConsumer, this);

  // In a loop call get available robots and assign robots random move missions.
  while (op_counter_ > 0) {
    this_thread::sleep_for(chrono::seconds(5));

    redisReply *reply;

    reply = (redisReply *) redisCommand(redis_, "keys robot_info_*");
    if (reply == nullptr) {
      exit(0);
    }
    vector<string> keys;
    if (reply->type != REDIS_REPLY_ARRAY) {
      exit(0);
    }
    for (int j = 0; j < reply->elements; j++) {
      keys.emplace_back(reply->element[j]->str);
    }
    freeReplyObject(reply);

    vector<int> available_kubots;
    for (string key : keys) {
      reply = (redisReply *) redisCommand(redis_, "get %s", key.c_str());
      if (reply == nullptr) {
        exit(0);
      }
      nlohmann::json robot_info_json = nlohmann::json::parse(reply->str);
      if (robot_info_json["isAvailable"]) {
        available_kubots.push_back(robot_info_json["robotId"]);
      }
    }

    cout << "pending ops count: " << to_string(pending_ops_.size()) << endl;

    for (int robot_id : available_kubots) {
      if (IsElapsedTimeShorterThan(robot_id_to_prev_finished_[robot_id],
                                   (rand() % 30) * 1000)) {
        continue;
      }
      // Assign a random mission.
      McMission mission;
      mission.msg_body.mission_id = mission_id_++;
      mission.msg_body.robot_id = robot_id;

      McOperation move_op;
      move_op.type = OpType::MOVE;
      move_op.map_position = GetRandomPositionXYT(ss_map_);
      move_op.op_id = op_id_++;
      pending_ops_.insert(move_op.op_id);

      McOperation to_station_op;
      to_station_op.type = OpType::MOVE;
      to_station_op.map_position = humen_op_station_;
      to_station_op.op_id = op_id_++;
      pending_ops_.insert(to_station_op.op_id);

      McOperation wait_op;
      wait_op.type = OpType::WAIT;
      wait_op.op_id = op_id_++;

      mission.msg_body.operations.push_back(move_op);
      mission.msg_body.operations.push_back(to_station_op);
      op_counter_ -= 2;

      // Add wait only for a portion of tasks.
      if ((rand() % 3) == 0) {
        mission.msg_body.operations.push_back(wait_op);
        op_counter_--;
      }

      cout << "robot " << to_string(robot_id) << " moving to "
           << move_op.map_position.ToString() << endl;

      msi_->SendToSsAsync(mission.ToJson().dump());
    }
  }

  SleepSec(3 * 60);
  if (pending_ops_.empty()) {
    cout << "succeed" << endl;
  } else {
    cout << "failed" << endl;
  }
}

void MockMcMove::MessageConsumer() {
  while (true) {
    string str_msg = msi_->BlockingReceiveAsMc();

    cout << "Received message: " << str_msg << endl;
    nlohmann::json json_msg = nlohmann::json::parse(str_msg);
  }
}
