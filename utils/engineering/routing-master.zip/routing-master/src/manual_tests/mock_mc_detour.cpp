#include <iostream>
#include <cstdlib>
#include <ctime>

#include "pulsar/Client.h"
#include "ss_types.h"
#include "ss_constants.h"

using namespace std;
using namespace scheduling_server;

// Global data.
pulsar::Producer to_ss_;

int main() {
  srand(time(NULL));

  // Build a pulsar client.
  pulsar::Client client_("pulsar://localhost:6650");

  // Build one producer to sent message to SS.
  pulsar::ProducerConfiguration to_ss_config;
  to_ss_config.setSendTimeout(0);
  to_ss_config.setProducerName("sendDetourtoSs");

  pulsar::Result result;
  result = client_.createProducer(kSsTopic, to_ss_config, to_ss_);
  if (result != pulsar::Result::ResultOk) {
    cout << "Failed to connect to pulsar." << endl;
    exit(0);
  }

  while (true) {
    McDetour msg;
    cout << "robot to add detour: " << endl;
    cin >> msg.robot_id;
    cout << "x: " << endl;
    cin >> msg.pos.x;
    cout << "y: " << endl;
    cin >> msg.pos.y;
    cout << "theta: " << endl;
    cin >> msg.pos.theta;

    pulsar::Message detour_command = pulsar::MessageBuilder()
        .setContent(msg.ToJson().dump())
        .build();

    to_ss_.send(detour_command);

  }
  return 0;
}
