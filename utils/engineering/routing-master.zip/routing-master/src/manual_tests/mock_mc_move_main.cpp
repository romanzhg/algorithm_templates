#include "mock_mc_move.h"

int main() {
  return 0;
}