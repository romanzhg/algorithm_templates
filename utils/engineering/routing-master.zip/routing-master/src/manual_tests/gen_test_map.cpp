/**
 * Generate a test map.
 */
#include <iostream>

#include <vector>
#include <utility>

using namespace std;

// int x_low = 10;
// int y_low = 10;
// int x_high = 60;
// int y_high = 60;

// A simple setup.
int x_low = 10;
int y_low = 10;
int x_high = 30;
int y_high = 10;

bool InRange(pair<int, int> p) {
  if (p.first < x_low || p.first > x_high) {
    return false;
  }
  if (p.second < y_low || p.second > y_high) {
    return false;
  }
  return true;
}

int main() {
  vector<pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

  for (int x = x_low; x <= x_high; x++) {
    for (int y = y_low; y <= y_high; y++) {
      cout << x << "," << y << "," << "0" << ":";
      bool first_adj = true;
      int tmp_x, tmp_y;
      for (const auto &p : directions) {
        tmp_x = x + p.first;
        tmp_y = y + p.second;
        if (InRange({tmp_x, tmp_y})) {
          if (first_adj) {
            first_adj = false;
          } else {
            cout << ";";
          }
          cout << tmp_x << "," << tmp_y;
        }
      }
      cout << endl;
    }
  }

  return 0;
}