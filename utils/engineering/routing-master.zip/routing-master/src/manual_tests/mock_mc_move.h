#ifndef ROUTING_SRC_MANUAL_TESTS_MOCK_MC_MOVE_H_
#define ROUTING_SRC_MANUAL_TESTS_MOCK_MC_MOVE_H_

#include <set>
#include <map>

#include "messaging_service/local_ms.h"
#include "position.h"

class MockMcMove {
 public:
  MockMcMove(messaging_service::MessagingServiceInterface* msi)
  : msi_(msi) {};

  void Start();

 private:
  // Helper functions.
  void MessageConsumer();

  // Stubs.
  messaging_service::MessagingServiceInterface* msi_;

  // Data.
  int op_id_ = 0;
  int mission_id_ = 0;
  scheduling_server::PositionXYT humen_op_station_{15.0, 32.685, 3.14159};
  int op_counter_ = 100;
  std::map<int, uint64_t> robot_id_to_prev_finished_;
  std::set<int> pending_ops_;
};

#endif //ROUTING_SRC_MANUAL_TESTS_MOCK_MC_MOVE_H_
