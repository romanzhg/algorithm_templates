#include <iostream>
#include <thread>
#include "pulsar/Client.h"
#include "ss_types.h"
#include "ss_constants.h"

const int KUBOT_ID = 135;



using namespace pulsar;
using namespace std;
using namespace scheduling_server;

Producer to_ss;

void HandleRemove(McMissionBinOp &bin_load, McMissionBinOp &bin_unload);
void HandleLoad(McMissionBinOp &bin_load);
void HandleUnload(McMissionBinOp &bin_unload);
void SendBinMission() {
  McMission mission;
  mission.type = MessageType::MC2RCS_PUSH_MISSION;
  mission.msg_body.mission_id = 0;
  mission.msg_body.kubot_id = KUBOT_ID;

  McMissionBinOp bin_load{};

  McMissionBinOp bin_unload{};

  cout << "enter: 0.remove 1.load 2.unload" << endl;

  int flag;
  cin >> flag;
  switch (flag) {
    case 0:HandleRemove(bin_load, bin_unload);
      mission.msg_body.bin_operations.push_back(bin_load);
      mission.msg_body.bin_operations.push_back(bin_unload);
      break;
    case 1:HandleLoad(bin_load);
      mission.msg_body.bin_operations.push_back(bin_load);
      break;
    case 2:HandleUnload(bin_unload);
      mission.msg_body.bin_operations.push_back(bin_unload);
      break;
    default:exit(1);
  }

  Message bin_mission = MessageBuilder().setContent(mission.ToJson().dump()).build();
  to_ss.send(bin_mission);
}
void HandleRemove(McMissionBinOp &bin_load, McMissionBinOp &bin_unload) {
  HandleLoad(bin_load);
  HandleUnload(bin_unload);
}
void HandleUnload(McMissionBinOp &bin_unload) {
  double x, y;
  int face,
      binId,
      height;
  cout << "enter unload x, y, height, face, binId: " << endl;
  cin >> x >> y >> height >> face >> binId;
  bin_unload.bin_id = binId;
  bin_unload.x = x;
  bin_unload.y = y;
  bin_unload.fork_height = height;
  bin_unload.bin_orient = face;
  bin_unload.type = TransferType::UNLOAD;
}
void HandleLoad(McMissionBinOp &bin_load) {
  double x, y;
  int face,
      binId,
      height;
  cout << "enter load x, y, height, face, binId: " << endl;
  cin >> x >> y >> height >> face >> binId;
  bin_load.bin_id = binId;
  bin_load.x = x;
  bin_load.y = y;
  bin_load.fork_height = height;
  bin_load.bin_orient = face;
  bin_load.type = TransferType::LOAD;
}

void SendMoveMission() {
  McMission mission;
  mission.type = MessageType::MC2RCS_PUSH_MISSION;
  mission.msg_body.mission_id = 0;
  mission.msg_body.kubot_id = KUBOT_ID;
  McMissionDest dest{};
  double x, y, t;
  cout << "x,y,t: " << endl;
  cin >> x >> y >> t;
  dest.x = x;
  dest.y = y;
  dest.theta = t;
  mission.msg_body.destination_position.push_back(dest);
  Message move_mission = MessageBuilder().setContent(mission.ToJson().dump()).build();

  cout << "robot " << 0 << " moving to " + to_string(x) + " " + to_string(y) + " " + to_string(t) << endl;

  to_ss.send(move_mission);
}

int main() {
  //pulsar
  Client client("pulsar://localhost:6650");
  Consumer consumer;

  Result result;
  result = client.subscribe("persistent://public/default/mc", "mc_pulsar", consumer);
  if (result != Result::ResultOk) {
    exit(1);
  }
  ProducerConfiguration to_ss_config;
  to_ss_config.setSendTimeout(0);
  to_ss_config.setProducerName("mcToSs");
  result = client.createProducer("persistent://public/default/ss", to_ss_config, to_ss);
  if (result != pulsar::Result::ResultOk) {
    exit(1);
  }

  thread([&consumer]() {
    while (true) {
      Message msg;
      consumer.receive(msg);
      consumer.acknowledge(msg);
    }
  }).detach();

  int move_or_bin_or_exit;
  while (true) {
    cout << "enter mission: 0.move 1.bin -1.exit" << endl;
    cin >> move_or_bin_or_exit;
    switch (move_or_bin_or_exit) {
      case -1:return 0;
      case 0:SendMoveMission();
        break;
      case 1:SendBinMission();
        break;
      default:return 0;
    }
  }
}