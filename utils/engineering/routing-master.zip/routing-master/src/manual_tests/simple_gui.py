import tkinter as tk
import threading
import time
import redis
import cmath
import json

# corresponds to 90 meters
CANVAS_WIDTH = 900
CANVAS_HEIGHT = 900
CANVAS_HEIGHT_SHIFT = -100

class Robot(object):
    x = float()
    y = float()
    theta = float()
    last_update_time = int()
    canvas = None
    poly = None
    line_to_target = None
    reserved_points = []

    # The robot body.
    body = [(7, 4), (9, 0), (7, -4), (-7, -4), (-7, 4)]

    def __init__(self, c):
        self.canvas = c

    def update(self, new_state):
        # First parse state.
        ks = json.loads(new_state)
        self.x = ks["mapPosition"]["x"] * 10
        self.y = ks["mapPosition"]["y"] * 10
        self.theta = ks["mapPosition"]["theta"]
        self.last_update_time = ks["lastUpdate"]

        # Then draw the car.
        if self.poly is None:
            self.poly = self.canvas.create_polygon(*(self.get_points()), fill='blue')
        else:
            self.canvas.coords(self.poly, *(self.get_points()))

    def update_reservation(self, info):
        # Draw the line to the target.
        target_x = info["targetPoint"]["x"] * 10
        target_y = info["targetPoint"]["y"] * 10

        new_xy = [self.x,
                  CANVAS_HEIGHT - self.y + CANVAS_HEIGHT_SHIFT,
                  target_x,
                  CANVAS_HEIGHT - target_y + CANVAS_HEIGHT_SHIFT]
        if self.line_to_target is None:
            self.line_to_target = self.canvas.create_line(*(new_xy), fill="red")
        else:
            self.canvas.coords(self.line_to_target, *(new_xy))

        # Clear all previous locked points.
        for elem in self.reserved_points:
            self.canvas.delete(elem)

        # Draw the locked points.
        for elem in info["lockedPoints"]:
            l_x = elem["x"] * 10
            l_y = elem["y"] * 10
            # print("locked points x and y: " + str(l_x) + "," + str(l_y))
            self.reserved_points.append(
                self.canvas.create_rectangle(
                    l_x - 2,
                    CANVAS_HEIGHT - (l_y - 2) + CANVAS_HEIGHT_SHIFT,
                    l_x + 2,
                    CANVAS_HEIGHT - (l_y + 2) + CANVAS_HEIGHT_SHIFT,
                    fill="red"
                )
            )

    def cleanup(self):
        # Remove the rectangular if the robot is not updated for sometime.
        pass

    def get_points(self):
        offset = complex(self.x, self.y)
        cangle = cmath.exp(self.theta * 1j)  # theta in radians
        new_xy = []
        for a, b in self.body:
            v = cangle * (complex(a, b)) + offset
            new_xy.append(v.real)
            new_xy.append(CANVAS_HEIGHT - v.imag + CANVAS_HEIGHT_SHIFT)
        return new_xy


class RobotManager(object):
    canvas = None
    redis_client = None
    id_to_robot = {}

    def __init__(self, c):
        self.canvas = c

    def run(self):
        self.redis_client = redis.Redis(host='localhost', port=6379, db=0)
        while True:
            time.sleep(0.05)

            keys = self.redis_client.keys("kubot_*")
            if keys is None:
                continue

            for key in keys:
                value = self.redis_client.get(key)
                if value is None:
                    continue
                key_str = str(key, 'utf-8')
                if key_str not in self.id_to_robot:
                    self.id_to_robot[key_str] = Robot(self.canvas)
                self.id_to_robot[key_str].update(value)

            keys = self.redis_client.keys("robot_info_*")
            for key in keys:
                value = self.redis_client.get(key)
                if value is None:
                    continue
                robot_info = json.loads(value)
                robot_unique_id = robot_info["robotUniqueName"]
                self.id_to_robot[robot_unique_id].update_reservation(robot_info)

            for robot in self.id_to_robot.values():
                robot.cleanup()

def draw_special_point(x, y, canvas):
    x = x * 10
    y = y * 10
    canvas.create_rectangle(x - 2, CANVAS_HEIGHT - (y - 2) + CANVAS_HEIGHT_SHIFT,
                            x + 2, CANVAS_HEIGHT - (y + 2) + CANVAS_HEIGHT_SHIFT, fill="red")


def main():
    root = tk.Tk()

    canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT)
    canvas.pack()

    # Draw the map.
    fp = open("../data/humen/adjacency_list.in", "r")
    for line in fp:
        point = line.split(',')
        x = float(point[0]) * 10
        y = float(point[1]) * 10
        canvas.create_rectangle(x, CANVAS_HEIGHT - y + CANVAS_HEIGHT_SHIFT,
                                x, CANVAS_HEIGHT - y + CANVAS_HEIGHT_SHIFT, fill="black")
    fp.close()

    rm = RobotManager(canvas)

    t = threading.Thread(name='run', target=rm.run)
    t.start()

    root.mainloop()


if __name__ == '__main__':
    main()
