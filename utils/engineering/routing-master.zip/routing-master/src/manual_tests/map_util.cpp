/**
 * A map utility to verify various things.
 */
#include <iostream>
#include <random>
#include <thread>
#include <chrono>
#include <cstdlib>
#include <ctime>

#include "json.hpp"
#include "ss_types.h"
#include "ss_constants.h"
#include "path_planner/ss_map.h"

using namespace std;
using namespace scheduling_server;


int main() {
  SsMap *ss_map;
  ss_map = new SsMap();
  ss_map->LoadMap(kMapFilePath);

//  int sid = ss_map->FindSidByPosition(PositionXYT(15.0, 32.685, kDirectionLeft));
//  auto adjs = ss_map->GetAdjSids(sid);
//  cout << "adj: " << endl;
//  for (int adj_sid : adjs) {
//    cout << ss_map->GetPositionBySid(adj_sid).ToString() << endl;
//  }

  {
    double x = 43.770;
    double y = 29.990;
    int cur_sid = ss_map->FindSidByPosition(PositionXYT(x, y, kDirectionRight));
    const set<int>& conflict_sids = ss_map->GetSidsToLock(cur_sid);
    for (int sid : conflict_sids) {
      cout << "conflict position: " << ss_map->GetPositionBySid(sid).ToString() << endl;
    }
    cout << endl;
  }

  {
    double x = 46.753;
    double y = 25.15;
    int cur_sid = ss_map->FindSidByPosition(PositionXYT(x, y, kDirectionRight));
    const set<int>& conflict_sids = ss_map->GetSidsToLock(cur_sid);
    for (int sid : conflict_sids) {
      cout << "conflict position: " << ss_map->GetPositionBySid(sid).ToString() << endl;
    }
    cout << endl;
  }

  {
    double x = 22.718;
    double y = 22.73;
    int cur_sid = ss_map->FindSidByPosition(PositionXYT(x, y, kDirectionRight));
    const set<int>& conflict_sids = ss_map->GetSidsToLock(cur_sid);
    for (int sid : conflict_sids) {
      cout << "conflict position: " << ss_map->GetPositionBySid(sid).ToString() << endl;
    }
    cout << endl;
  }

  return 0;
}