#include <iostream>
#include <random>
#include <thread>
#include <chrono>
#include <cstdlib>
#include <ctime>

#include "pulsar/Client.h"
#include "json.hpp"
#include "ss_types.h"
#include "ss_constants.h"

using namespace std;
using namespace scheduling_server;

// Global data.
pulsar::Consumer consumer_;
pulsar::Producer to_ss_;

void PulsarConsumerThread() {
  while (true) {
    pulsar::Message msg;
    consumer_.receive(msg);
    consumer_.acknowledge(msg);
    string str_msg = msg.getDataAsString();
    cout << "Received message: " << str_msg << endl;
  }
}

int main() {
  srand(time(NULL));

  int robot_to_kill = 0;

  SsMap *ss_map_;
  // Build a pulsar client.
  pulsar::Client client_("pulsar://localhost:6650");

  pulsar::Result result;
  result = client_.subscribe(kMcTopic, "ss_pulsar", consumer_);
  if (result != pulsar::Result::ResultOk) {
    // TODO: use global logger to log error.
    exit(1);
  }

  // Build one producer to sent message to SS.
  pulsar::ProducerConfiguration to_ss_config;
  to_ss_config.setSendTimeout(0);
  to_ss_config.setProducerName("mcToSs");

  result = client_.createProducer(kSsTopic, to_ss_config, to_ss_);
  if (result != pulsar::Result::ResultOk) {
    exit(1);
  }

  // The kill robot message.
  nlohmann::json kill_robot_json = {{"msgType", MessageType::MC2RCS_KILL_ROBOT},
                                    {"msgBody", {{"kobotId", robot_to_kill}}}};

  pulsar::Message kill_robot_command = pulsar::MessageBuilder()
      .setContent(kill_robot_json.dump())
      .build();

  to_ss_.send(kill_robot_command);

  return 0;
}