#include <iostream>
#include <random>
#include <thread>
#include <chrono>
#include <cstdlib>
#include <ctime>

#include "pulsar/Client.h"
#include "json.hpp"
#include "ss_types.h"
#include "ss_constants.h"
#include "hiredis/hiredis.h"
#include "path_planner/ss_map.h"

using namespace std;
using namespace scheduling_server;

// Global data.
pulsar::Consumer consumer_;
pulsar::Producer to_ss_;

PositionXYT GetRandomPositionXYT(SsMap *ss_map_) {
  int state_point_count = ss_map_->GetStatePointCount();
  return ss_map_->GetPositionBySid(rand() % state_point_count);
}

void PulsarConsumerThread() {
  while (true) {
    pulsar::Message msg;
    consumer_.receive(msg);
    consumer_.acknowledge(msg);
    string str_msg = msg.getDataAsString();
    cout << "Received message: " << str_msg << endl;
  }
}

int main() {
  srand(time(NULL));

  int op_id = 0;

  map<int, int> robot_id_to_op_count;

  SsMap *ss_map_;
  // Build a pulsar client.
  pulsar::Client client_("pulsar://localhost:6650");

  pulsar::Result result;
  result = client_.subscribe(kMcTopic, "ss_pulsar", consumer_);
  if (result != pulsar::Result::ResultOk) {
    // TODO: use global logger to log error.
    exit(1);
  }

  // Build one producer to sent message to SS.
  pulsar::ProducerConfiguration to_ss_config;
  to_ss_config.setSendTimeout(0);
  to_ss_config.setProducerName("mcToSs");

  result = client_.createProducer(kSsTopic, to_ss_config, to_ss_);
  if (result != pulsar::Result::ResultOk) {
    exit(1);
  }

  redisContext *redis_;
  redis_ = redisConnect(kRedisHostname, kRedisPort);
  if (redis_ == nullptr || redis_->err) {
    cout << "Failed to connect to redis." << endl;
    exit(0);
  }

  // GetMap
  ss_map_ = new SsMap();
  ss_map_->LoadMap(kMapFilePath);

  std::thread t_consumer(PulsarConsumerThread);

  // In a loop call get available robots and assign robots random move missions.
  while (true) {
    this_thread::sleep_for(chrono::seconds(5));

    redisReply *reply;

    reply = (redisReply *) redisCommand(redis_, "keys robot_info_*");
    if (reply == nullptr) {
      exit(0);
    }
    vector<string> keys;
    if (reply->type != REDIS_REPLY_ARRAY) {
      exit(0);
    }
    for (int j = 0; j < reply->elements; j++) {
      keys.emplace_back(reply->element[j]->str);
    }
    freeReplyObject(reply);

    vector<int> available_kubots;
    for (string key : keys) {
      reply = (redisReply *) redisCommand(redis_, "get %s", key.c_str());
      if (reply == nullptr) {
        exit(0);
      }
      nlohmann::json robot_info_json = nlohmann::json::parse(reply->str);
      if (robot_info_json["isAvailable"]) {
        available_kubots.push_back(robot_info_json["robotId"]);
      }
    }

    cout << "available robots: ";
    for (int id : available_kubots) {
      cout << to_string(id) << " ";
    }
    cout << endl;

    for (int kubot_id : available_kubots) {

      int op_count = robot_id_to_op_count[kubot_id];
      int bin_id;
      OpType op_type;
      if (op_count % 2 == 0) {
        bin_id = op_count;
        op_type = OpType::LOAD;
      } else {
        bin_id = op_count - 1;
        op_type = OpType::UNLOAD;
      }
      robot_id_to_op_count[kubot_id]++;

      // Assign a random mission.
      McMission mission;
      mission.msg_body.mission_id = 0;
      mission.msg_body.robot_id = kubot_id;

      McOperation bin_op;
      bin_op.type = op_type;
      bin_op.map_position = GetRandomPositionXYT(ss_map_);
      bin_op.op_id = op_id++;
      bin_op.fork_height = 2;
      bin_op.fork_orient = 3;
      bin_op.bin_id = bin_id;

      McOperation wait_op;
      wait_op.type = OpType::WAIT;
      wait_op.op_id = op_id++;

      mission.msg_body.operations.push_back(bin_op);
      mission.msg_body.operations.push_back(wait_op);

      cout << "sending out command: " << mission.ToJson().dump() << endl;

      pulsar::Message push_mission = pulsar::MessageBuilder()
          .setContent(mission.ToJson().dump())
          .build();

      to_ss_.send(push_mission);
    }
  }
  return 0;
}