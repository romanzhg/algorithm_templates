#include <cstdio>
#include <cstdlib>
#include <iostream>

#include "hiredis/hiredis.h"

using namespace std;

int main() {
  redisContext *c;
  redisReply *reply;
  const char *hostname = "127.0.0.1";
  int port = 6379;
  c = redisConnect(hostname, port);
  if (c == NULL || c->err) {
    printf("error 0\n");
    exit(0);
  }

  reply = (redisReply*)redisCommand(c,"KEYS demo_*");
//  printf("reply type: %s\n", reply->type);
  if (reply->type == REDIS_REPLY_ARRAY) {
    printf("reply is array\n");
    for (int j = 0; j < reply->elements; j++) {
      printf("%u) %s\n", j, reply->element[j]->str);
    }
  } else {
    printf("reply is not array\n");
  }

  freeReplyObject(reply);
  redisFree(c);

  return 0;
}