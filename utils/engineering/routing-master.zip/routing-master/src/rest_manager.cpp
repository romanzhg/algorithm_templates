#include "rest_manager.h"

#include <fstream>

#include "logger/log.h"

namespace scheduling_server {

using namespace std;

RestManager::RestManager(const string &rest_file) {
  ifstream ifs;
  ifs.open(rest_file);
  if (ifs.fail()) {
    throw runtime_error("Failed to load rest file.");
  }

  nlohmann::json rest_json;
  ifs >> rest_json;
  if (!CheckRestJson(rest_json)) {
    throw runtime_error("rest json failed.");
  }
  for (const auto &rest :rest_json["rest-stations"]) {
    rest_stations_.emplace_back(rest);
  }
  for (const auto &charge:rest_json["charge-stations"]) {
    charge_stations_.emplace_back(charge);
  }
  rest_station_lock_table_.resize(rest_stations_.size());
  charge_station_lock_table_.resize(charge_stations_.size());

  for (int i = 0; i < rest_station_lock_table_.size(); i++) {
    rest_station_lock_table_[i] = -1;
  }

  for (int i = 0; i < charge_station_lock_table_.size(); i++) {
    charge_station_lock_table_[i] = -1;
  }
}

RestManager::RestManager(const vector<PositionXYT> &rest_stations,
                         const vector<PositionXYT> &charge_stations)
    : rest_stations_(rest_stations), charge_stations_(charge_stations) {

  rest_station_lock_table_.resize(rest_stations_.size());
  charge_station_lock_table_.resize(charge_stations_.size());

  for (int i = 0; i < rest_station_lock_table_.size(); i++) {
    rest_station_lock_table_[i] = -1;
  }

  for (int i = 0; i < charge_station_lock_table_.size(); i++) {
    charge_station_lock_table_[i] = -1;
  }
}

optional<PositionXYT> RestManager::LockRestStation(int robot_id) {
  lock_guard<mutex> lock(mutex_);

  // First check if the station is already locked.
  for (int i = 0; i < rest_station_lock_table_.size(); i++) {
    if (rest_station_lock_table_[i] == robot_id) {
      return rest_stations_[i];
    }
  }

  // Lock and return a rest station.
  for (int i = 0; i < rest_station_lock_table_.size(); i++) {
    if (rest_station_lock_table_[i] == -1) {
      rest_station_lock_table_[i] = robot_id;
      return rest_stations_[i];
    }
  }

  return std::nullopt;
}

optional<PositionXYT> RestManager::LockChargeStation(int robot_id) {
  lock_guard<mutex> lock(mutex_);

  for (int i = 0; i < charge_station_lock_table_.size(); i++) {
    if (charge_station_lock_table_[i] == robot_id) {
      return charge_stations_[i];
    }
  }

  for (int i = 0; i < charge_station_lock_table_.size(); i++) {
    if (charge_station_lock_table_[i] == -1) {
      charge_station_lock_table_[i] = robot_id;
      return charge_stations_[i];
    }
  }

  return std::nullopt;
}

bool RestManager::CheckRestJson(const nlohmann::json &json) {
  return json["rest-stations"].is_array() && json["charge-stations"].is_array();
}

bool RestManager::IsAtRestStation(const PositionXYT& pos) const {
  for (const PositionXYT& rest_station : rest_stations_) {
    if (IsPositionSameLowPrecision(pos, rest_station)) {
      return true;
    }
  }
  return false;
}

bool RestManager::IsAtChargeStation(const PositionXYT& pos) const {
  for (const PositionXYT& charge_station : charge_stations_) {
    if (IsPositionSameLowPrecision(pos, charge_station)) {
      return true;
    }
  }
  return false;
}

std::set<int> RestManager::GetRobotsLockedRestStation() {
  set<int> rtn;
  for (int r : rest_station_lock_table_) {
    if (r != -1) {
      rtn.insert(r);
    }
  }
  return rtn;
}

std::set<int> RestManager::GetRobotsLockedChargeStation() {
  set<int> rtn;
  for (int r : charge_station_lock_table_) {
    if (r != -1) {
      rtn.insert(r);
    }
  }
  return rtn;
}

void RestManager::FreeRestStation(int robot_id) {
  for (int index = 0; index < rest_station_lock_table_.size(); index++) {
    if (rest_station_lock_table_[index] == robot_id) {
      rest_station_lock_table_[index] = -1;
      return;
    }
  }

  // Invalid state.
  exit(0);
}

void RestManager::FreeChargeStation(int robot_id) {
  for (int index = 0; index < charge_station_lock_table_.size(); index++) {
    if (charge_station_lock_table_[index] == robot_id) {
      charge_station_lock_table_[index] = -1;
      return;
    }
  }

  // Invalid state.
  exit(0);
}

}