#include <ctime>
#include <thread>

#include "scheduling_server.h"
#include "ss_syncer.h"
#include "messaging_service/local_ms.h"
#include "mock_ll/mock_ll.h"
#include "manual_tests/mock_mc_move.h"
#include "util/ss_util.h"

using messaging_service::MessagingServiceInterface;

void StartMockLl(MessagingServiceInterface* msi) {
  mock_ll::MockLl mock_ll(msi);
  mock_ll.Init(scheduling_server::kKubotFilePath);

  // Never returns.
  mock_ll.Run();
}

void StartSs(MessagingServiceInterface* msi) {
  scheduling_server::SchedulingServer ss;
  ss.Init(msi);

  scheduling_server::SsSyncer syncer(&ss);

  // Start one thread to run syncer.
  std::thread t0(&scheduling_server::SsSyncer::Run, &syncer);
  t0.detach();

  // Start one thread to run SchedulingServer::manageTasks.
  std::thread t1(&scheduling_server::SchedulingServer::ManageTasks, &ss);
  t1.detach();

  // Main thread. Never return.
  ss.Run();
}

void StartMockMc(MessagingServiceInterface* msi) {
  MockMcMove mv(msi);
  mv.Start();
}

int main() {
  srand(time(nullptr));

  MessagingServiceInterface* msi = new messaging_service::LocalMs();

  std::thread t0(&StartMockLl, msi);
  t0.detach();

  scheduling_server::SleepSec(10);

  std::thread t1(&StartSs, msi);
  t1.detach();

  scheduling_server::SleepSec(10);

  StartMockMc(msi);
  return 0;
}