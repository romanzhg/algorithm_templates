#ifndef REST_MANAGER_H
#define REST_MANAGER_H

#include <optional>
#include <mutex>
#include <set>
#include <vector>

#include "position.h"

namespace scheduling_server {

class RestManager {
 public:
  RestManager(const std::string &rest_file);
  RestManager(const std::vector<PositionXYT> &rest_stations,
              const std::vector<PositionXYT> &charge_stations);

  std::optional<PositionXYT> LockRestStation(int robot_id);
  std::optional<PositionXYT> LockChargeStation(int robot_id);

  bool IsAtRestStation(const PositionXYT& pos) const;
  bool IsAtChargeStation(const PositionXYT& pos) const;

  std::set<int> GetRobotsLockedRestStation();
  std::set<int> GetRobotsLockedChargeStation();

  void FreeRestStation(int robot_id);
  void FreeChargeStation(int robot_id);

 private:
  std::vector<PositionXYT> rest_stations_;
  std::vector<PositionXYT> charge_stations_;

  std::mutex mutex_;
  std::vector<int> rest_station_lock_table_;
  std::vector<int> charge_station_lock_table_;
  bool CheckRestJson(const nlohmann::json &json);
};
}

#endif
