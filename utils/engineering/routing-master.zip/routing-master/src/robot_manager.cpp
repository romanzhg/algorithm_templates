#include "robot_manager.h"

#include "logger/log.h"

namespace scheduling_server {

using namespace std;

RobotAgent *RobotManager::GetRobotByUniqueId(const string &unique_id) {
  for (auto &elem : id_and_unique_id_) {
    if (elem.second == unique_id) {
      return GetRobotById(elem.first);
    }
  }
  return nullptr;
}

RobotAgent *RobotManager::GetRobotById(int robot_id) {
  if (id_to_agent_.find(robot_id) == id_to_agent_.end()) {
    return nullptr;
  } else {
    return id_to_agent_.at(robot_id);
  }
}

const std::map<int, RobotAgent *> &RobotManager::GetIdToRobotMap() {
  return id_to_agent_;
}

RobotAgent *RobotManager::CreateRobot(const string &unique_id, int initial_sid) {
  assert(GetRobotByUniqueId(unique_id) == nullptr);

  int robot_id = cur_robot_id_++;
  id_and_unique_id_.emplace_back(robot_id, unique_id);

  id_to_agent_[robot_id] = new RobotAgent(
      robot_id, unique_id, ss_, msi_, ss_map_, rm_, initial_sid);

  thread t(&RobotAgent::Process, id_to_agent_[robot_id]);
  t.detach();

  LOG(LogLevel::info, "Create robot with id: " + std::to_string(robot_id));

  return id_to_agent_[robot_id];
}

void RobotManager::RemoveRobot(int robot_id) {
  id_to_agent_.erase(robot_id);

  for (auto it = id_and_unique_id_.cbegin(); it != id_and_unique_id_.cend(); ++it) {
    if (it->first == robot_id) {
      id_and_unique_id_.erase(it);
      return;
    }
  }

  LOG(LogLevel::error, "Cannot find the robot to delete.");
  exit(0);
}

}
