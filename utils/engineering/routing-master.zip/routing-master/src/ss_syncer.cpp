#include "ss_syncer.h"

#include "logger/log.h"
#include "interface/ss_ll_messages.h"
#include "util/ss_util.h"
#include "ss_constants.h"
#include "position.h"

using namespace std;

namespace scheduling_server {
SsSyncer::SsSyncer(scheduling_server::SchedulingServer *ssp) :
    ssp_(ssp) {
  redis_ = redisConnect(kRedisHostname, kRedisPort);
  if (redis_ == NULL || redis_->err) {
    LOG(LogLevel::error, "Failed to connect to redis.");
    exit(0);
  }
}

void SsSyncer::Run() {
  while (true) {
    LOG(LogLevel::trace, "Syncer thread loop start.");
    // TODO: query the keys only sometimes. 1 in 10?
    // TODO: add a timer for the one pass.
    redisReply *reply;

    reply = (redisReply *) redisCommand(redis_, "keys kubot_*");
    if (reply == nullptr) {
      LOG(LogLevel::error, "Redis query failed. " + string(redis_->errstr));
      exit(0);
    }
    vector<string> keys;
    if (reply->type != REDIS_REPLY_ARRAY) {
      LOG(LogLevel::error, "Redis query failed.");
      exit(0);
    }
    for (int j = 0; j < reply->elements; j++) {
      keys.emplace_back(reply->element[j]->str);
    }
    freeReplyObject(reply);

    uint64_t time_ms = GetCurrentTimeSinceEpochMS();

    for (const string &key : keys) {
      string kb_state_str;
      reply = (redisReply *) redisCommand(redis_, "get %s", key.c_str());
      if (reply == NULL) {
        LOG(LogLevel::error, "Redis query failed. " + string(redis_->errstr));
        exit(0);
      }

      kb_state_str = reply->str;
      freeReplyObject(reply);

      // TODO: handle exception here, in case the parse failed.
      // If update to one kubot failed, just ignore it.
      nlohmann::json kb_state_json = nlohmann::json::parse(kb_state_str);
      string unique_id = kb_state_json["robotId"];
      KubotState ks = KubotState(kb_state_json);

      // If a robot redis record is older than kKubotMaxWaitTimeSecs seconds, do not use it.
      if (time_ms - ks.last_update_ms > kRobotStateStaleDurationMSecs) {
        continue;
      }

      // Do not update for a robot in state pause.
      if (ks.state_type == RobotState::ROBOT_PAUSE) {
        continue;
      }

      // TODO: implement a batch update mode isntead of update the kubot state one by one.
      ssp_->UpdateKubotState(unique_id, ks);
    }
    scheduling_server::SleepMS(kSyncerPullIntervalMS);
  }
}

}