#include "local_ms.h"

namespace messaging_service {

using namespace std;

bool LocalMs::SendToLlAsync(const std::string &msg) {
  lock_guard lock(ll_mutex_);
  if (ll_queue_.size() > MESSAGE_QUEUE_CAPACITY) {
    return false;
  }
  ll_queue_.push(msg);
  ll_consumer_.notify_one();
  return true;
}

bool LocalMs::SendToMcAsync(const std::string &msg) {
  lock_guard lock(mc_mutex_);
  if (mc_queue_.size() > MESSAGE_QUEUE_CAPACITY) {
    return false;
  }
  mc_queue_.push(msg);
  mc_consumer_.notify_one();
  return true;
}

bool LocalMs::SendToSsAsync(const std::string &msg) {
  lock_guard lock(ss_mutex_);
  if (ss_queue_.size() > MESSAGE_QUEUE_CAPACITY) {
    return false;
  }
  ss_queue_.push(msg);
  ss_consumer_.notify_one();
  return true;
}

std::string LocalMs::BlockingReceiveAsLl() {
  ll_mutex_.lock();
  while (ll_queue_.empty()) {
    ll_consumer_.wait(ll_mutex_);
  }
  string rtn = ll_queue_.front();
  ll_queue_.pop();
  ll_mutex_.unlock();
  return rtn;
}

std::string LocalMs::BlockingReceiveAsMc() {
  mc_mutex_.lock();
  while (mc_queue_.empty()) {
    mc_consumer_.wait(mc_mutex_);
  }
  string rtn = mc_queue_.front();
  mc_queue_.pop();
  mc_mutex_.unlock();
  return rtn;
}

std::string LocalMs::BlockingReceiveAsSs() {
  ss_mutex_.lock();
  while (ss_queue_.empty()) {
    ss_consumer_.wait(ss_mutex_);
  }
  string rtn = ss_queue_.front();
  ss_queue_.pop();
  ss_mutex_.unlock();
  return rtn;
}

}