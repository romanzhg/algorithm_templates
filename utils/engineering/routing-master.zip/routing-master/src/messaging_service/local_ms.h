#ifndef MESSAGING_SERVICE_LOCAL_MS_H
#define MESSAGING_SERVICE_LOCAL_MS_H

#include <condition_variable>
#include <queue>
#include <mutex>

#include "messaging_service.h"

namespace messaging_service {

class LocalMs : public MessagingServiceInterface {
 public:
  LocalMs() {};

  bool ConnectToLl(const std::string &addr) { return true; };
  bool ConnectToMc(const std::string &addr) { return true; };
  bool ConnectToSs(const std::string &addr) { return true; };

  bool SendToLlAsync(const std::string &msg) override;
  bool SendToMcAsync(const std::string &msg) override;
  bool SendToSsAsync(const std::string &msg) override;

  std::string BlockingReceiveAsLl() override;
  std::string BlockingReceiveAsMc() override;
  std::string BlockingReceiveAsSs() override;

 private:
  std::mutex ll_mutex_;
  std::mutex mc_mutex_;
  std::mutex ss_mutex_;

  std::queue<std::string> ll_queue_;
  std::queue<std::string> mc_queue_;
  std::queue<std::string> ss_queue_;

  std::condition_variable_any ll_consumer_;
  std::condition_variable_any mc_consumer_;
  std::condition_variable_any ss_consumer_;
};

}  // namespace

#endif //ROUTING_SRC_MESSAGING_SERVICE_LOCAL_MS_H_
