#ifndef MESSAGING_SERVICE_MESSAGING_SERVICE_H
#define MESSAGING_SERVICE_MESSAGING_SERVICE_H

#include <string>

namespace messaging_service {

const int MESSAGE_QUEUE_CAPACITY = 10000;

class MessagingServiceInterface {
 public:
  virtual bool ConnectToLl(const std::string& addr) = 0;
  virtual bool ConnectToMc(const std::string& addr) = 0;
  virtual bool ConnectToSs(const std::string& addr) = 0;

  // These methods are thread safe and async.
  virtual bool SendToLlAsync(const std::string& msg) = 0;
  virtual bool SendToMcAsync(const std::string& msg) = 0;
  virtual bool SendToSsAsync(const std::string& msg) = 0;

  virtual std::string BlockingReceiveAsLl() = 0;
  virtual std::string BlockingReceiveAsMc() = 0;
  virtual std::string BlockingReceiveAsSs() = 0;
};
}

#endif