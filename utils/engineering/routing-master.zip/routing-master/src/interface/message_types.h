#ifndef SS_TYPES_H
#define SS_TYPES_H

namespace scheduling_server {

enum class TrayType : int {
  FORK = 0,
  BEILOU = 1,
};

enum class TrayState : int {
  FULL = 0,
  EMPTY = 1,
  ERROR = 2,
};

enum class ExecutionResult : int {
  SUCCESS = 0,
  CANCLED = 1,
  DECLINE = 2,
  FAIL = 3,
};

enum class RobotState : int {
  ROBOT_READY_TO_INIT = 0,
  ROBOT_IDLE = 1,
  ROBOT_RUNNING = 2,
  ROBOT_PAUSE = 3,
  ROBOT_ERROR = 4,
};

enum class MessageType : int {
  RCS2LL_INIT = 0,
  RCS2LL_MOVE = 1,
  RCS2LL_BIN_OP = 2,
  RCS2LL_INTERNAL_BIN_OP = 3,
  RCS2LL_PAUSE = 4,
  RCS2LL_RECOVER = 5,
  RCS2LL_CANCEL = 6,
  LL2RCS_RESP = 7,

  MC2RCS_PUSH_MISSION = 8,
  MC2RCS_BIN_UPDATE = 9,
  MC2RCS_CANCEL = 12,
  MC2RCS_KILL_ROBOT = 13,
  RCS2MC_MISSION_UPDATE = 21,
  RCS2MC_OP_UPDATE = 22,
  MC2RCS_DETOUR = 23,

  MC2IS_INIT = 1000,
  MC2IS_CHECK_INVENTORY = 1001,
  MC2IS_INVENTORY = 1002,
  LL2IS_INVENTORY_UPDATE = 1003,

  IS2MC_INIT_RESP = 1004,
  IS2MC_INVENTORY_RESP = 1005,
  IS2LL_INVENTORY_RESP = 1006,
  IS_INVENTORY_RESP = 1007,
};

enum class BinOpType : int {
  PUT_NEAR = 0,
  PUT_FAR = 1,
  TAKE_NEAR = 2,
  TAKE_FAR = 3,
};

enum class BinHandlingResult : int {
  SUCCESS = 0,
  FAILURE = 1,
};

enum class BatteryState : int {
  NORMAL = 0,
  CHARGING = 1,
};

// Types used between MC and RCS.
enum class OpResult : int {
  SUCCESS = 0,
  FAILURE = 1,
  CANCEL = 2,
  DECLINE = 3,
  ERROR = 4,
};

enum class MissionStatus : int {
  SUCCESS = 0,
  FAILURE = 1,
  CANCEL = 2,
  DECLINE = 3,
  ERROR = 4,
};

enum class OpType : int {
  MOVE = 0,
  LOAD = 1,
  UNLOAD = 2,
  WAIT = 3,
};

}

#endif