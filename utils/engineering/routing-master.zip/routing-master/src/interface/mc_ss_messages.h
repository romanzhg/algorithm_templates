#ifndef ROUTING_SRC_INTERFACE_MC_SS_MESSAGE_TYPES_H_
#define ROUTING_SRC_INTERFACE_MC_SS_MESSAGE_TYPES_H_

#include <string>
#include <vector>

#include "message_types.h"
#include "position.h"
#include "json.hpp"

namespace scheduling_server {

// Types between MC and SS.
struct McBinUpdate {
  int robot_id;
  int bin_id;
  int tray_id;
  OpType op_type;
  TrayType tray_type;

  McBinUpdate() = default;
  McBinUpdate(const nlohmann::json &json) {
    FromJson(json);
  };

  void FromJson(const nlohmann::json &json) {
    robot_id = json["kubotId"];
    bin_id = json["binId"];
    tray_id = json["trayId"];
    op_type = json["opType"];
    tray_type = json["trayType"];

  }

  nlohmann::json ToJson() const {
    return {{"binId", bin_id},
            {"opType", op_type},
            {"trayId", tray_id},
            {"trayType", tray_type},
            {"kubotId", robot_id}};
  }
};

struct McOperation {
  int64_t op_id;
  OpType type;
  PositionXYT map_position;
  double fork_height;
  int bin_id;
  double fork_orient;

  McOperation() = default;
  McOperation(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    nlohmann::json j;
    j["opId"] = op_id;
    j["type"] = type;
    j["mapPosition"] = map_position.ToJson();
    j["forkHeight"] = fork_height;
    j["binId"] = bin_id;
    j["forkOrient"] = fork_orient;
    return j;
  }

  void FromJson(const nlohmann::json &j) {
    op_id = j["opId"];
    type = j["type"];
    if (type == OpType::WAIT) {
      return;
    }
    map_position.FromJson(j["mapPosition"]);
    if (type == OpType::MOVE) {
      return;
    }
    fork_height = j["forkHeight"];
    bin_id = j["binId"];
    fork_orient = j["forkOrient"];
  }
};

struct MissionMessageBody {
  int mission_id;
  int robot_id;
  std::vector<McOperation> operations;

  MissionMessageBody() = default;
  MissionMessageBody(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    nlohmann::json j;
    j["missionId"] = mission_id;
    j["kubotId"] = robot_id;
    j["operations"] = nlohmann::json::array();
    for (const McOperation &op : operations) {
      j["operations"].push_back(op.ToJson());
    }
    return j;
  }

  void FromJson(const nlohmann::json &j) {
    mission_id = j["missionId"];
    robot_id = j["kubotId"];
    if (j.contains("operations")) {
      for (const nlohmann::json &op : j["operations"]) {
        operations.emplace_back(op);
      }
    }
  }
};

struct McMission {
  MissionMessageBody msg_body;

  McMission() = default;
  McMission(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    return {{"msgType", MessageType::MC2RCS_PUSH_MISSION},
            {"msgBody", msg_body.ToJson()}};
  }

  void FromJson(const nlohmann::json &j) {
    msg_body.FromJson(j["msgBody"]);
  }
};

struct McCancelMission {
  int robot_id;

  McCancelMission() = default;
  McCancelMission(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    return {
        {"msgType", MessageType::MC2RCS_CANCEL},
        {"msgBody", {{"kubotId", robot_id}}}};
  }

  void FromJson(const nlohmann::json &j) {
    robot_id = j["msgBody"]["kubotId"];
  }
};

struct McKillRobot {
  int robot_id;

  McKillRobot() = default;
  McKillRobot(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    return {
        {"msgType", MessageType::MC2RCS_KILL_ROBOT},
        {"msgBody", {{"kubotId", robot_id}}}};
  }

  void FromJson(const nlohmann::json &j) {
    robot_id = j["msgBody"]["kubotId"];
  }
};

struct McDetour {
  int robot_id;
  PositionXYT pos;

  McDetour() = default;
  McDetour(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    return {
        {"msgType", MessageType::MC2RCS_DETOUR},
        {"msgBody", {{"kubotId", robot_id},
                     {"mapPosition", pos.ToJson()}}}};
  }

  void FromJson(const nlohmann::json &j) {
    robot_id = j["msgBody"]["kubotId"];
    pos.FromJson(j["msgBody"]["mapPosition"]);
  }
};

struct RcsOpUpdate {
  int robot_id;
  int64_t op_id;
  int mission_id;
  OpResult op_result;
  TrayType dest_tray_type;
  int dest_tray_id;

  RcsOpUpdate() = default;
  RcsOpUpdate(int kubot_id, int64_t op_id, int mission_id, OpResult op_result,
              TrayType dest_tray_type, int dest_tray_id)
      : robot_id(kubot_id), op_id(op_id), mission_id(mission_id), op_result(op_result),
        dest_tray_type(dest_tray_type), dest_tray_id(dest_tray_id) {};
  RcsOpUpdate(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    return {{"msgType", MessageType::RCS2MC_OP_UPDATE},
            {"msgBody", {{"opId", op_id},
                         {"missionId", mission_id},
                         {"opResult", op_result},
                         {"kubotId", robot_id},
                         {"destTrayType", dest_tray_type},
                         {"destTrayId", dest_tray_id}}}
    };
  }

  void FromJson(const nlohmann::json &j) {
    op_id = j["msgBody"]["opId"];
    mission_id = j["msgBody"]["missionId"];
    op_result = j["msgBody"]["opResult"];
    robot_id = j["msgBody"]["kubotId"];
    dest_tray_type = j["msgBody"]["destTrayType"];
    dest_tray_id = j["msgBody"]["destTrayId"];
  }
};

struct RcsMissionUpdate {
  int mission_id;
  int robot_id;
  MissionStatus mission_status;

  RcsMissionUpdate() = default;
  RcsMissionUpdate(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    nlohmann::json j = {
        {"missionId", mission_id},
        {"kubotId", robot_id},
        {"missionStatus", mission_status},
    };
    j["trayBins"] = nlohmann::json::array();
    return {{"msgType", MessageType::RCS2MC_MISSION_UPDATE},
            {"msgBody", j}};
  }

  void FromJson(const nlohmann::json &j) {
    const nlohmann::json &body = j["msgBody"];
    mission_id = body["missionId"];
    robot_id = body["kubotId"];
    mission_status = body["missionStatus"];
  }
};

}
#endif //ROUTING_SRC_INTERFACE_MC_SS_MESSAGE_TYPES_H_
