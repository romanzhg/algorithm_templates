#ifndef ROUTING_SRC_INTERFACE_SS_LL_MESSAGE_TYPES_H_
#define ROUTING_SRC_INTERFACE_SS_LL_MESSAGE_TYPES_H_

#include <string>
#include <vector>

#include "message_types.h"
#include "json.hpp"
#include "position.h"

namespace scheduling_server {

struct RcsKubotTray {
  int tray_id;
  TrayType tray_type;
  int bin_id;

  RcsKubotTray() = default;

  RcsKubotTray(int tray_id, TrayType tray_type, int bin_id)
      : tray_id(tray_id), tray_type(tray_type), bin_id(bin_id) {};

  RcsKubotTray(const nlohmann::json &j) {
    FromJson(j);
  }

  nlohmann::json ToJson() const {
    return {{"trayId", tray_id},
            {"trayType", tray_type},
            {"binId", bin_id}};
  }

  void FromJson(const nlohmann::json &j) {
    tray_id = j["trayId"];
    tray_type = j["trayType"];
    bin_id = j["binId"];
  }
};

// Types between SS and LL.
struct KubotTray {
  TrayType type;
  int tray_id;

  // TODO: Add these fields back once the tray state sensor on robot is ready.
  // These two fields are not used in this version.
  // TrayState state;
  // This bin id is uploaded by the link layer.
  // std::string bin_str_id;

  KubotTray() = default;
  KubotTray(TrayType t, int id)
      : type(t), tray_id(id) {};
  KubotTray(const nlohmann::json &j) {
    FromJson(j);
  }

  void FromJson(const nlohmann::json &j) {
    type = j["trayType"];
    tray_id = j["trayId"];
  }

  nlohmann::json ToJson() const {
    return {{"trayType", type},
            {"trayId", tray_id}};
  }
};

// This struct corresponds to the Kubot State link layer published in redis.
struct KubotState {
  std::string unique_id;
  RobotState state_type;
  PositionXYT pos;
  std::vector<KubotTray> trays;
  int power_level;
  BatteryState battery_state;
  uint64_t last_update_ms;
  // Not used in the current version.
  // double fork_height;

  KubotState() = default;
  KubotState(const nlohmann::json &j) {
    FromJson(j);
  };

  void FromJson(const nlohmann::json &j) {
    unique_id = j["robotId"];
    state_type = j["robotState"];
    pos = PositionXYT(j["mapPosition"]);
    for (const auto &elem : j["trays"]) {
      trays.push_back(KubotTray(elem));
    }
    power_level = j["batteryInfo"]["powerLevel"];
    battery_state = j["batteryInfo"]["state"];
    last_update_ms = j["lastUpdate"];
  }

  nlohmann::json ToJson() const {
    nlohmann::json j;
    j["robotId"] = unique_id;
    j["robotState"] = state_type;
    j["mapPosition"] = pos.ToJson();
    j["trays"] = nlohmann::json::array();
    for (const auto &tray : trays) {
      j["trays"].push_back(tray.ToJson());
    }
    j["batteryInfo"]["powerLevel"] = power_level;
    j["batteryInfo"]["state"] = battery_state;
    j["lastUpdate"] = last_update_ms;
    return j;
  }

};

struct KubotInfo {
  int robot_id;
  std::string unique_name;
  bool is_available;
  PositionXY target_point;
  std::vector<PositionXY> locked_points;
  std::vector<RcsKubotTray> tray_info;

  KubotInfo() = default;
  explicit KubotInfo(const nlohmann::json &j) {
    FromJson(j);
  }

  void FromJson(const nlohmann::json &j) {
    robot_id = j["robotId"];
    unique_name = j["robotUniqueName"];
    is_available = j["isAvailable"];
    target_point.FromJson(j["targetPoint"]);
    if (j.contains("lockedPoints")) {
      for (const auto &elem : j["lockedPoints"]) {
        locked_points.emplace_back(elem);
      }
    }
    if (j.contains("trayInfo")) {
      for (const auto &elem : j["trayInfo"]) {
        tray_info.emplace_back(elem);
      }
    }
  }

  nlohmann::json ToJson() const {
    nlohmann::json j;
    j["robotId"] = robot_id;
    j["robotUniqueName"] = unique_name;
    j["isAvailable"] = is_available;
    j["targetPoint"] = target_point.ToJson();

    j["lockedPoints"] = nlohmann::json::array();
    for (const auto &elem : locked_points) {
      j["lockedPoints"].push_back(elem.ToJson());
    }

    j["trayInfo"] = nlohmann::json::array();
    for (const auto &elem : tray_info) {
      j["trayInfo"].push_back(elem.ToJson());
    }
    return j;
  }
};

// Types relate to the instructions to real robots.
struct RcsToLlMoveInst {
  PositionXYT target_position;
};

struct RcsToLlBinOpInst {
  BinOpType op_type;
  double height;
  PositionXYT map_position;
  double fork_orient;
  int bin_id;
};

struct RcsToLlInternalBinOpInst {
  int source_tray_id;
  TrayType source_tray_type;
  int dest_tray_id;
  TrayType dest_tray_type;
  // For take operation, id of the bin to be put in the tray.
  int bin_id;
};

struct RcsToLlCancelInst {
  uint64_t target_seq_num;
};

// TODO: optimize this so we don't allocate storage for the instructions we don't use.
struct Instruction {
  MessageType type;
  uint64_t seq_num;
  std::string robot_unique_id;

  RcsToLlMoveInst move_inst;
  RcsToLlBinOpInst bin_op_inst;
  RcsToLlInternalBinOpInst internal_bin_op_inst;
  RcsToLlCancelInst cancel_inst;

  Instruction() = default;
  Instruction(const nlohmann::json &json) {
    FromJson(json);
  }
  Instruction &operator=(const Instruction &o) = default;

  void FromJson(const nlohmann::json &j) {
    type = j["msgType"];
    seq_num = j["seqNum"];
    robot_unique_id = j["robotId"];

    if (type == MessageType::RCS2LL_MOVE) {
      move_inst.target_position.FromJson(j["targetPosition"]);
    }
    if (type == MessageType::RCS2LL_BIN_OP) {
      bin_op_inst.height = j["forkHeight"];
      bin_op_inst.map_position.FromJson(j["mapPosition"]);
      bin_op_inst.fork_orient = j["forkOrient"];
      bin_op_inst.bin_id = j["binId"];
      bin_op_inst.op_type = j["opType"];
    }
    if (type == MessageType::RCS2LL_INTERNAL_BIN_OP) {
      internal_bin_op_inst.bin_id = j["binId"];
      internal_bin_op_inst.source_tray_type = j["sourceTray"]["type"];
      internal_bin_op_inst.source_tray_id = j["sourceTray"]["id"];
      internal_bin_op_inst.dest_tray_type = j["destTray"]["type"];
      internal_bin_op_inst.dest_tray_id = j["destTray"]["id"];
    }
    if (type == MessageType::RCS2LL_CANCEL) {
      cancel_inst.target_seq_num = j["targetSeqNum"];
    }
  }

  nlohmann::json ToJson() const {
    nlohmann::json j;
    j["msgType"] = type;
    j["seqNum"] = seq_num;
    j["robotId"] = robot_unique_id;

    if (type == MessageType::RCS2LL_MOVE) {
      j["targetPosition"] = move_inst.target_position.ToJson();
    }
    if (type == MessageType::RCS2LL_BIN_OP) {
      j["forkHeight"] = bin_op_inst.height;
      j["mapPosition"] = bin_op_inst.map_position.ToJson();
      j["forkOrient"] = bin_op_inst.fork_orient;
      j["binId"] = bin_op_inst.bin_id;
      j["opType"] = bin_op_inst.op_type;
    }
    if (type == MessageType::RCS2LL_INTERNAL_BIN_OP) {
      j["binId"] = internal_bin_op_inst.bin_id;
      j["sourceTray"]["type"] = internal_bin_op_inst.source_tray_type;
      j["sourceTray"]["id"] = internal_bin_op_inst.source_tray_id;
      j["destTray"]["type"] = internal_bin_op_inst.dest_tray_type;
      j["destTray"]["id"] = internal_bin_op_inst.dest_tray_id;
    }
    if (type == MessageType::RCS2LL_CANCEL) {
      j["targetSeqNum"] = cancel_inst.target_seq_num;
    }
    return j;
  }
};

struct LlResp {
  std::string robot_unique_id;
  MessageType type;
  uint64_t seq_num;
  ExecutionResult execution_result;

  LlResp() = default;
  LlResp(const nlohmann::json &json) {
    FromJson(json);
  }

  LlResp(const std::string &unique_id, const MessageType &type,
         uint64_t seq_num, const ExecutionResult &result)
      : robot_unique_id(unique_id),
        type(type),
        seq_num(seq_num),
        execution_result(result) {}

  nlohmann::json ToJson() const {
    nlohmann::json j;
    j["msgType"] = type;
    j["seqNum"] = seq_num;
    j["executionResult"] = execution_result;
    j["robotId"] = robot_unique_id;
    return j;
  }

  void FromJson(const nlohmann::json &j) {
    type = j["msgType"];
    seq_num = j["seqNum"];
    execution_result = j["executionResult"];
    robot_unique_id = j["robotId"];
  }
};
}
#endif //ROUTING_SRC_INTERFACE_SS_LL_MESSAGE_TYPES_H_
