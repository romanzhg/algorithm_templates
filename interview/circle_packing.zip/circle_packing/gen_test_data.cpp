/**
 * Generate a 500 * 500 rectangular and random circles.
 */
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
  srand(time(NULL));
  int number_of_circles = 1000;

  cout << 500 << " " << 500 << " " << number_of_circles << endl;

  for (int i = 0; i < number_of_circles; i++) {
    int x = rand() % 300 + 100;
    int y = rand() % 300 + 100;
    int r = rand() % 70 + 2;
    cout << x << " " << y << " " << r << " ";
  }
  cout << endl;
  return 0;
}