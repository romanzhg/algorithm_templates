/**
 * Find exact solution to the maximum weighted independent set problem.
 *
 * Please refer to circle_packing_solution_ZhangHong.pdf for usage.
 */
#include <map>
#include <vector>
#include <cmath>
// For drawing.
#include <opencv2/opencv.hpp>

using namespace std;

const double kPi = 3.141592;

struct Circle {
  double x, y, r, area;
  Circle(double x, double y, double r, double area) : x(x), y(y), r(r), area(area) {};
  bool operator<(const Circle &o) const {
    return area > o.area;
  }
};

// Helper functions.
double GetDist(double x1, double y1, double x2, double y2) {
  return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

bool Intersects(const Circle &a, const Circle &b) {
  return GetDist(a.x, a.y, b.x, b.y) < a.r + b.r;
}

// Global data.
// L and W of the rectangular.
double length, width;
// Circles, excluded the invalid ones.
vector<Circle> circles;
// Graph representation.
map<int, set<int>> adj_map;
set<int> rtn_set;
double max_area_sum = 0;

void helper(vector<int> &free_count, int index, set<int> &chosen_set, double prev_sum) {
  if (index == free_count.size()) {
    if (max_area_sum < prev_sum) {
      max_area_sum = prev_sum;
      rtn_set = chosen_set;
    }
    return;
  }

  // Take current circle.
  if (free_count[index] >= 1) {
    free_count[index]--;
    for (int adj_vertex : adj_map[index]) {
      free_count[adj_vertex]--;
    }

    chosen_set.insert(index);
    helper(free_count, index + 1, chosen_set, prev_sum + circles[index].area);
    chosen_set.erase(index);

    for (int adj_vertex : adj_map[index]) {
      free_count[adj_vertex]++;
    }
    free_count[index]++;
  }

  // Do not take current circle.
  // The if statement does the pruning here: only when a vertex has some neighbors, we
  // need to try not taking it, otherwise it should always be taken.
  if (!adj_map[index].empty()) {
    helper(free_count, index + 1, chosen_set, prev_sum);
  }
}

void DrawCircle(cv::Mat image, cv::Point center, int radius) {
  cv::circle(image,
             center,
             radius,
             cv::Scalar(0),
             1,
             cv::LINE_8);
}

void DrawResult() {
  cv::Mat image(length, width, CV_8UC1, cv::Scalar(255));
  for (int c : rtn_set) {
    DrawCircle(image, cv::Point(circles[c].x, circles[c].y), circles[c].r);
  }
  imwrite("exact_sol_output.jpg", image);
}

int main() {
  int circle_count;
  scanf("%lf %lf %d", &length, &width, &circle_count);

  for (int i = 0; i < circle_count; i++) {
    double x, y, r;
    scanf("%lf %lf %lf", &x, &y, &r);

    // Ignore circles out of the boundary.
    if (x - r < 0 || x + r > length || y - r < 0 || y + r > width) {
      continue;
    }

    circles.emplace_back(x, y, r, kPi * r * r);
  }

  // Larger circles in front.
  sort(circles.begin(), circles.end());

  circle_count = circles.size();
  for (int i = 0; i < circle_count; i++) {
    for (int j = i + 1; j < circle_count; j++) {
      if (Intersects(circles[i], circles[j])) {
        adj_map[i].insert(j);
        adj_map[j].insert(i);
      }
    }
  }

  vector<int> free_count(circle_count, 1);
  set<int> chosen_set;
  helper(free_count, 0, chosen_set, 0);

  // Uncomment to show the total area.
  //  cout << max_area_sum << endl;
  DrawResult();
  return 0;
}