/**
 * Find approximate solution to the maximum weighted independent set problem.
 * May favor a central-symmetry-like solution depends on the value of kCSL.
 *
 * Please refer to circle_packing_solution_ZhangHong.pdf for usage.
 */

#include <map>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iostream>
// For drawing.
#include <opencv2/opencv.hpp>

using namespace std;

const double kPi = 3.141592;
// How much a central-symmetry-like solution should be favored.
const double kCSL = 0.5;
const int kRandomSeeds = 1000;
const int kLocalSearchIterations = 1000;

struct Circle {
  double x, y, r, area;
  Circle(double x, double y, double r, double area) : x(x), y(y), r(r), area(area) {};
};

// Helper functions.
double GetDist(double x1, double y1, double x2, double y2) {
  return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

bool Intersects(const Circle &a, const Circle &b) {
  return GetDist(a.x, a.y, b.x, b.y) < a.r + b.r;
}

// Return true with probability a/b.
inline bool GetTrueWithProb(double a, double b) {
  return rand() < (a / b * RAND_MAX);
}

set<int> SetIntersection(const set<int>& a, const set<int>& b) {
  set<int> rtn;
  for (int v : a) {
    if (b.find(v) != b.end()) {
      rtn.insert(v);
    }
  }
  return rtn;
}

set<int> SetSubtraction(const set<int>& a, const set<int>& b) {
  set<int> rtn = a;
  for (int v : b) {
    rtn.erase(v);
  }
  return rtn;
}


// Global data and constants.
// L and W of the rectangular.
double length, width, half_diag;
// Circles, excluded the invalid ones.
vector<Circle> circles;
// Graph representation.
map<int, set<int>> adj_map;

bool HasFreeCircles(const vector<int> &free_count) {
  for (int v : free_count) {
    if (v >= 1) {
      return true;
    }
  }
  return false;
}

// Reservior sampling.
int SelectRandomFreeCircle(const vector<int> &free_count) {
  int selected_index = -1;
  int counter = 1;

  for (int i = 0; i < free_count.size(); i++) {
    if (free_count[i] >= 1) {
      if (GetTrueWithProb(1, counter)) {
        selected_index = i;
      }
      counter++;
    }
  }
  return selected_index;
}

set<int> GenRandomSeed(vector<int> &free_count) {
  set<int> rtn;
  while (HasFreeCircles(free_count)) {
    int s = SelectRandomFreeCircle(free_count);
    free_count[s]--;
    for (int adj_vertex : adj_map[s]) {
      free_count[adj_vertex]--;
    }
    rtn.insert(s);
  }
  return rtn;
}

double GetAreaFromSelection(const set<int> &selected) {
  double total_area = 0;
  for (int c : selected) {
    total_area += circles[c].area;
  }
  return total_area;
}

double GetScoreFromSelection(const set<int> &selected) {
  double total_area = 0;
  double centroid_x = 0, centroid_y = 0;
  for (int c : selected) {
    total_area += circles[c].area;
    centroid_x += circles[c].area * circles[c].x;
    centroid_y += circles[c].area * circles[c].y;
  }
  centroid_x = centroid_x / total_area;
  centroid_y = centroid_y / total_area;

  return total_area * (1 - kCSL * GetDist(centroid_x, centroid_y, length / 2, width / 2) / half_diag);
}

set<int> LocalSearch(set<int> selection, vector<int> &free_count) {
  int circle_count = circles.size();
  int iterations = 0;

  while (iterations++ < kLocalSearchIterations) {
    int vertex_to_use = -1;
    int iterations_to_find = circle_count / 2;
    while (iterations_to_find-- > 0) {
      int rand_vertex = rand() % circle_count;
      if (selection.find(rand_vertex) != selection.end()) {
        continue;
      }
      set<int> to_remove = SetIntersection(adj_map[rand_vertex], selection);
      set<int> removed = SetSubtraction(selection, to_remove);
      removed.insert(rand_vertex);
      if (GetScoreFromSelection(removed) > GetScoreFromSelection(selection)) {
        vertex_to_use = rand_vertex;
        break;
      }
    }

    // Cannot find a vertex to add.
    if (vertex_to_use == -1) {
      break;
    }
    // Take current vertex.
    set<int> to_remove = SetIntersection(adj_map[vertex_to_use], selection);
    for (int s : to_remove) {
      free_count[s]++;
      for (int adj_vertex : adj_map[s]) {
        free_count[adj_vertex]++;
      }
      selection.erase(s);
    }

    selection.insert(vertex_to_use);
    free_count[vertex_to_use]--;
    for (int adj_vertex : adj_map[vertex_to_use]) {
      free_count[adj_vertex]--;
    }
  }
  return selection;
}

void DrawCircle(cv::Mat image, cv::Point center, int radius) {
  cv::circle(image, center, radius, cv::Scalar(0), 1, cv::LINE_8);
}

void DrawResult(const set<int> &rtn_set) {
  cv::Mat image(length, width, CV_8UC1, cv::Scalar(255));
  for (int c : rtn_set) {
    DrawCircle(image, cv::Point(circles[c].x, circles[c].y), circles[c].r);
  }
  imwrite("approximate_sol_output.jpg", image);
}

int main() {
  srand(time(NULL));

  int circle_count;
  scanf("%lf %lf %d", &length, &width, &circle_count);
  half_diag = sqrt(length * length + width * width) / 2;

  for (int i = 0; i < circle_count; i++) {
    double x, y, r;
    scanf("%lf %lf %lf", &x, &y, &r);

    // Ignore circles out of the boundary.
    if (x - r < 0 || x + r > length || y - r < 0 || y + r > width) {
      continue;
    }

    circles.emplace_back(x, y, r, kPi * r * r);
  }

  circle_count = circles.size();
  for (int i = 0; i < circle_count; i++) {
    for (int j = i + 1; j < circle_count; j++) {
      if (Intersects(circles[i], circles[j])) {
        adj_map[i].insert(j);
        adj_map[j].insert(i);
      }
    }
  }

  set<int> overall_optimal;
  double overall_optimal_score = 0;
  for (int i = 0; i < kRandomSeeds; i++) {
    vector<int> free_count(circle_count, 1);
    set<int> random_selection = GenRandomSeed(free_count);
    set<int> local_rand_optimal = LocalSearch(random_selection, free_count);
    double local_rand_optimal_score = GetScoreFromSelection(local_rand_optimal);
    if (overall_optimal_score < local_rand_optimal_score) {
      overall_optimal_score = local_rand_optimal_score;
      overall_optimal = local_rand_optimal;
    }
  }

  cout << GetAreaFromSelection(overall_optimal) << endl;
  DrawResult(overall_optimal);
  return 0;
}